"""Tests for users.py -- uses a TEMP database, never the real users.db."""

import os
import tempfile

import users

TMP = tempfile.mkdtemp()
DB = os.path.join(TMP, "test_users.db")
REAL_DB = os.path.join(os.path.dirname(os.path.abspath(users.__file__)),
                       "users.db")

users.init_db(DB)

# --- empty start ---
assert users.user_count() == 0

# --- create admin ---
users.create_user("hamza", "admin123", is_admin=True)
assert users.user_count() == 1

# --- verify ---
assert users.verify("hamza", "admin123") == ("ok", True)
assert users.verify("hamza", "wrong") == ("bad", False)
assert users.verify("koi-nahi", "admin123") == ("bad", False)  # no user leak
assert users.verify("", "") == ("bad", False)

# --- normal user ---
users.create_user("worker1", "pass123")
assert users.verify("worker1", "pass123") == ("ok", False)

# --- duplicate / validation ---
for fn, exc_msg in [
    (lambda: users.create_user("hamza", "other123"), "duplicate"),
    (lambda: users.create_user("", "pass123"), "empty username"),
    (lambda: users.create_user("x", "123"), "short password"),
    (lambda: users.create_user("x", ""), "empty password"),
]:
    try:
        fn()
        raise AssertionError(f"expected ValueError for {exc_msg}")
    except ValueError:
        pass

# --- list ---
lst = users.list_users()
assert lst == [("hamza", True, False, None), ("worker1", False, False, None)], lst

# --- block / unblock ---
users.set_blocked("worker1", True)
assert users.verify("worker1", "pass123") == ("blocked", False)
users.set_blocked("worker1", False)
assert users.verify("worker1", "pass123") == ("ok", False)
try:
    users.set_blocked("ghost", True)
    raise AssertionError("expected ValueError for unknown user")
except ValueError:
    pass

# --- cannot block the last admin ---
try:
    users.set_blocked("hamza", True)
    raise AssertionError("expected ValueError blocking last admin")
except ValueError:
    pass

# --- reset password ---
users.reset_password("worker1", "newpass99")
assert users.verify("worker1", "newpass99") == ("ok", False)
assert users.verify("worker1", "pass123") == ("bad", False)
try:
    users.reset_password("worker1", "12")
    raise AssertionError("expected ValueError for short password")
except ValueError:
    pass

# --- delete ---
users.delete_user("worker1")
assert users.user_count() == 1
assert users.verify("worker1", "newpass99") == ("bad", False)

# --- cannot delete the last admin ---
try:
    users.delete_user("hamza")
    raise AssertionError("expected ValueError deleting last admin")
except ValueError:
    pass

# --- second admin allows deleting the first ---
users.create_user("admin2", "admin456", is_admin=True)
users.delete_user("hamza")
assert users.verify("admin2", "admin456") == ("ok", True)

# --- hashes are not plaintext ---
import sqlite3
con = sqlite3.connect(DB)
row = con.execute("SELECT pw_hash, salt FROM users").fetchone()
con.close()
assert "admin456" not in row[0], "password stored in plaintext!"
assert len(row[0]) == 64 and len(row[1]) == 32  # sha256 hex + 16-byte salt hex

# --- the real users.db must NOT have been created by tests ---
assert not os.path.exists(REAL_DB), "tests created the real users.db!"


# --- expiry / subscription ---
import time as _t
# lifetime user (default)
users.create_user("sub1", "pass123")
assert users.get_expiry("sub1") is None
assert users.verify("sub1", "pass123") == ("ok", False)
assert users.fmt_expiry(None) == "Lifetime"
# 1 mahina wala user
exp = users.expiry_from_duration(30 * 86400)
users.create_user("sub2", "pass123", expires_at=exp)
assert users.verify("sub2", "pass123") == ("ok", False)
assert users.get_expiry("sub2") == exp
assert users.fmt_expiry(exp)[:4].isdigit()  # date string like 2026-..
# expired user
users.create_user("sub3", "pass123", expires_at=_t.time() - 10)
assert users.verify("sub3", "pass123") == ("expired", False)
assert users.fmt_expiry(_t.time() - 10).startswith("EXPIRED")
# renew: set_expiry
users.set_expiry("sub3", users.expiry_from_duration(90 * 86400))
assert users.verify("sub3", "pass123") == ("ok", False)
# back to lifetime
users.set_expiry("sub3", None)
assert users.get_expiry("sub3") is None
# list shows 4-tuples with expiry
d = {u: e for u, _a, _b, e in users.list_users()}
assert d["sub1"] is None and d["sub2"] == exp
# migration: purani DB (bina expires_at column) khulni chahiye
import sqlite3 as _sq
old_db = os.path.join(TMP, "old_schema.db")
con = _sq.connect(old_db)
con.execute("CREATE TABLE users (username TEXT PRIMARY KEY, pw_hash TEXT NOT NULL, salt TEXT NOT NULL, is_admin INTEGER NOT NULL DEFAULT 0, is_blocked INTEGER NOT NULL DEFAULT 0, created_at REAL NOT NULL)")
con.commit(); con.close()
users.init_db(old_db)  # migration chalni chahiye, crash nahi
assert users.list_users() == []
users.init_db(DB)  # wapis test db

print("All expiry tests passed.")

print("All user tests passed.")
