"""CPU / chipset database -- kaunsa CPU kis family ka hai.

Families: 'mtk' (MediaTek), 'spd' (Spreadtrum/Unisoc), 'qcom' (Qualcomm),
           'exynos' (Samsung), 'other'/None (unknown).

HONESTY: family sirf tab set hoti hai jab chipset string se wazeh ho.
Unknown -> None (koi jhoota daawa nahi).
"""

# --- MTK CPUs (MTxxxx / Helio / Dimensity) ---
MTK_CPUS = [
    "MT6761", "MT6762", "MT6763", "MT6765", "MT6768", "MT6769",
    "MT6771", "MT6781", "MT6785", "MT6789",
    "MT6833", "MT6853", "MT6873", "MT6877", "MT6879",
    "MT6883", "MT6885", "MT6886", "MT6889",
    "MT6890", "MT6891", "MT6893", "MT6896", "MT6899",
    "MT6983", "MT6985", "MT6989", "MT6991",
    "MT6735", "MT6737", "MT6739", "MT6750", "MT6753", "MT6755", "MT6757",
    "MT6795", "MT6797", "MT6799",
    "MT8127", "MT8163", "MT8167", "MT8173", "MT8176", "MT8183", "MT8188",
    "MT8192", "MT8195",
    "MT8321", "MT8735", "MT8755",
]
MTK_SERIES = ["helio", "dimensity"]

# --- SPD / Unisoc CPUs ---
SPD_CPUS = [
    "SC9832E", "SC9863A",
    "T310", "T606", "T612", "T616", "T618", "T760", "T765", "T770", "T820",
    "SC7731E", "SC9860", "SC9850",
    "Tiger T310", "Tiger T606", "Tiger T612", "Tiger T616", "Tiger T618",
    "Tiger T760",
]
SPD_SERIES = ["unisoc", "spreadtrum", "tiger"]

# --- Qualcomm ---
QCOM_SERIES = ["snapdragon"]
# EDL (9008) par sirf limited kaam: is tool me guide + basic ops.

# --- Samsung ---
EXYNOS_SERIES = ["exynos"]


def family_of(chipset):
    """Chipset string -> family ya None.

    e.g. 'Mediatek Helio G85' -> 'mtk'
         'Tiger T606'         -> 'spd'
         'Snapdragon 680'     -> 'qcom'
    """
    if not chipset:
        return None
    s = chipset.upper()
    # SPD pehle (kuch strings me dono aa sakte hain -- SPD specific match)
    for cpu in SPD_CPUS:
        if cpu.upper() in s:
            return "spd"
    for cpu in MTK_CPUS:
        if cpu.upper() in s:
            return "mtk"
    low = chipset.lower()
    for kw in SPD_SERIES:
        if kw in low:
            return "spd"
    for kw in MTK_SERIES:
        if kw in low:
            return "mtk"
    for kw in QCOM_SERIES:
        if kw in low:
            return "qcom"
    for kw in EXYNOS_SERIES:
        if kw in low:
            return "exynos"
    return None


# Har family par kaunsi operation categories chalti hain (honest matrix).
FAMILY_OPS = {
    "mtk": {
        "BROM (MTKClient)": True,
        "META IMEI (AT)": True,
        "Fastboot": True,   # agar bootloader fastboot support kare
        "SPD ops": False,
        "EDL": False,
    },
    "spd": {
        "BROM (MTKClient)": False,
        "META IMEI (AT)": False,
        "Fastboot": True,   # kuch SPD me fastboot hota hai
        "SPD ops": True,
        "EDL": False,
    },
    "qcom": {
        "BROM (MTKClient)": False,
        "META IMEI (AT)": False,
        "Fastboot": True,
        "SPD ops": False,
        "EDL": "guide",     # sirf guide -- firehose loaders device-specific
    },
    "exynos": {
        "BROM (MTKClient)": False,
        "META IMEI (AT)": False,
        "Fastboot": False,  # Samsung: Odin/Download mode
        "SPD ops": False,
        "EDL": False,
    },
}


def family_label(family):
    return {"mtk": "MediaTek", "spd": "Spreadtrum/Unisoc",
            "qcom": "Qualcomm", "exynos": "Samsung Exynos"}.get(family, "Unknown")


def op_allowed(family, op_kind):
    """op_kind: 'mtk' | 'spd' | 'meta_imei' | 'fastboot' | 'edl'.

    Returns (True, '') ya (False, 'Urdu wajah').
    family=None (koi model select nahi) -> allow (runtime par check hoga).
    """
    if not family:
        return True, ""
    if op_kind == "mtk":
        if family == "mtk":
            return True, ""
        return False, (f"Ye MTK operation hai -- selected CPU "
                       f"({family_label(family)}) par nahi chalega")
    if op_kind == "spd":
        if family == "spd":
            return True, ""
        return False, (f"Ye SPD/Unisoc operation hai -- selected CPU "
                       f"({family_label(family)}) par nahi chalega")
    if op_kind == "meta_imei":
        if family == "mtk":
            return True, ""
        return False, (f"META IMEI sirf MediaTek par -- selected CPU "
                       f"({family_label(family)})")
    if op_kind == "fastboot":
        if family in ("mtk", "spd", "qcom"):
            return True, ""
        return False, (f"Fastboot {family_label(family)} par nahi hota "
                       f"(Samsung: Odin mode use karo)")
    if op_kind == "edl":
        if family == "qcom":
            return True, ""  # guide only, handled separately
        return False, "EDL sirf Qualcomm (9008) par hota hai"
    return True, ""
