# Universal Android Servicing Utilities — Research Report
**(ADB-based, Windows PC repair toolkit — sab real, tested methods)**

## 1. Demo / Retail Mode Removal

**Samsung — Retail Mode app password (pehle try karo, no ADB needed):**
- Retail Mode app → "Exit Retail Demo Mode" → code: `5444`
- Na chale to: `24682468` (naye models), `M729Q16K8546`, `Ret@il-7398`, `Reta!l-9102`

**ADB method:**
```bash
adb shell pm uninstall -k --user 0 com.samsung.retaildemo
adb shell pm uninstall -k --user 0 com.samsung.retail
```
⚠️ Samsung LDU ka IMEI `00000000000000` hota hai — sirf app uninstall se IMEI repair nahi hota. LDU aksar stolen/display units — ownership verify karo.

**Pixel:** `adb shell am broadcast -a com.android.systemui.demo -e command exit`
**Asus:** `com.asus.livedemo`, `com.asus.livedemoservice` uninstall

## 2. OTA Update Disable (per brand)

**Samsung** (disable-user use karo, uninstall nahi):
```
com.sec.android.soagent, com.wssyncmldm, com.samsung.sdm,
com.samsung.sdm.sdmviewer, com.ws.dm
```
**Xiaomi:** `com.android.updater` — SIRF disable-user, uninstall = bootloop! `com.miui.securitycenter` kabhi touch mat karo.
**Oppo/Realme/OnePlus:** `com.oplus.ota` (disable-user zyada reliable)
**Vivo:** `com.vivo.updater`, `com.bbk.updater`
**GMS (sab brands):** `com.google.android.gms.update.SystemUpdateService`

## 3. Bloatware Removal (safe lists)

Golden rule: `pm uninstall -k --user 0` (factory reset par wapas aata hai). Restore: `pm install-existing <pkg>`.
NEVER: android, com.android.systemui, com.android.settings, com.android.phone, com.android.server.telecom, com.android.nfc, com.miui.securitycenter

**Samsung safe:** gamehome, messaging, vmanager, voc, easyMover, bixby, bixbyvoice, galaxybuds, facebook.*
**Xiaomi safe:** miui.analytics, miui.msa.global, miui.daemon, miui.bugreport, weather2, compass, player, videoplayer, notes, screenrecorder, mipicks, glgm, midrop, scanner, payment, wallet, cleanmaster, yellowpage, cloudbackup, cloudservice, micloudsync, xiaomi.discover, facebook.*
**Oppo/Realme safe:** coloros.compass2, coloros.video, coloros.browser, coloros.phonemanager, oppo.gamecenter, oppo.market, opos.cs, heytap.*, oppo.ovoicemanager, opera.preinstall, facebook.*
**Transsion safe:** transsion.overlay, cybercat.acbridge, transsion.aiservice, facebook.* (hilauncher sirf agar 3rd-party launcher installed ho)
**Vivo safe:** vivo.browser, vivo.weather, vivo.compass, facebook.*

## 4. Network/SIM Unlock — Honest
Koi free ADB trick modern SIM lock nahi khol sakta. SIM lock carrier ke IMEI database me hota hai.
Kaam karta hai: (1) carrier se free unlock request, (2) paid IMEI services ($5-30).
Pakistan: zyadatar factory-unlocked; PTA tax = registration, unlock nahi. Fake "SIM Unlock" button mat lagana.

## 5. Screen Lock Without Data Loss — Honest 2026
Android 8+ par namumkin (File-Based Encryption). TWRP .key delete sirf Android 7 ya neechay.
Naye phones: factory reset hi tareeqa. Tool me saaf likho ke data zaya hoga.

## 6. scrcpy
Free screen mirroring: github.com/Genymobile/scrcpy/releases (scrcpy-win64).
`scrcpy`, `scrcpy --record=file.mp4`, `scrcpy --turn-screen-off`, drag-drop APK install.
Toolkit: "Screen Mirror" button.

## 7. ADB One-Liners
- Info: `adb shell getprop ro.product.model`, `dumpsys battery`, `wm size`
- APK pull: `pm path <pkg>` + `adb pull`
- Install: `adb install`, `adb install -r`, `pm clear`
- Backup: `adb backup -apk -shared -all -f backup.ab`
- Screenshot: `adb exec-out screencap -p > screen.png`
- screenrecord: `adb shell screenrecord /sdcard/vid.mp4`
- Packages: `pm list packages`, `pm list packages -3`, `pm uninstall -k --user 0`, `pm disable-user --user 0`, `cmd package install-existing`, `pm enable`
- Wireless: `adb tcpip 5555`, `adb connect IP:5555`

## 8. FRP Overview 2026
- Samsung: SamFw FRP Tool (free, Android 14/15), TalkBack (mostly patched), Alliance Shield (hit-or-miss)
- Xiaomi MTK: mtkclient BROM erase frp/persistent. Fastboot: `fastboot erase config`
- Oppo/Vivo/Realme MTK: mtkclient; SPD: spd_dump; Qualcomm: EDL (auth needed)
- Infinix/Tecno: QR code ADB enable → ADB packages disable
- Universal (rare): `content insert --uri content://settings/secure` user_setup_complete=1
- Caveats: har patch puranay exploits band karta hai; naye Snapdragon par authorized account; ownership proof lo.
