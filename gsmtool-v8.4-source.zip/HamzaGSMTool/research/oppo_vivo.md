# Oppo / Vivo / Realme / OnePlus Servicing Research
**Date:** 2026-10-10 | **Audience:** mobile repair technician (Pakistan) | **Focus:** free, working methods

---

## 1. Oppo/Realme OFP Firmware

**What OFP is:** OFP is Oppo's encrypted firmware container (also used by Realme and OnePlus for service firmware). It cannot be flashed via fastboot or recovery directly — it must be decrypted/extracted first or flashed with a dedicated tool.

### Free extraction — `oppo_decrypt` (by bkerler, open source)
```
# Install (Windows/Linux/macOS, Python 3.8+)
pip install -r requirements.txt        # from https://github.com/bkerler/oppo_decrypt

# Extract Oppo OFP (Qualcomm chipset)
python ofp_qc_decrypt.py firmware.ofp  D:\Extracted

# Extract Oppo OFP (MediaTek chipset)
python ofp_mtk_decrypt.py firmware.ofp D:\Extracted

# Extract OnePlus .ops firmware
python opscrypto.py decrypt firmware.ops      # output in .\extract\
python opscrypto.py encrypt .\extract\        # repack

# Merge split super images (check super_map.csv.txt first — must be same carrier)
simg2img super.0.xxxxxxxx.img super.1.xxxxxxxx.img super.img
```

### Flashing OFP — two routes
| Tool | Cost | Bootloader | How |
|---|---|---|---|
| **Realme Flash Tool** (official, portable `RealmeFlash.exe`) | Free | **Must be UNLOCKED** | Browse OFP → phone in fastboot (Power + Vol Down) → "Loading device" → Flash |
| **OppoRealme-OFP-Flash** (community, github.com/italorecife/OppoRealme-OFP-Flash) | Free | Unlocked | Drop .ofp in tool folder → run → pick region → erase userdata → flash all partitions |

**Steps (Realme Flash Tool):**
1. Unlock bootloader first (Realme: in-depth test app; Oppo: fastboot flashing unlock where allowed)
2. Download matching .ofp for exact model + region + Android version
3. Boot phone to fastboot: Power + Vol Down, connect USB
4. Realme Flash Tool → Browse → select .ofp → Loading Device → Flash → Confirm

**Honest limits:**
- Realme Flash Tool does NOT support EDL/9008 — hard-bricked phones need QPST/QFIL or MSM/OPLUS EDL tool
- Official tool historically supported only: Realme 3/3i/X/X2/X2 Pro/X50 Pro; community OFP-Flash tool covers more models
- Flashing wipes all data; region mismatch = soft brick (match RUI version: RUI 2.0→A.x package, RUI 3.0→C.x package)
- Newer ColorOS 14–16 models increasingly require auth/server flashing

---

## 2. Vivo / Realme MTK Servicing (mtkclient)

### mtkclient basics (free, by bkerler)
```
pip install mtkclient
# BROM mode: power OFF phone → hold Vol Up + Power (or Vol Down + Power) → plug USB → release when detected
python mtk r boot boot.img                 # read partition
python mtk w boot boot.img                 # write partition
python mtk e frp                           # erase FRP
python mtk e userdata,metadata             # factory reset
python mtk da seccfg unlock                # bootloader unlock (old chips)
```

### Compatibility — the critical split
| Chipset | Status |
|---|---|
| Old MTK (MT6765, MT6768, MT6833 etc., pre-2022) | **Works in BROM** — full read/write/FRP/format |
| New Dimensity: **MT6781, MT6789, MT6855, MT6886, MT6895, MT6983, MT8985** | BootROM patched (V6 protocol) → BROM exploit dead. Must use `--loader` with V6 loader + **preloader mode** (just plug in, no buttons). Only works on UNFUSED devices |
| DAA / SLA / Remote-Auth enabled chips | **No public free solution** — paid server auth required |

### Vivo/Realme specifics
- **Realme MTK** (Narzo 30 5G, 8 5G, 9 5G, X7 series, GT Neo): mtkclient works on older Dimensity; paid tools (UMT MTK2, UnlockTool) added BROM testpoint support for newer Dimensity 6300/7050/8200 models via brand-specific exploits
- **Vivo MTK** (Y series, iQOO Z1): mtkclient works on older chips; Vivo's newer MTK uses signed preloader — free BROM mostly dead, paid tools required
- **BROM key combos:** Power off → hold **Vol Up + Power** OR **Vol Down + Power** → insert USB. If preloader mode needed: no buttons, just plug in powered-off phone
- **Windows drivers:** stock MTK USB port driver + UsbDk required

**Honest limits:** Free mtkclient covers ~2021 and older MTK well. For 2023+ Oppo/Realme/Vivo Dimensity, expect paid tool (UnlockTool ~annual sub, UMT dongle) or official service.

---

## 3. Oppo ID / Vivo Account Removal — 2026 Honest Status

| Lock | Free method | Reality check |
|---|---|---|
| **Oppo ID / HeyTap account** | None reliable in 2026 | Paid: UnlockTool / server credits; some MTK models via format+flash with paid DA |
| **Vivo account (Funtouch/OriginOS)** | None reliable in 2026 | Paid server unlock; old Y-series MTK sometimes via mtkclient format (model-dependent) |
| **FRP (Google)** | Partially free | mtkclient `e frp` on old MTK; fastboot `erase frp` on some; new security = paid tool |
| **Screen lock (PIN/pattern)** | mtkclient format on old MTK | New chips = paid |

**Rule of thumb for the toolkit:** implement FRP erase via mtkclient/fastboot (free tier), and clearly label Oppo ID / Vivo account removal as **paid-server only** — do not promise free removal. "Free unlock tool" YouTube videos almost always lead to cracked/paid tools or malware.

---

## 4. Realme UI / ColorOS Dialer Codes

Dial in stock dialer app. (Source: XDA ColorOS codes thread + hardreset.info)

| Code | Function |
|---|---|
| `*#800#` | Engineering mode / feedback menu (older ColorOS) |
| `*#899#` | Engineering mode (newer ColorOS/Realme UI) |
| `*#808#` | Manual hardware test menu |
| `*#6776#` | Software version info (Android, kernel, PCB, build) |
| `*#1234#` | Software details |
| `*#888#` | PCB/hardware version |
| `*#900#` | RGB display test |
| `*#06#` | IMEI |
| `*#99#` | Screen always-on test |
| `*#36446337#` | Test function instructions (MediaTek engineer menu on MTK models) |
| `*#801#` | Engineering switch test (dangerous — avoid) |
| `*#807#` | Engineering test mode |

**Toolkit use:** `*#6776#` and `*#1234#` are the most useful — instant model/region/version readout for identifying correct firmware. `*#899#`/`*#808#` for hardware diagnostics (touch, sensors, speaker).

---

## 5. Fastboot / OnePlus MSM Tool — Honest 2026 Status

### Oppo/OnePlus fastboot commands
```
fastboot devices
fastboot flashing unlock          # bootloader unlock (Oppo/OnePlus/Realme)
fastboot flashing lock            # relock
fastboot reboot fastboot          # enter fastbootd (userspace)
fastboot erase frp                # works on some older models only
fastboot -w                       # wipe userdata
```
Oppo/Realme use **standard fastboot**; there is no special "enhanced fastboot" command set — the "enhancement" is in their proprietary flash tools.

### MSM Download Tool (OnePlus) — the real story
- **What it is:** OnePlus/Oppo internal service-center unbrick tool. Flashes via Qualcomm **EDL (9008)** mode — works even on hard bricks and locked bootloaders.
- **Leak reality:** leaked versions exist per-model on XDA (credits: Some_Random_Username, AnonymousWP). Each MSM package is **model-specific** — wrong model = brick.
- **2026 status — deteriorating:**
  - OxygenOS 15 / ColorOS 16 introduced **hardware anti-rollback (QFPROM eFuse)** — old MSM packages now hard-brick fused devices
  - OnePlus removed official downgrade packages (Jan 2026); downgrade "temporarily paused"
  - Newer devices need fresh auth tokens; old leaked tokens expire
- **Successor:** **OPLUS EDL Tool** (v3/v4, 2026) — community EDL flasher for Realme/OnePlus/Oppo. Needs: Device Programmer ELF + Digest + Sign files per chipset, firmware folder, "Merge super" → load rawprogram XMLs → flash in EDL (Vol Up + Vol Down + plug USB)
- **oppo_decrypt `backdoor`:** `python backdoor.py "MsmDownloadTool.exe"` (admin CMD) enables hidden readback in MSM tool

**Honest limits:** MSM is NOT a universal free unbrick anymore. For 2024+ OnePlus/Oppo: verify exact model + firmware version match, expect auth/token hurdles, and warn about anti-rollback bricks. EDL mode entry: power off → hold **Vol Up + Vol Down** → plug USB (shows as Qualcomm HS-USB QDLoader 9008).

---

## 6. ADB Bloatware Package Names (safe-to-disable, no root)

Standard commands (all brands):
```
adb shell pm uninstall -k --user 0 <package>     # remove for current user (reversible)
adb shell pm disable-user --user 0 <package>     # disable (safer)
adb shell cmd package install-existing <package> # restore
adb shell pm enable <package>                     # re-enable
```
Note: `pm uninstall --user 0` does NOT touch OTAs and is undone by factory reset.

### Oppo / Realme / OnePlus (shared OPlus/HeyTap/ColorOS codebase)
```
# App Market / stores
com.oppo.market  com.heytap.market  com.oppo.store
# Browser / media (adware-heavy)
com.heytap.browser  com.heytap.music  com.coloros.video  com.coloros.gallery3d
com.heytap.reader  com.coloros.compass2  com.heytap.smarthome
# Cloud / accounts
com.heytap.cloud  com.heytap.usercenter  com.heytap.openid
# Telemetry / analytics
com.heytap.habit.analysis  com.heytap.mcs  com.oppo.criticallog  com.oppo.logkit
com.coloros.activation  com.oppo.atlas
# Games / pay
com.coloros.gamespace  com.oplus.games  com.heytap.htms  com.oplus.pay
com.coloros.securepay  com.finshell.wallet  com.oplus.vip
# Misc bloat
com.coloros.ocrscanner  com.coloros.floatassistant  com.coloros.focusmode
com.coloros.oppomultiapp  com.heytap.pictorial  com.heytap.themestore
com.oppo.community  com.coloros.oshare  com.coloros.childrenspace
com.nearme.instant.platform  com.coloros.weather.service
```
⚠️ **Do NOT remove** (breaks APK installer): `com.oplus.appdetail`, `com.coloros.securityguard`, `com.coloros.phonemanager` — these gate app installs; removing them can break sideloading.

### Vivo / iQOO (Funtouch / OriginOS)
```
com.vivo.browser  com.android.bbkmusic  com.vivo.appstore  com.bbk.appstore
com.vivo.easyshare  com.iqoo.secure  com.vivo.website  com.vivo.email
com.vivo.translator  com.vivo.smartremote  com.vivo.hiboard
com.vivo.wallet  com.vivo.smartlife  com.vivo.vivokaraoke
com.vivo.weather  com.vivo.numbermark  com.vivo.pem
com.bbk.theme  com.bbk.calendar  com.android.BBKClock
com.yozo.vivo.office  com.vivo.minigamecenter
```
⚠️ Vivo hardened newer OriginOS: `com.vivo.daemonService` and `com.vivo.cota` resist disable on Android 14/15; some packages need the `service call package` trick or downgrade-uninstall method.

---

## 7. Demo / Live Demo Unit Removal

### Method A — ADB (works on most retail demo units where ADB is reachable)
```
# 1. Generic Android retail demo exit broadcast
adb shell am broadcast -a com.android.systemui.demo -e command exit

# 2. Disable the demo packages (brand-specific guesses — list first)
adb shell pm list packages | findstr -i demo
adb shell pm disable-user --user 0 <demo.package>
adb shell pm uninstall -k --user 0 <demo.package>
```

### Method B — demo reset codes (Oppo/Realme/OnePlus retail units)
Retail demo apps often have a hidden settings menu opened with a code (commonly `0110` or model-specific master code) → deactivate video → factory reset from recovery → set up as new. Newer ColorOS 15/16 demo units increasingly require **auth flash** (paid).

### Method C — flash stock firmware
For stubborn units: flash retail .ofp via Realme Flash Tool / OFP-Flash (Section 1) or EDL flash (Section 5). This wipes the demo partition entirely.

**Honest limits:**
- ADB method only works if USB debugging can be enabled on the demo unit (many retail units block it)
- 2024+ Oppo/Realme demo units: free methods shrinking; "auth flash" services are paid
- Only service demo units with proof of legitimate ownership (shop display units being decommissioned)

---

## Toolkit Implementation Checklist (free tier)

- [ ] OFP extract helper: bundle `oppo_decrypt` scripts + guide (extraction only, no flashing liability)
- [ ] mtkclient wrapper: BROM detect → `e frp`, `e userdata,metadata`, partition read/write (old MTK only; warn on V6/DAA chips)
- [ ] Dialer code reference page in-app (`*#6776#`, `*#899#`, `*#808#`, `*#06#`)
- [ ] ADB debloat presets per brand (package lists above, with restore)
- [ ] Demo-mode removal: ADB broadcast + package disable flow
- [ ] EDL driver check + guide (Qualcomm 9008 / MTK VCOM)
- [ ] **Paid-only labels:** Oppo ID, Vivo account, new-chip auth flash — never promise free

## Key Sources
- oppo_decrypt: https://github.com/bkerler/oppo_decrypt
- mtkclient: https://github.com/bkerler/mtkclient
- Realme Flash Tool guide: https://www.thecustomdroid.com/realme-flash-tool/
- OppoRealme-OFP-Flash: https://github.com/italorecife/OppoRealme-OFP-Flash
- ColorOS dialer codes: https://xdaforums.com/t/secret-codes-for-coloros.2844031/
- RealmeUI debloater: https://github.com/abhis699/realmeui-debloater
- Vivo debloat CLI: https://github.com/nxplain-sh/debloat
- OPLUS EDL Tool: https://www.fixbynaem.com/2026/09/realme-oneplus-oppo-via-oplus-edl-tool.html
- Anti-rollback warning: https://consumerrights.wiki/w/Oneplus_phone_update_introduces_hardware_anti-rollback
