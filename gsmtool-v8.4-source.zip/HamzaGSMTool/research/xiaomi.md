# Xiaomi / Redmi / POCO Servicing Research Report
**Prepared for GSM Tool integration — 2026-10-10**
**Audience:** mobile repair technician (Pakistan), Windows PC toolkit
**Focus:** free methods, honest limits, implementable commands

---

## 1. EDL Mode (9008) — Entry Methods

### 1a. `adb reboot edl`
- **Requires:** USB debugging ON, authorized ADB, working system
- **Command:** `adb reboot edl`
- **Verify:** Device Manager → "Qualcomm HS-USB QDLoader 9008 (COMx)"
- **Limit:** Only works if phone boots and ADB is accessible. Useless for bricked/dead phones.

### 1b. `fastboot oem edl` / `fastboot reboot edl`
- **Requires:** bootloader already in fastboot mode (Vol Down + Power)
- **Commands:**
  ```
  fastboot oem edl
  fastboot reboot edl
  ```
- **Limit:** Disabled on many newer Xiaomi models (HyperOS / recent MIUI). Works reliably on older models (Redmi Note 5/6/7 era, Mi A-series). If it returns OKAY but phone just reboots normally, the command is blocked — use test point.

### 1c. Test point (hardware short) — the universal fallback
- **When needed:** bricked phone, locked bootloader + blocked fastboot commands, FRP/Mi-account jobs on Qualcomm models
- **Steps:**
  1. Install Qualcomm HS-USB QDLoader 9008 drivers on PC
  2. Power off phone, remove back cover
  3. Locate the 2 EDL test points on the mainboard (model-specific — search "mobilerdx.com <model> test point"; typical locations: near camera connector on Redmi Note series, near battery connector on POCO)
  4. Short the 2 points with tweezers/copper wire
  5. While shorted, plug USB into PC → Device Manager shows QDLoader 9008
  6. Release the short
- **Limit:** Requires opening the phone (physical disassembly). Test-point diagrams are model-specific — the tool should link to a lookup, not hardcode one diagram.

### 1d. HONEST LIMIT — Xiaomi EDL auth (critical)
- EDL entry is only half the battle. **Flashing in EDL on modern Xiaomi Qualcomm phones requires a Mi Authorized account** (server-side signature check on the firehose loader).
- Free tools (MiFlash) will fail at the auth step on most 2019+ Qualcomm Xiaomi models without authorized credentials.
- **What still works free in EDL:** reading device info, some partition dumps with leaked loaders (model-specific, unreliable).
- **What needs paid/authorized:** full firmware flash, Mi-account removal via EDL on Qualcomm.
- MTK Xiaomi models do NOT use EDL — they use BROM/preloader (see §3).

**Toolkit implementation:** add buttons for `adb reboot edl`, `fastboot oem edl`, `fastboot reboot edl` + a "9008 driver check" (scan Device Manager for QDLoader) + test-point guide links per model.

---

## 2. Mi Account Removal — Honest 2026 Status

### What works FREE
| Method | Works on | Notes |
|---|---|---|
| MTK BROM bypass + format (mtkclient / SP Flash Tool) | Xiaomi **MTK** models with bypassable SLA/DAA (see §3 chip list) | Erase `frp` + `persist`/`nvdata` partitions via `python mtk e frp` etc. Relock risk if phone goes online with Find Device ON |
| Bootloader-unlocked method | Any model with **unlocked bootloader** | Flash TWRP → format data → delete `CloudService.apk` (system/app) and `FindDevice.apk` (system/priv-app) → reboot. No relock after wipe |
| Downgrade + old exploit | Old models only (Mi 6/8/Note 5 era, MIUI < 9.6.x) | Downgrade to vulnerable firmware, remove account, block updates. Mostly obsolete |

### What needs PAID server
- **Qualcomm Xiaomi, locked bootloader, recent security patch:** remote auth-server unlock (e.g., USB Redirector + technician services, ~$5–15 per device). No free method.
- **HyperOS (2024+) Qualcomm models:** effectively server-only for Mi-account removal.
- "Free Mi Account Unlock Tool" downloads on random sites = mostly malware or dead tools. Do NOT bundle.

### Relock warning (tell the user in the tool UI)
- If "Find Device" was ON and the phone connects to Wi-Fi with the original account still linked server-side, the lock **returns**. After removal: skip Wi-Fi during setup, disable Find Device, do NOT factory reset again casually.

**Toolkit implementation:** implement the MTK BROM erase path (free) + the unlocked-bootloader TWRP path (guide), and honestly label Qualcomm/new-patch jobs as "server required".

---

## 3. MTK Xiaomi Auth Bypass (SLA/DAA) via mtkclient

### How it works
`mtkclient` (B. Kerler) exploits the MTK bootrom to disable SLA/DAA auth, then allows partition read/write/erase without Xiaomi's authorized DA.

**Commands (after `pip install mtkclient`):**
```
# Bypass auth (phone off, hold Vol Up + Vol Down, plug USB)
python mtk payload

# Erase FRP / Mi-account-related partitions
python mtk e frp
python mtk e persist       # CAUTION: kills calibration data on some models — backup first
python mtk e nvdata        # CAUTION: contains IMEI calibration — backup first!

# Read partition table / backup
python mtk printgpt
python mtk r persist persist_backup.bin
```

### Chip compatibility (free bypass works)
- **Helio P/G series (old–mid):** MT6761, MT6763, MT6765, MT6768, MT6771, MT6785 — full support
- **Helio G80/G85/G88/G90T/G95/G96:** MT6769 family, MT6781 — supported (G96 added in later mtkclient/bypass builds)
- **Dimensity 700/720/800/820 (MT6833, MT6853, MT6873):** bypass supported (mtkclient + MTK Auth Bypass Tool V22+)
- **Dimensity 900/1100/1200 (MT6877, MT6891Z, MT6893):** partial — older mtkclient builds work; newer firmware revisions may block

### HONEST LIMITS
- **Dimensity 8300/9200/newer (2023+ chips):** no public free bypass. mtkclient cannot handshake — "no DA for this chipset" errors.
- **Poco X6 Pro (Dimensity 8300 Ultra):** confirmed NOT working with mtkclient as of 2025.
- New Xiaomi MTK phones ship with **patched bootrom / SLA enforced** — even some MT6781 units on new firmware resist.
- Xiaomi MTK phones still need a **compatible preloader/DA** — mtkclient bundles generic ones; if handshake fails, that model is out.

**Toolkit implementation:** keep the existing mtkclient integration; add a Xiaomi-MTK chip lookup table (chip → free-bypass yes/no) so the tech sees expectations BEFORE trying.

---

## 4. Bootloader Unlock — Official Process

### Official steps (free, Windows only)
1. On phone: Settings → Mi Account → sign in (same account you'll use on PC)
2. Settings → About phone → tap MIUI/HyperOS version 7× → Developer options
3. Developer options → **OEM unlocking ON**, **USB debugging ON**
4. Developer options → **Mi Unlock status** → **Add account and device** (needs SIM inserted + mobile data ON, Wi-Fi OFF on MIUI 13+)
5. Power off → **Vol Down + Power** → fastboot mode → connect USB
6. Run `miflash_unlock.exe` (Mi Unlock Tool) on PC, sign in with SAME Mi account
7. Click **Unlock** → first attempt intentionally fails → **waiting period starts**

### Waiting period (server-side, CANNOT be bypassed by any tool)
- **MIUI:** 168 hours (7 days)
- **HyperOS:** 72 hours (3 days)
- Some accounts/devices get 14 or 30 days (new accounts, China ROM = 30 days/720h typical)
- **Do NOT during the wait:** remove Mi account, factory reset, or change SIM — resets the timer
- Check remaining time anytime by re-running the unlock tool

### "Bypass" realities
- Modified/old Mi Unlock tools claiming "no wait" do NOT skip Xiaomi's server timer — the key is issued server-side. At best they automate retries.
- MTK-only alternative: on old MTK Xiaomi (unlockable via mtkclient, see §3 list), `python mtk da seccfg unlock` can unlock WITHOUT the wait — but this is chip-limited and trips verified-boot warnings.
- HyperOS added extra requirements: account must be older, community "unlock permission" quiz in some regions (China ROM).

**Toolkit implementation:** guide + "check unlock status" via `fastboot getvar unlocked` / `fastboot oem device-info`. Do NOT promise wait-bypass.

---

## 5. Firmware Sources (free fastboot ROMs)

| Source | URL | Notes |
|---|---|---|
| **Xiaomi Firmware Updater** | `https://xmfirmwareupdater.com/hyperos/` (and `/miui/`) | Community-run, direct official Xiaomi CDN links. Per-device codename pages, Recovery vs **Fastboot** builds clearly labeled. Sizes 6–10 GB. Updated ~daily. **Best source.** |
| Official MIUI site | `https://en.miui.com/` / `https://miui.com` | Official but slow navigation, sometimes region-blocked |
| MiFlash tool | bundled with tool | Official flasher for fastboot ROMs (`.tgz`) |

### Fastboot ROM usage
1. Download the **Fastboot** (not Recovery) `.tgz` for the exact codename + region (e.g. `houji` = Xiaomi 14, `MIXM` = Global, `EUXM` = EEA, `INXM` = India)
2. Extract → open **MiFlash** → "Select" the extracted folder
3. Bottom-right options: **clean all** (safe) / save user data / **clean all and lock** (DANGER: relocks bootloader — never use on serviced phones)
4. Refresh → Flash

**Codename matters:** flashing the wrong region/codename ROM = brick or ARB (anti-rollback) brick. The tool should warn and show `fastboot getvar product` to match.

---

## 6. Xiaomi Dialer Codes

| Code | Function |
|---|---|
| `*#06#` | IMEI + serial number |
| `*#*#4636#*#*` | Phone info / battery / Wi-Fi / usage stats |
| `*#*#64663#*#*` | **Hardware test (CIT)** — sensors, display, battery, speaker, etc. |
| `*#*#6484#*#*` | Hardware test menu (alt) |
| `*#*#6485#*#*` | Battery health / charge cycles |
| `*#*#3646633#*#*` | **Engineering mode (MTK only)** |
| `*#*#2664#*#*` | Touchscreen test |
| `*#*#0588#*#*` | Proximity sensor test |
| `*#*#34971539#*#*` | Camera info |
| `*#*#232338#*#*` | Wi-Fi MAC address |
| `*#*#1472365#*#*` | GPS test |
| `*#*#86583#*#*` | Enable VoLTE carrier check |
| `*#*#86943#*#*` | Enable VoWiFi carrier check |
| `*#*#726633#*#*` | 5G SA carrier check toggle |
| `*#*#7780#*#*` | **Factory reset — DANGEROUS, never auto-run** |
| `*2767*3855#` | **Full firmware reinstall wipe — DANGEROUS** |

**Notes:**
- On MIUI 12+/HyperOS, CIT is also reachable via Settings → All specs → tap **Kernel version** 5–7× (needs internet for some tests).
- Some codes are blocked on newer HyperOS builds — fall back to the Settings route.
- **Toolkit implementation:** a "secret codes" reference tab (display only — never auto-dial the wipe codes).

---

## 7. ADB Bloatware Package Names (Xiaomi)

**Safe removal command (no root, reversible):**
```
adb shell pm uninstall -k --user 0 <package>
```
**Restore any package:**
```
adb shell cmd package install-existing <package>
```
(Use `pm disable-user --user 0` instead of uninstall if you want extra safety — same effect, easier revert via `pm enable`.)

### Ads & telemetry (safe, recommended)
```
com.miui.msa.global        # MIUI System Ads — the main ad daemon
com.miui.analytics         # Analytics / telemetry
com.miui.daemon            # Telemetry daemon
com.miui.systemAdSolution  # Ad framework (newer MIUI/HyperOS)
com.xiaomi.joyose          # Analytics (keep if heavy gaming — minor perf hooks)
```

### Xiaomi bloatware (safe)
```
com.xiaomi.mipicks         # GetApps store (may fail on HyperOS — protected)
com.miui.hybrid            # Quick apps
com.miui.hybrid.accessory
com.miui.yellowpage        # Yellow pages / caller ID spam
com.miui.bugreport         # Mi Feedback
com.miui.cloudbackup
com.miui.cloudservice
com.miui.cloudservice.sysbase
com.miui.micloudsync
com.miui.cleaner           # Mi Cleaner
com.miui.compass
com.miui.fm                # FM radio
com.miui.fmservice
com.miui.player            # Mi Music
com.miui.videoplayer       # Mi Video
com.miui.extraphoto
com.miui.touchassistant    # Quick ball
com.miui.phrase
com.miui.freeform
com.miui.wmsvc
com.miui.notification
com.miui.audiomonitor
com.miuix.editor
com.xiaomi.barrage
com.xiaomi.discover
com.xiaomi.glgm            # Games
com.xiaomi.midrop          # Mi Drop / ShareMe
com.xiaomi.payment         # Mi Pay
com.xiaomi.powerchecker    # Battery saver hooks (safe to remove; system still manages battery)
com.xiaomi.simactivate.service
com.mi.healthglobal        # Mi Health
com.milink.service
com.miui.weather2          # Weather app
com.miui.screenrecorder
com.miui.notes
com.miui.calculator
com.xiaomi.scanner
com.mi.android.globalFileexplorer  # File Manager (only if user OK with alternative)
com.android.browser        # Mi Browser
```

### Third-party preloads (safe)
```
com.facebook.appmanager
com.facebook.services
com.facebook.system
```

### NEVER touch (bootloop risk)
- `com.android.systemui`, `com.android.settings`, `com.android.phone`
- `com.google.android.gms` (Play Services)
- `com.miui.home` (MIUI launcher — unless replacement launcher installed)
- `com.miui.securitycenter` (removing breaks permissions/app management on MIUI)

**HyperOS note:** package names shifted from `com.miui.*` to `com.xiaomi.*` on newer builds; a debloat tool should probe both variants (`pm list packages | grep`).

---

## Summary: what the toolkit can honestly offer for Xiaomi (free)

| Feature | Implementable free | Notes |
|---|---|---|
| EDL entry (adb/fastboot cmds) | ✅ | + 9008 driver check + test-point guide links |
| EDL flashing (Qualcomm) | ⚠️ partial | Entry yes; flashing needs Mi Authorized account on 2019+ models |
| MTK BROM bypass + erase | ✅ | Chip-dependent (§3 table); mtkclient already integrated |
| Mi-account remove (MTK) | ✅ | Via BROM erase; warn about relock |
| Mi-account remove (Qualcomm/new) | ❌ | Server-only — say so in UI |
| Bootloader unlock | ✅ guide | Official tool + wait timer; `fastboot getvar` status check |
| Fastboot ROM flash (MiFlash) | ✅ guide | Link xmfirmwareupdater; codename/region match warning |
| Debloat (ADB) | ✅ | Package lists above; reversible |
| Dialer codes | ✅ | Reference tab |
| Test-point diagrams | 🔗 link | Per-model lookup links (mobilerdx), not hardcoded |

**Bottom line for the user:** Xiaomi servicing splits cleanly — MTK models are the free playground (mtkclient bypass), Qualcomm models hit the authorized-account wall for anything below the OS level. The toolkit should make this split VISIBLE in the UI so the tech never wastes an hour on a job that needs a server.
