"""Tests for release.py -- release builder, token, and one-click publish."""

import json
import os
from unittest import mock

import release


def _make_tool_dir(tmp_path):
    tool = tmp_path / "tool"
    tool.mkdir()
    (tool / "app.py").write_text("# app")
    (tool / "version.py").write_text('__version__ = "7.0"\n')
    (tool / "users.db").write_text("SECRET-DATA")  # must be excluded
    (tool / "update_config.json").write_text(json.dumps(
        {"update_url": "https://hamzaagsm.github.io/gsmtool/version.json"}))
    pycache = tool / "__pycache__"
    pycache.mkdir()
    (pycache / "app.pyc").write_text("x")
    rel = tool / "releases"
    rel.mkdir()
    (rel / "old.zip").write_text("old")  # must not be nested into new zip
    return str(tool)


def test_sanitize_version():
    assert release.sanitize_version("v7.1 beta") == "7.1"
    assert release.sanitize_version(" 8.0 ") == "8.0"
    assert release.sanitize_version("") == ""


def test_site_base_and_upload_url():
    u = "https://hamzaagsm.github.io/gsmtool/version.json"
    assert release.site_base_from_update_url(u) == \
        "https://hamzaagsm.github.io/gsmtool"
    assert release.github_upload_url(u) == \
        "https://github.com/hamzaagsm/gsmtool/upload/main"
    assert release.github_upload_url("") == ""
    assert release.github_upload_url("https://example.com/x.json") == ""


def test_build_release_creates_zip_and_manifest(tmp_path):
    tool = _make_tool_dir(tmp_path)
    ok, msg, paths = release.build_release(tool_dir=tool, new_version="7.1",
                                           notes="test notes")
    assert ok, msg
    assert os.path.isfile(paths["zip"])
    assert os.path.isfile(paths["json"])

    import zipfile
    with zipfile.ZipFile(paths["zip"]) as zf:
        names = zf.namelist()
    assert "app.py" in names
    assert "users.db" not in names, "users.db leak!"
    assert "update_config.json" not in names
    assert not any(n.endswith(".pyc") for n in names)
    assert not any(n.startswith("releases/") for n in names), "nested release!"

    with open(paths["json"], encoding="utf-8") as fh:
        manifest = json.load(fh)
    assert manifest["version"] == "7.1"
    assert manifest["download_url"] == \
        "https://hamzaagsm.github.io/gsmtool/HamzaGSMTool-v7.1.zip"
    assert manifest["notes"] == "test notes"


def test_build_release_needs_update_url(tmp_path):
    tool = tmp_path / "tool2"
    tool.mkdir()
    ok, msg, _ = release.build_release(tool_dir=str(tool), new_version="7.1")
    assert not ok
    assert "Update Settings" in msg


def test_build_release_rejects_empty_version(tmp_path):
    tool = _make_tool_dir(tmp_path)
    ok, msg, _ = release.build_release(tool_dir=tool, new_version="")
    assert not ok


def test_build_release_stamps_version_in_zip(tmp_path):
    tool = _make_tool_dir(tmp_path)
    ok, msg, paths = release.build_release(tool_dir=tool, new_version="7.2")
    assert ok, msg
    import zipfile
    with zipfile.ZipFile(paths["zip"]) as zf:
        vpy = zf.read("version.py").decode("utf-8")
    assert '__version__ = "7.2"' in vpy
    # local version.py must be restored, not left stamped
    with open(os.path.join(tool, "version.py"), encoding="utf-8") as fh:
        assert '__version__ = "7.0"' in fh.read()


def test_token_save_load_roundtrip(tmp_path):
    tf = str(tmp_path / "github_token.json")
    assert not release.token_saved(tf)
    ok, msg = release.save_token("ghp_abc123DEF456", token_file=tf)
    assert ok, msg
    assert release.token_saved(tf)
    assert release.load_token(tf) == "ghp_abc123DEF456"
    # bad token rejected
    ok2, msg2 = release.save_token("not-a-token", token_file=tf)
    assert not ok2
    assert "ghp_" in msg2


def test_parse_repo():
    assert release.parse_repo(
        "https://hamzaagsm.github.io/gsmtool/version.json") == \
        ("hamzaagsm", "gsmtool")
    assert release.parse_repo("") == (None, None)
    assert release.parse_repo("https://example.com/x") == (None, None)


def test_publish_to_github_mocked_api(tmp_path):
    tool = _make_tool_dir(tmp_path)
    tf = os.path.join(tool, "github_token.json")
    ok, _ = release.save_token("ghp_testtoken123", token_file=tf)
    assert ok

    calls = []

    def fake_api(method, url, token, data=None):
        calls.append((method, url, token, data))
        assert token == "ghp_testtoken123"
        assert "/repos/hamzaagsm/gsmtool/contents/" in url
        if method == "GET":
            return 404, {"message": "Not Found"}
        assert method == "PUT"
        assert data["content"]  # base64 body present
        assert data["message"].startswith("Publish v7.3")
        return 201, {"content": {"sha": "abc"}}

    progress_msgs = []
    with mock.patch.object(release, "_gh_api", side_effect=fake_api):
        ok, msg = release.publish_to_github(
            tool_dir=tool, new_version="7.3", notes="mock test",
            progress=progress_msgs.append)
    assert ok, msg
    assert "7.3" in msg
    methods = [c[0] for c in calls]
    assert methods.count("GET") == 2 and methods.count("PUT") == 2
    uploaded = [c[1].rsplit("/contents/", 1)[1] for c in calls if c[0] == "PUT"]
    assert "HamzaGSMTool-v7.3.zip" in uploaded
    assert "version.json" in uploaded
    assert any("Step" in m for m in progress_msgs)


def test_publish_fails_without_token(tmp_path):
    tool = _make_tool_dir(tmp_path)
    ok, msg = release.publish_to_github(tool_dir=tool, new_version="7.3")
    assert not ok
    assert "token" in msg.lower()


def test_publish_rejects_bad_token_401(tmp_path):
    tool = _make_tool_dir(tmp_path)
    tf = os.path.join(tool, "github_token.json")
    release.save_token("ghp_badtoken", token_file=tf)

    def fake_api(method, url, token, data=None):
        return 401, {"message": "Bad credentials"}

    with mock.patch.object(release, "_gh_api", side_effect=fake_api):
        ok, msg = release.publish_to_github(tool_dir=tool, new_version="7.3")
    assert not ok
    assert "expire" in msg or "ghalat" in msg
