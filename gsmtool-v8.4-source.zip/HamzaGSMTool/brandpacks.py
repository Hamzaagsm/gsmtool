"""Brand packs for Hamza GSM Tool v8.3 — dialer codes, bloatware, OTA, demo mode.

Sab data 2026-10 ki research se. Sirf SAFE packages — NEVER-touch list alag hai.
"""

# ---------------- Dialer codes ----------------
# (code, function) — display only, kabhi auto-dial nahi karna
DIALER_CODES = {
    "Samsung": [
        ("*#06#", "IMEI + serial number"),
        ("*#0*#", "Hardware test mode (Auto Blocker off karo agar na khule)"),
        ("*#0808#", "USB settings (MTP/PTP/ADB)"),
        ("*#1234#", "Firmware / CSC info"),
        ("*#0228#", "Battery status / ADC"),
        ("*#9900#", "SysDump (logs)"),
        ("*#12580*369#", "Software + hardware info"),
        ("*#0011#", "Service mode (Exynos/intl)"),
    ],
    "Xiaomi": [
        ("*#06#", "IMEI + serial"),
        ("*#*#64663#*#*", "Hardware test (CIT)"),
        ("*#*#6485#*#*", "Battery health / cycles"),
        ("*#*#4636#*#*", "Phone / battery / WiFi info"),
        ("*#*#3646633#*#*", "Engineering mode (MTK only)"),
        ("*#*#86583#*#*", "VoLTE carrier check"),
    ],
    "Oppo / Realme": [
        ("*#06#", "IMEI"),
        ("*#800#", "Engineering mode (purana ColorOS)"),
        ("*#899#", "Engineering mode (naya)"),
        ("*#808#", "Manual hardware test"),
        ("*#6776#", "Software version (firmware ID ke liye best)"),
        ("*#1234#", "Software details"),
        ("*#888#", "PCB / hardware version"),
    ],
    "Vivo": [
        ("*#06#", "IMEI"),
        ("*#558#", "Engineering / test mode"),
        ("*#2222#", "Hardware version"),
    ],
    "Infinix / Tecno": [
        ("*#06#", "IMEI"),
        ("*#87#", "Hardware test (kuch models)"),
        ("*#3646633#", "MTK engineer menu"),
    ],
    "General": [
        ("*#06#", "IMEI (sab phones)"),
        ("*#*#4636#*#*", "Phone info (kuch brands par blocked)"),
    ],
}

# ---------------- Bloatware (safe-to-remove) ----------------
# Sirf ye packages — NEVER list se door raho
BLOATWARE = {
    "Samsung": [
        "com.samsung.android.game.gamehome",
        "com.samsung.android.game.gametools",
        "com.samsung.android.game.gos",
        "com.samsung.android.bixby.agent",
        "com.samsung.android.bixby.wakeup",
        "com.samsung.android.app.tips",
        "com.samsung.android.themestore",
        "com.samsung.android.arzone",
        "com.samsung.android.aremoji",
        "com.samsung.android.scloud",
        "com.samsung.android.voc",
        "com.sec.android.app.samsungapps",
        "com.samsung.android.oneconnect",
        "com.samsung.android.vmanager",
        "com.facebook.katana",
        "com.facebook.system",
        "com.facebook.appmanager",
        "com.facebook.services",
        "com.microsoft.skydrive",
        "com.microsoft.appmanager",
        "com.spotify.music",
    ],
    "Xiaomi": [
        "com.miui.analytics",
        "com.miui.msa.global",
        "com.miui.daemon",
        "com.miui.bugreport",
        "com.miui.weather2",
        "com.miui.compass",
        "com.miui.player",
        "com.miui.videoplayer",
        "com.miui.notes",
        "com.miui.screenrecorder",
        "com.xiaomi.mipicks",
        "com.xiaomi.glgm",
        "com.xiaomi.midrop",
        "com.xiaomi.scanner",
        "com.xiaomi.payment",
        "com.miui.cleanmaster",
        "com.miui.yellowpage",
        "com.miui.cloudbackup",
        "com.miui.cloudservice",
        "com.miui.micloudsync",
        "com.xiaomi.discover",
        "com.facebook.appmanager",
        "com.facebook.services",
        "com.facebook.system",
    ],
    "Oppo / Realme": [
        "com.coloros.compass2",
        "com.coloros.video",
        "com.coloros.browser",
        "com.oppo.gamecenter",
        "com.oppo.market",
        "com.opos.cs",
        "com.heytap.cloud",
        "com.heytap.pictorial",
        "com.heytap.usercenter",
        "com.heytap.music",
        "com.heytap.browser",
        "com.oppo.ovoicemanager",
        "com.opera.preinstall",
        "com.oplus.games",
        "com.oplus.pay",
        "com.oplus.vip",
        "com.coloros.floatassistant",
        "com.coloros.focusmode",
        "com.heytap.themestore",
        "com.oppo.community",
        "com.facebook.katana",
    ],
    "Vivo": [
        "com.vivo.browser",
        "com.vivo.weather",
        "com.vivo.compass",
        "com.android.bbkmusic",
        "com.vivo.easyshare",
        "com.vivo.website",
        "com.vivo.email",
        "com.vivo.translator",
        "com.vivo.smartremote",
        "com.vivo.hiboard",
        "com.vivo.wallet",
        "com.vivo.weather",
        "com.facebook.appmanager",
    ],
    "Infinix / Tecno": [
        "com.transsion.overlay",
        "com.transsion.aiservice",
        "com.facebook.appmanager",
        "com.facebook.services",
        "com.facebook.system",
    ],
}

# Kabhi touch mat karo — bootloop guaranteed
NEVER_TOUCH = (
    "android",
    "com.android.systemui",
    "com.android.settings",
    "com.android.phone",
    "com.android.server.telecom",
    "com.android.nfc",
    "com.miui.securitycenter",
    "com.miui.home",
    "com.samsung.android.kgclient",
    "com.oplus.appdetail",
    "com.coloros.securityguard",
    "com.coloros.phonemanager",
    "com.sec.android.app.launcher",
)

# ---------------- OTA disable ----------------
# (package, method) — method: "disable" ya "uninstall"
OTA_PACKAGES = {
    "Samsung": [
        ("com.sec.android.soagent", "disable"),
        ("com.wssyncmldm", "disable"),
        ("com.samsung.sdm", "disable"),
        ("com.samsung.sdm.sdmviewer", "disable"),
        ("com.ws.dm", "disable"),
    ],
    "Xiaomi": [
        ("com.android.updater", "disable"),  # UNINSTALL = BOOTLOOP!
    ],
    "Oppo / Realme": [
        ("com.oplus.ota", "disable"),
    ],
    "Vivo": [
        ("com.vivo.updater", "disable"),
        ("com.bbk.updater", "disable"),
    ],
    "Infinix / Tecno": [
        ("com.transsion.systemupdate", "disable"),
    ],
    "General": [
        ("com.google.android.gms.update.SystemUpdateService", "disable"),
    ],
}

# ---------------- Demo / retail mode ----------------
DEMO_PACKAGES = [
    "com.samsung.retaildemo",
    "com.samsung.retail",
    "com.asus.livedemo",
    "com.asus.livedemoservice",
]

# Samsung retail demo exit codes (pehle ye try karo, ADB ki zaroorat nahi)
RETAIL_CODES = ["5444", "24682468", "M729Q16K8546"]

# ---------------- Brand guides (Urdu) ----------------
BRAND_GUIDES = {
    "Samsung": """📱 SAMSUNG — Servicing Guide

🔧 ODIN FLASHING:
1. Samsung USB drivers install karo
2. Phone OFF → Vol Up + Vol Down daba kar USB lagao (Download Mode)
3. Odin me BL/AP/CP/CSC files load karo
4. HOME_CSC = data safe | CSC = full wipe
5. Start → PASS! (5-15 min)

⚠️ BIT RULE: sirf barabar ya nayi BIT wali firmware flash karo!
⚠️ Re-Partition KABHI tick mat karo!

🔓 FRP:
• SamFw FRP Tool (free) — samfw.com se download
• Setup wizard → Emergency Call → *#0*# → tool me Remove FRP

📶 FIRMWARE: samfw.com (free, fast) | Frija tool (Samsung server se direct)

🔒 KG LOCK: Locked (01) ka koi free hal nahi — operator ya paid server.
   Sirf Active/Prenormal purane Android par ADB se dabaya ja sakta hai.
""",
    "Xiaomi": """📱 XIAOMI / REDMI / POCO — Servicing Guide

⚡ EDL MODE (9008):
• adb reboot edl (USB debugging on ho to)
• fastboot oem edl (naye models par blocked ho sakta hai)
• Test point: back cover khol kar 2 points short karo (model-specific)

⚠️ EDL flash 2019+ Qualcomm par Mi Authorized account mangta hai (paid)!

🔓 MI ACCOUNT:
• MTK models: mtkclient BROM → erase frp (FREE purane chips par)
• Bootloader unlocked: TWRP → CloudService.apk + FindDevice.apk delete
• Qualcomm naye: paid server ($5-15)

🔧 MTK BYPASS (purane Helio/Dimensity):
python mtk payload → python mtk e frp

🔓 BOOTLOADER UNLOCK: Mi Unlock tool → 168h wait (server-side, koi bypass nahi!)

📶 FIRMWARE: xmfirmwareupdater.com/hyperos (free, official CDN)
""",
    "Oppo / Realme": """📱 OPPO / REALME / ONEPLUS — Servicing Guide

📦 OFP FIRMWARE:
• ofp_qc_decrypt.py / ofp_mtk_decrypt.py (bkerler, free)
• Realme Flash Tool (official) — unlocked bootloader chahiye

🔧 MTK (purane chips): mtkclient BROM → e frp / e userdata,metadata
⚠️ Naye Dimensity (2023+): paid tools (UMT/UnlockTool)

🔓 OPPO ID / VIVO ACCOUNT: koi reliable free hal nahi — paid server only.
   "Free unlock" YouTube videos = crack/malware se bacho!

📶 MSM TOOL: model-specific leaked packages; galat model = brick!
   OOS15/ColorOS16 par anti-rollback eFuse — purane packages brick kar denge.
""",
    "Vivo": """📱 VIVO / iQOO — Servicing Guide

🔧 MTK models (Y series, purane): mtkclient BROM free
⚠️ Naye models: paid server auth

🔓 VIVO ACCOUNT: koi reliable free hal nahi — paid server only.

📦 Bloatware: com.vivo.browser, com.vivo.appstore waghera safe remove.
   com.vivo.daemonService / com.vivo.cota (Android 14/15) ko force mat karo.
""",
    "Infinix / Tecno": """📱 INFINIX / TECNO / ITEL (Transsion) — Servicing Guide

🔧 YE SAB SE ASAN BRAND HAI — zyadatar MTK/SPD!

• FRP: [BROM] Erase FRP (MTKClient) ya [SPD] Erase FRP
• Factory reset: [BROM] Factory Reset
• Transsion ID: [ADB] MDM Scan & Fix se packages disable
• Bloatware: com.transsion.overlay, com.transsion.aiservice safe remove

⚠️ com.transsion.hilauncher (launcher) sirf tab hatao jab dusra
   launcher (Nova/Microsoft) pehle se installed ho!

📶 Dialer: *#06# (IMEI), *#3646633# (MTK engineer)
""",
    "iPhone": """🍎 iPHONE — Honest Guide

✅ 3uTools (3u.com, FREE): flashing, backup, battery info, exit recovery
✅ ipsw.me: firmware + signing status (green = installable)
✅ DFU: Vol Up → Vol Down → Side 10s → Side+Vol Down 5s → sirf Vol Down
✅ Shift+Restore: IPSW download → iTunes me Shift+Restore

❌ iCLOUD LOCK ka koi free software hal NAHI (iPhone X+).
   Asli hal: (1) original owner icloud.com se remove kare
            (2) Apple support receipt ke saath
            (3) iforgot.apple.com
   YouTube/Telegram "paid unlock" = 99% fraud. Customer ko bachao!

⚠️ Jailbreak sirf iPhone X ya purane (palera1n). XS/XR+ = impossible.
⚠️ Face ID hardware kharab ho to sirf Apple theek kar sakta hai.
""",
}
