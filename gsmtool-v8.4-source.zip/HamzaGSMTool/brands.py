"""Brand profiles for the Pakistan mobile market.

Each profile gives: typical chipsets, typical key combos for service modes,
which external tool handles deep work (BROM/EDL flashing), and honest notes
about FRP / IMEI / MDM on that brand.

Key combos are TYPICAL -- they vary by model and year. Always verify for the
exact model in hand. Nothing here replaces the phone's official firmware.
"""

BRANDS = {
    "tecno": {
        "name": "Tecno",
        "chipsets": ["MediaTek (aksar)", "Unisoc/SPD (kuch models)"],
        "modes": {
            "Recovery": "Power + Vol Up",
            "BROM (MTK)": "Phone off, Vol Up/Down + USB lagao",
            "Download (SPD)": "Phone off, Vol Down + USB lagao",
            "META mode": "adb reboot meta (command se)",
        },
        "external_tools": ["SP Flash Tool (MTK)", "SPD Upgrade Tool (Unisoc)",
                           "UMT / Chimera (paid)"],
        "frp_note": "MTK models par BROM-based FRP tools; SPD models par PAC flashing.",
        "imei_note": "META mode + vendor Modem META tool se. Sirf ORIGINAL IMEI restore karo.",
        "mdm_note": "MDM Fix Tool (MTK) ya UMT me Infinix/Tecno MDM reset.",
    },
    "infinix": {
        "name": "Infinix",
        "chipsets": ["MediaTek (aksar)", "Unisoc/SPD (kuch models)"],
        "modes": {
            "Recovery": "Power + Vol Up",
            "BROM (MTK)": "Phone off, Vol Up/Down + USB lagao",
            "Download (SPD)": "Phone off, Vol Down + USB lagao",
            "META mode": "adb reboot meta (command se)",
        },
        "external_tools": ["SP Flash Tool (MTK)", "SPD Upgrade Tool (Unisoc)",
                           "UMT / Chimera (paid)"],
        "frp_note": "MTK models par BROM-based FRP tools; SPD models par PAC flashing.",
        "imei_note": "META mode + vendor Modem META tool se. Sirf ORIGINAL IMEI restore karo.",
        "mdm_note": "MDM Fix Tool (MTK) ya UMT me Infinix MDM Reset option.",
    },
    "itel": {
        "name": "Itel",
        "chipsets": ["Unisoc/SPD (aksar)", "MediaTek (kuch models)"],
        "modes": {
            "Recovery": "Power + Vol Up",
            "Download (SPD)": "Phone off, Vol Down + USB lagao",
            "BROM (MTK)": "Phone off, Vol Up/Down + USB lagao",
        },
        "external_tools": ["SPD Upgrade Tool (Unisoc)", "SP Flash Tool (MTK)"],
        "frp_note": "SPD models: PAC firmware flash; MTK models: BROM FRP reset.",
        "imei_note": "SPD: WriteIMEI tool / Research Tool; MTK: META mode + Modem META.",
        "mdm_note": "MDM Fix Tool Tecno/Infinix/Itel ko support karta hai.",
    },
    "samsung": {
        "name": "Samsung",
        "chipsets": ["Exynos / Qualcomm / MediaTek (model par munhasir)"],
        "modes": {
            "Download (Odin)": "Vol Up + Vol Down ek saath, phir USB lagao (naye models)",
            "Recovery": "Power + Vol Up",
        },
        "external_tools": ["Odin (official flashing)", "Chimera / UMT (paid, KG/MDM)",
                           "SamFW Tool (free, FRP helpers)"],
        "frp_note": "Latest security par FRP mushkil -- dedicated tools (paid) darkar.",
        "imei_note": "Samsung me IMEI repair aam tor par supported NAHI (cert/patch based, risky).",
        "mdm_note": "KG/MDM lock: Chimera/UMT paid tools; kuch free KG tools mojood.",
    },
    "xiaomi": {
        "name": "Xiaomi / Redmi / Poco",
        "chipsets": ["Qualcomm (aksar)", "MediaTek (kuch models)"],
        "modes": {
            "Fastboot": "Vol Down + Power",
            "Recovery": "Vol Up + Power",
            "EDL": "adb reboot edl ya test point",
        },
        "external_tools": ["Mi Flash Tool (fastboot flashing)", "QFIL (Qualcomm EDL)",
                           "SP Flash Tool (MTK models)"],
        "frp_note": "Mi Account lock alag masla hai -- FRP se zyada sakht.",
        "imei_note": "Qualcomm: QCN backup/restore (QFIL/QPST); MTK: META mode.",
        "mdm_note": "MDM kam aam; Mi Account/FRP zyada relevant.",
    },
    "oppo": {
        "name": "Oppo",
        "chipsets": ["MediaTek / Qualcomm (model par munhasir)"],
        "modes": {
            "Recovery": "Power + Vol Down (aksar)",
            "Fastboot/Bootloader": "adb reboot bootloader",
        },
        "external_tools": ["Official MSM Download Tool (authorized accounts)",
                           "UMT / Chimera (paid)"],
        "frp_note": "Oppo ke locks sakht hain; authorized/paid tools darkar.",
        "imei_note": "META mode (MTK) ya QCN (Qualcomm); original IMEI hi restore karo.",
        "mdm_note": "Kam aam; FRP/ID locks zyada relevant.",
    },
    "vivo": {
        "name": "Vivo",
        "chipsets": ["MediaTek / Qualcomm (model par munhasir)"],
        "modes": {
            "Recovery": "Power + Vol Up (aksar)",
            "Fastboot": "Power + Vol Down (aksar)",
        },
        "external_tools": ["UMT / Chimera (paid)", "SP Flash Tool (MTK models)"],
        "frp_note": "Naye models par FRP sakht; paid tools darkar.",
        "imei_note": "META mode (MTK) ya QCN (Qualcomm).",
        "mdm_note": "Kam aam.",
    },
    "realme": {
        "name": "Realme",
        "chipsets": ["MediaTek / Qualcomm (model par munhasir)"],
        "modes": {
            "Recovery": "Power + Vol Down (aksar)",
            "Fastboot": "Power + Vol Up (aksar, model par munhasir)",
        },
        "external_tools": ["Realme Flash Tool", "QFIL (Qualcomm)", "SP Flash Tool (MTK)"],
        "frp_note": "Oppo lineage -- locks sakht, paid tools aam.",
        "imei_note": "META mode (MTK) ya QCN (Qualcomm).",
        "mdm_note": "Kam aam.",
    },
    "motorola": {
        "name": "Motorola",
        "chipsets": ["Qualcomm (aksar)", "MediaTek (kuch)"],
        "modes": {
            "Fastboot": "Vol Down + Power",
            "Recovery": "Vol Up + Power",
        },
        "external_tools": ["Official fastboot firmware (motorola.com)",
                           "QFIL (EDL, kuch models)"],
        "frp_note": "Fastboot flashing se FRP bypass kabhi kaam karta hai (model par munhasir).",
        "imei_note": "QCN backup/restore.",
        "mdm_note": "Moto MDM: free MDM tools me support (2026 tools).",
    },
    "nokia": {
        "name": "Nokia (HMD)",
        "chipsets": ["Qualcomm / Unisoc (model par munhasir)"],
        "modes": {
            "Fastboot": "Vol Down + Power (aksar)",
            "Recovery": "Vol Up + Power (aksar)",
        },
        "external_tools": ["Official OST LA (limited)", "Chimera (paid, kuch models)"],
        "frp_note": "Bootloader locked rehta hai -- options mehdood.",
        "imei_note": "Mehdood support.",
        "mdm_note": "Kam aam.",
    },
    "oneplus": {
        "name": "OnePlus",
        "chipsets": ["Qualcomm (aksar)", "MediaTek (kuch)"],
        "modes": {
            "Fastboot": "Vol Down + Power",
            "Recovery": "Vol Up + Power",
            "EDL": "adb reboot edl",
        },
        "external_tools": ["Official MSM Tool (authorized)", "QFIL (EDL)"],
        "frp_note": "EDL flashing se hal ho sakta hai (authorized MSM).",
        "imei_note": "QCN backup/restore.",
        "mdm_note": "Kam aam.",
    },
    "huawei": {
        "name": "Huawei (purane models)",
        "chipsets": ["Kirin (purane)", "Qualcomm/MediaTek (naye)"],
        "modes": {
            "Fastboot": "Vol Down + USB (aksar)",
            "Recovery": "Vol Up + Power",
        },
        "external_tools": ["Official dload (SD card)", "Chimera (paid, kuch)"],
        "frp_note": "Kirin models par options mehdood.",
        "imei_note": "Mehdood support.",
        "mdm_note": "Kam aam.",
    },
    "qmobile": {
        "name": "QMobile (purane/local models)",
        "chipsets": ["MediaTek / Spreadtrum (aksar)"],
        "modes": {
            "Recovery": "Power + Vol Up (aksar)",
            "BROM (MTK)": "Phone off, Vol Up/Down + USB lagao",
            "Download (SPD)": "Phone off, Vol Down + USB lagao",
        },
        "external_tools": ["SP Flash Tool (MTK)", "SPD Upgrade Tool (SPD)"],
        "frp_note": "Purane Android par aasan (BROM/PAC methods).",
        "imei_note": "MTK: META mode; SPD: WriteIMEI/Research Tool.",
        "mdm_note": "Kam aam.",
    },
}


def brand_names():
    return sorted(BRANDS.keys())


def cheat_sheet(key):
    """Return a readable cheat sheet string for a brand key."""
    b = BRANDS.get(key.lower())
    if not b:
        return f"Brand '{key}' nahi mila. Available: {', '.join(brand_names())}"
    lines = [f"=== {b['name']} ===",
             f"Chipsets: {', '.join(b['chipsets'])}",
             "Service modes (aam -- model verify karo):"]
    for mode, combo in b["modes"].items():
        lines.append(f"  - {mode}: {combo}")
    lines.append(f"External tools: {', '.join(b['external_tools'])}")
    lines.append(f"FRP: {b['frp_note']}")
    lines.append(f"IMEI: {b['imei_note']}")
    lines.append(f"MDM: {b['mdm_note']}")
    return "\n".join(lines)


IMEI_WORKFLOW = """IMEI repair -- honest workflow (MTK phones):

1. Is tool se: Device tab > 'Reboot: meta' -- phone META mode me jayega.
2. PC par vendor ka Modem META / Maui META tool kholo (MediaTek ka official
   servicing utility -- ye is toolkit ka hissa NAHI).
3. META tool me phone detect hoga; wahan NVRAM se IMEI read/write hota hai.
4. HAMESHA pehle NVRAM backup lo.

QANOONI WARNING: Sirf phone ka ORIGINAL IMEI restore karo. Pakistan me IMEI
change/tamper karna illegal hai (PTA). Ghalat IMEI wala phone block ho sakta hai.
"""

FRP_WORKFLOW = """FRP -- honest picture:

- Agar phone me ADB access mil jata hai (USB debugging on): is tool se scan
  karke relevant apps/settings check kiye ja sakte hain.
- Latest security patch par FRP bypass ke liye aam tor par chipset-level
  tools darkar hote hain (BROM/EDL exploits) -- ye paid tools (UMT, Chimera,
  Octoplus) ya model-specific free tools ka kaam hai, is toolkit ka nahi.
- Samsung: Odin + FRP helpers (SamFW). MTK: BROM FRP reset. SPD: PAC flash.
"""

SPD_NOTES = """SPD / Unisoc phones ke liye notes:

- Download mode: phone off karke Vol Down + USB (aam).
- Flashing ke liye SPD Upgrade Tool / Research Tool + .pac firmware chahiye
  (ye is toolkit ka hissa nahi -- alag download hota hai).
- Is toolkit me: ADB par based sare features SPD phones par bhi kaam karte
  hain (device info, reboot, MDM scan/disable), kyunke Android par ADB same hai.
- Driver: 'SPRD U2S Diag' / Unisoc USB drivers install karo.
"""
