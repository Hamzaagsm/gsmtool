@echo off
title Hamza GSM Tool - One Click UPDATER
set "HERE=%~dp0"
echo ============================================
echo   Hamza GSM Tool - One Click UPDATER
echo ============================================
echo.
echo Nayi wali ZIP file (HamzaGSMTool-v*.zip)
echo is folder me rakho:
echo   %HERE%
echo.
echo Tumhare users/passwords MEHFOOZ rahenge
echo (users.db ka backup liya jayega).
echo.
pause

:: newest update zip in this folder
set "ZIP="
for /f "delims=" %%f in ('dir /b /o-n "%HERE%HamzaGSMTool-v*.zip" 2^>nul') do (
    if not defined ZIP set "ZIP=%%f"
)
if not defined ZIP (
    echo.
    echo ERROR: is folder me koi HamzaGSMTool-v*.zip nahi mili.
    echo Pehle nayi ZIP yahan copy karo, phir dobara chalao.
    pause
    exit /b 1
)
echo Update mil gayi: %ZIP%
echo.

:: backup users.db (accounts safety)
set "BACKUP=%TEMP%\HamzaGSM_users_backup.db"
if exist "%HERE%users.db" (
    copy /y "%HERE%users.db" "%BACKUP%" >nul
    echo [OK] users.db backup ho gaya.
) else (
    echo [..] users.db nahi mili (pehli install lagti hai) -- koi baat nahi.
)

:: extract to temp
set "TMPD=%TEMP%\HamzaGSMUpdate"
rmdir /s /q "%TMPD%" 2>nul
mkdir "%TMPD%" 2>nul
echo Files extract ho rahi hain...
powershell -NoProfile -Command "Expand-Archive -Path '%HERE%%ZIP%' -DestinationPath '%TMPD%' -Force"
if not exist "%TMPD%\HamzaGSMTool\app.py" (
    echo.
    echo ERROR: ZIP ka structure samajh nahi aaya.
    pause
    exit /b 1
)

:: copy new files over (users.db is NOT in the zip, so accounts survive)
xcopy /y /e "%TMPD%\HamzaGSMTool\*" "%HERE%" >nul
echo [OK] Nayi files copy ho gayin.

:: restore users.db if somehow missing
if not exist "%HERE%users.db" (
    if exist "%BACKUP%" (
        copy /y "%BACKUP%" "%HERE%users.db" >nul
        echo [OK] users.db restore kar di.
    )
)

rmdir /s /q "%TMPD%" 2>nul
echo.
echo ============================================
echo   UPDATE COMPLETE!
echo   Tool dobara kholo -- sab kuch naya hoga,
echo   aur tumhare users waise ke waise.
echo ============================================
pause
