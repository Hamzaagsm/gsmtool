"""Base directory helper.

Normal run: script wali folder.
PyInstaller exe (frozen): exe wali folder -- warna users.db temp folder me
banegi aur restart par sab khatam!
"""

import os
import sys


def base_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))
