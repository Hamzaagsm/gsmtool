"""Anti-Crack checker for Hamza GSM Tool v8.4.

Tecno/Infinix/Itel (Transsion) phones par "Anti-Crack" / "Trigger_P7" /
"Unauthorized Repair" lock lag sakta hai agar:
- IMEI/serial change kiya gaya
- Ghalat firmware flash hui
- System modify hua

Ye checker do modes me kaam karta hai:

1. ADB MODE (phone ON, USB debugging enabled):
   Model, brand, Android version parh kar batata hai ke is model
   par anti-crack system hai ya nahi — IMEI kaam se PEHLE check karo.

2. BROM/INFO MODE (phone OFF/locked, Vol buttons + USB):
   Chip info se pata chalta hai ke phone anti-crack trigger state
   me hai ya koi aur masla (bootloop, etc.)

Sirf original identity restore ke liye guidance. Koi bypass/crack nahi.
"""

# Known anti-crack Transsion models (series level — naye Android 14/15 models)
# Ye list barhti rehti hai; naya model mile to add karo.
ANTICRACK_SERIES = {
    "infinix": [
        "Hot 40", "Hot 40i", "Hot 40 Pro",
        "Hot 50", "Hot 50i", "Hot 50 Pro", "Hot 50 Pro+",
        "Hot 60", "Hot 60i", "Hot 60 Pro", "Hot 60 Pro+",
        "Note 40", "Note 40 Pro", "Note 40X",
        "Note 50", "Note 50 Pro", "Note 50s", "Note 50X",
        "Smart 8", "Smart 9",
        "GT 20", "GT 30",
    ],
    "tecno": [
        "Spark 20", "Spark 20C", "Spark 20 Pro",
        "Spark 30", "Spark 30C", "Spark 30 Pro",
        "Spark 40", "Spark 40C", "Spark 40 Pro", "Spark 40 Pro+",
        "Camon 30", "Camon 30s", "Camon 40", "Camon 40 Pro",
        "Pova 6", "Pova 6 Pro", "Pova 7",
        "Pop 8", "Pop 9",
    ],
    "itel": [
        "P55", "P65",
        "S23", "S25",
        "A70", "A80",
    ],
}

# Android versions jahan anti-crack zyada strict hai
RISKY_ANDROID = (14, 15, 16)


def check_model(model, brand="", android_version=0):
    """Model check karo. Returns (risk_level, message_urdu).

    risk_level: 'high' | 'medium' | 'low'
    """
    model_l = (model or "").lower()
    brand_l = (brand or "").lower()

    # Brand detect karo
    detected = ""
    for b in ("infinix", "tecno", "itel"):
        if b in brand_l or b in model_l:
            detected = b
            break

    if not detected:
        return ("low",
                f"Model: {model}\n"
                "Ye Transsion (Infinix/Tecno/Itel) device nahi lagta.\n"
                "Anti-crack ka khatra kam hai, phir bhi ehtiyat karo.")

    # Series match karo
    matched = ""
    for series in ANTICRACK_SERIES.get(detected, []):
        if series.lower() in model_l:
            matched = series
            break

    ver_txt = f"Android {android_version}" if android_version else "Android version maloom nahi"

    if matched:
        risk = "high" if (android_version in RISKY_ANDROID or not android_version) else "medium"
        return (risk,
                f"⚠️ ANTI-CRACK RISK: {risk.upper()}\n\n"
                f"Model: {model} ({detected.title()} {matched})\n"
                f"{ver_txt}\n\n"
                "Is model par anti-crack system ACTIVE hai!\n\n"
                "⛔ IMEI/serial MAT change karo\n"
                "⛔ Ghalat firmware MAT flash karo\n"
                "✅ Sirf official firmware use karo\n"
                "✅ IMEI 000000 ho to sirf DABBE wala original likho")
    else:
        return ("medium",
                f"Model: {model} ({detected.title()})\n"
                f"{ver_txt}\n\n"
                "Purana model hai — anti-crack ka khatra kam,\n"
                "lekin Android 14+ par ehtiyat zaroori hai.\n\n"
                "✅ Kaam se pehle serial/IMEI ka backup lo")


def brom_diagnose(chip_name="", brom_output=""):
    """BROM mode se mili info se diagnose karo.

    Returns (state, message_urdu). state: 'anticrack' | 'ok' | 'unknown'
    """
    out = (brom_output or "").lower()
    chip = (chip_name or "").lower()

    # Anti-crack trigger ke nishaniyan
    triggers = ["trigger_p7", "trigger p7", "unauthorized repair",
                "anti-crack", "anti crack", "sej", "sbc enabled"]
    for t in triggers:
        if t in out:
            return ("anticrack",
                    "🔒 ANTI-CRACK TRIGGER MILA!\n\n"
                    f"Chip: {chip_name or 'maloom nahi'}\n"
                    f"Nishani: '{t}'\n\n"
                    "Phone anti-crack lock me hai.\n\n"
                    "HAL:\n"
                    "1. Android Win Tool (FREE) → Anti-Crack Remove\n"
                    "   (Free Tools section se kholo)\n"
                    "2. Ya Phoenix Service Tool (paid credits)\n\n"
                    "⛔ Dobara IMEI change mat karna!")

    if chip:
        return ("unknown",
                f"Chip detect hua: {chip_name}\n\n"
                "BROM se phone connect ho gaya — achhi khabar!\n"
                "Anti-crack ka wazeh nishan nahi mila.\n\n"
                "Agar phone recovery me 'Unauthorized Repair' dikhaye\n"
                "to Anti-Crack Remove use karo.")

    return ("unknown",
            "BROM se koi info nahi mili.\n\n"
            "Check karo:\n"
            "1. Phone OFF hai?\n"
            "2. Vol Up+Down daba kar USB lagaya?\n"
            "3. MTK VCOM drivers installed hain?")


def fix_guide_urdu():
    """Anti-crack fix ka mukammal guide (Urdu)."""
    return """🔧 ANTI-CRACK FIX GUIDE (Tecno/Infinix/Itel)

AGAR LOCK LAG CHUKA HAI (recovery me "Unauthorized Repair"):

METHOD 1 — FREE (Android Win Tool):
1. Free Tools → Android Win Tool kholo
2. Download karo: github.com/Android-Win-Tools-Update
3. Install → Register (free)
4. Phone OFF karo, Vol buttons + USB se connect
5. "Anti-Crack Remove" dabao
6. Phone normal boot hoga ✅

METHOD 2 — PAID (Phoenix Service Tool):
1. phoenixservicetool.com se credits lo
2. Trigger_P7 / Unauthorized Repair fix
3. Naye Android 15 models supported

METHOD 3 — Videos (step by step):
• Free Method 2026: youtube.com/watch?v=Ks-91bPlmEs
• Trigger_P7 Fix: youtube.com/watch?v=3VgQAPjwHPY

⚠️ AHEM BAAT:
• Cherh-khani kisi aur ne ki ho, customer tumhare paas aaye —
  pehle CHECK karo, phir FIX karo
• Fix ke baad IMEI 000000 aaye to DABBE wala original likho
• Dobara IMEI change karoge to lock WAPIS lagega!

BACHAV (pehle se):
• IMEI kaam se pehle Anti-Crack Check zaroor karo
• Serial/IMEI ka backup lo
• Sirf official firmware flash karo
"""
