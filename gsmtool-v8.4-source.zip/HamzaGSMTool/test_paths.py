"""Tests for paths.base_dir (exe-safe base directory)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import paths

# normal (non-frozen) run: script wali folder
assert paths.base_dir() == os.path.dirname(os.path.abspath(paths.__file__))

# frozen simulation: sys.frozen + sys.executable
real_frozen = getattr(sys, "frozen", None)
real_exe = sys.executable
try:
    sys.frozen = True
    sys.executable = "/fake/dir/HamzaGSMTool.exe" if os.name != "nt" else \
        "C:\\fake\\dir\\HamzaGSMTool.exe"
    got = paths.base_dir()
    assert got == os.path.dirname(os.path.abspath(sys.executable)), got
    # users.db kabhi temp/_MEI me nahi jani chahiye
    assert "_MEI" not in got and "Temp" not in got, got
finally:
    if real_frozen is None:
        del sys.frozen
    else:
        sys.frozen = real_frozen
    sys.executable = real_exe

print("All paths tests passed.")
