"""Tests for edl.py -- brand coverage, warnings, search helper."""

import edl

# must match the 13 brand keys used by the app
BRAND_KEYS = ["samsung", "xiaomi", "tecno", "infinix", "itel", "oppo", "vivo",
              "realme", "motorola", "nokia", "oneplus", "huawei", "qmobile",
              "apple"]


def test_all_brands_covered():
    for key in BRAND_KEYS:
        assert key in edl.BRAND_EDL, f"missing EDL data for {key}"
        info = edl.BRAND_EDL[key]
        assert info["mode"] and info["keys"] and info["notes"]


def test_brand_edl_text():
    txt = edl.brand_edl_text("samsung")
    assert "Download" in txt and "Odin" in txt
    assert "nahi mila" in edl.brand_edl_text("nonexistent")


def test_warnings_strong():
    w = edl.TESTPOINT_WARNINGS
    assert "DEAD" in w and "MODEL" in w


def test_search_url_encodes_model():
    url = edl.testpoint_search_url("X6887")
    assert url.startswith("https://www.google.com/search?q=")
    assert "X6887" in url
    assert "test+point" in url or "test%20point" in url


def test_frp_notes_honest():
    assert "100%" in edl.FRP_NOTES  # the no-false-promise line
