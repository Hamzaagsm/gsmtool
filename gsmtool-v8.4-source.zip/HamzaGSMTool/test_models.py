"""Sanity tests for models.py -- no phone needed."""

from brands import brand_names
from models import MODELS, get_models, model_count, search_models

# every brand in brands.py must have a model list with >= 5 entries
for key in brand_names():
    assert key in MODELS, f"models missing brand: {key}"
    assert model_count(key) >= 5, f"{key}: only {model_count(key)} models"

required = ("model", "code", "chipset")
seen = set()
for key, lst in MODELS.items():
    for m in lst:
        for field in required:
            assert field in m, f"{key}: entry missing {field}"
            assert isinstance(m[field], str), f"{key}: {field} not a string"
        assert m["model"].strip(), f"{key}: empty model name"
        assert m["chipset"].strip(), f"{key}: empty chipset"
        dup = (key, m["model"], m["code"])
        assert dup not in seen, f"duplicate entry: {dup}"
        seen.add(dup)

# search behavior
res = search_models("infinix", "x6887")
assert len(res) == 1 and res[0]["model"] == "Note Edge", res
assert search_models("samsung", "") == get_models("samsung")
assert search_models("samsung", "zzz-no-match") == []
assert get_models("no-such-brand") == []

total = sum(model_count(k) for k in brand_names())
print(f"All model tests passed ({total} models across {len(brand_names())} brands).")
