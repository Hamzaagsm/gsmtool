@echo off
title Hamza GSM Tool - One Click Installer
echo ============================================
echo   Hamza GSM Tool - One Click Installer
echo ============================================
echo.
echo Ye installer sab kuch khud karega:
echo  1. Python install (agar nahi hai)
echo  2. platform-tools download (adb/fastboot)
echo  3. Desktop par shortcut banana
echo.
pause

:: ---------- 1. Python check ----------
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo Python nahi mila. winget se install ho raha hai...
    echo (Agar winget na ho to python.org se manually install karo,
    echo  "Add python.exe to PATH" tick zaroor karna)
    echo.
    winget install -e --id Python.Python.3.12 --silent --accept-source-agreements --accept-package-agreements
    set "PATH=%LocalAppData%\Programs\Python\Python312\;%LocalAppData%\Programs\Python\Python312\Scripts\;%PATH%"
)
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo ERROR: Python install nahi ho saka.
    echo python.org se manually install karo ("Add python.exe to PATH" tick karo)
    echo phir INSTALL.bat dobara chalao.
    pause
    exit /b 1
)
echo [OK] Python mil gaya.
echo.

:: ---------- 2. platform-tools ----------
if not exist "%~dp0platform-tools\adb.exe" (
    echo platform-tools download ho raha hai (Google official)...
    powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://dl.google.com/android/repository/platform-tools-latest-windows.zip' -OutFile '%~dp0platform-tools.zip'"
    if %errorlevel% neq 0 (
        echo ERROR: download fail. Internet check karo aur dobara chalao.
        pause
        exit /b 1
    )
    powershell -NoProfile -Command "Expand-Archive -Path '%~dp0platform-tools.zip' -DestinationPath '%~dp0' -Force"
    del "%~dp0platform-tools.zip"
)
if not exist "%~dp0platform-tools\adb.exe" (
    echo ERROR: adb.exe nahi mila. Google se "platform-tools" download karke
    echo is folder me extract karo, phir dobara chalao.
    pause
    exit /b 1
)
echo [OK] platform-tools ready.
echo.

:: ---------- 3. Desktop shortcut ----------
set "TOOLSDIR=%~dp0"
set "DESK=%USERPROFILE%\Desktop\Hamza GSM Tool.bat"
(
echo @echo off
echo title Hamza GSM Tool
echo cd /d "%TOOLSDIR%"
echo python app.py
echo pause
) > "%DESK%"
echo [OK] Desktop shortcut ban gaya: "Hamza GSM Tool.bat"
echo.

:: ---------- 4. Quick self test ----------
echo Self test...
python test_features.py
python test_brands.py
echo.

echo ============================================
echo   INSTALL COMPLETE!
echo.
echo   Ab Desktop par "Hamza GSM Tool.bat"
echo   par double-click karo -- tool khul jayega.
echo.
echo   Phone connect karne se pehle:
echo   - USB drivers install karo (chipset ke hisaab se)
echo   - Phone me USB debugging ON karo
echo ============================================
pause
