"""Driver helper for Hamza GSM Tool v7 (stdlib only).

Honest scope -- is module me koi driver BUNDLED nahi hai. Chipset vendor
drivers (MTK / SPD / Qualcomm) proprietary hain aur unke official flashing
tool packages ke sath aate hain. Ye module deta hai:

  * official download links (Google USB driver, Samsung USB driver,
    Android platform-tools) -- verified official pages
  * MTK / SPD / Qualcomm ke liye honest guidance (kahan se milenge)
  * check_drivers(): adb/fastboot + mashhoor USB drivers ki maujoodgi
    report karta hai (Windows par pnputil se; baqi OS par ADB/Fastboot tak)
"""

import platform
import subprocess

# (name, purpose, url, kind, note)
# kind: "official" = verified official download page
#       "bundled"  = koi public download nahi; flashing tool package ke sath
DRIVER_ROWS = [
    (
        "Google USB Driver (ADB)",
        "Google/Pixel phones + generic ADB interface",
        "https://developer.android.com/studio/run/win-usb",
        "official",
        "Official page -- wahan se ZIP download karo.",
    ),
    (
        "Samsung USB Driver",
        "Samsung phones (Odin / ADB / Download mode)",
        "https://developer.samsung.com/android-usb-driver",
        "official",
        "Samsung developer site -- official installer.",
    ),
    (
        "Android Platform-Tools",
        "adb + fastboot binaries (is tool ko chahiye!)",
        "https://developer.android.com/tools/releases/platform-tools",
        "official",
        "adb/fastboot na mile to yahan se download karke PATH me dalo.",
    ),
    (
        "Apple Mobile Device USB Driver",
        "iPhone / iPad (Recovery / DFU mode)",
        "",
        "bundled",
        "iTunes install karne se Apple drivers aate hain. Neeche iPhone tab "
        "me official iTunes download button hai.",
    ),
    (
        "MTK (MediaTek) Preloader / VCOM",
        "Tecno / Infinix / Itel / MTK phones (BROM / META mode)",
        "",
        "bundled",
        "MediaTek public download NAHI deta. SP Flash Tool package ke "
        "andar 'Driver' folder se install karo.",
    ),
    (
        "SPD / Unisoc drivers",
        "SPD / Unisoc phones (firmware upgrade mode)",
        "",
        "bundled",
        "SPD Upgrade Tool / Research Tool package ke sath aate hain.",
    ),
    (
        "Qualcomm QDLoader 9008",
        "Qualcomm phones (EDL mode 9008)",
        "",
        "bundled",
        "QPST package ke sath aate hain (Qualcomm official tool).",
    ),
]

# USB Vendor IDs -> chipset/driver family (detection hints).
HW_IDS = {
    "0E8D": "MediaTek (MTK)",
    "05C6": "Qualcomm",
    "1782": "Spreadtrum / Unisoc",
    "04E8": "Samsung",
    "18D1": "Google",
}

# Provider-name keywords looked for in Windows driver store.
_PROVIDER_KEYWORDS = ("mediatek", "qualcomm", "spreadtrum", "unisoc",
                      "samsung", "google")


def check_drivers(adb_bin=None, fb_bin=None):
    """Return a multi-line text report. Never raises."""
    lines = []
    lines.append("== ADB / Fastboot ==")
    lines.append(f"adb: {'FOUND' if adb_bin else 'NOT FOUND'}"
                 + (f" ({adb_bin})" if adb_bin else ""))
    lines.append(f"fastboot: {'FOUND' if fb_bin else 'NOT FOUND'}"
                 + (f" ({fb_bin})" if fb_bin else ""))

    if adb_bin:
        try:
            out = subprocess.run([adb_bin, "devices"], capture_output=True,
                                 text=True, timeout=15).stdout
            devs = [l for l in out.splitlines()[1:] if l.strip()]
            lines.append(f"adb devices: {len(devs)} connected"
                         if devs else "adb devices: koi phone connected nahi")
        except Exception as exc:  # noqa: BLE001 - report, don't crash
            lines.append(f"adb devices check failed: {exc}")

    lines.append("")
    lines.append("== USB drivers (Windows driver store) ==")
    if platform.system() != "Windows":
        lines.append("Ye check sirf Windows par chalta hai. Linux/mac me "
                     "driver install ki zaroorat nahi hoti.")
        return "\n".join(lines)

    try:
        proc = subprocess.run(["pnputil", "/enum-drivers"], capture_output=True,
                              text=True, timeout=30)
        text = (proc.stdout or "").lower()
        found = sorted({kw for kw in _PROVIDER_KEYWORDS if kw in text})
        if found:
            lines.append("Milne wale driver providers: " + ", ".join(found))
        else:
            lines.append("Koi mashhoor phone driver provider nahi mila. "
                         "Upar di gayi list se driver install karo.")
    except FileNotFoundError:
        lines.append("pnputil nahi mila (Windows 10/11 me hota hai).")
    except Exception as exc:  # noqa: BLE001 - report, don't crash
        lines.append(f"Driver check failed: {exc}")

    lines.append("")
    lines.append("TIP: phone ko sahi MODE me lagao (BROM/EDL/Download) -- "
                 "warna driver hone ke bawajood detect nahi hoga.")
    return "\n".join(lines)


def install_driver_folder(folder):
    """Install all .inf drivers from a folder via pnputil (Windows only).

    Returns report text. Needs Admin rights -- warna Windows mana karega.
    """
    import os as _os

    if platform.system() != "Windows":
        return "Ye feature sirf Windows par kaam karta hai."
    if not folder or not _os.path.isdir(folder):
        return "Sahi folder select karo."
    infs = [f for f in _os.listdir(folder) if f.lower().endswith(".inf")]
    if not infs:
        return "Is folder me koi .inf file nahi mili."
    ok, fail = 0, []
    for inf in infs:
        path = _os.path.join(folder, inf)
        try:
            proc = subprocess.run(
                ["pnputil", "/add-driver", path, "/install"],
                capture_output=True, text=True, timeout=120)
            if proc.returncode == 0:
                ok += 1
            else:
                fail.append(inf)
        except Exception as exc:  # noqa: BLE001 - collect, don't crash
            fail.append(f"{inf} ({exc})")
    rep = f"{ok} driver install ho gaye."
    if fail:
        rep += "\nFailed: " + ", ".join(fail)
        rep += ("\n(Agar 'access denied' aaya to tool ko 'Run as administrator' "
                "se chalao.)")
    return rep
