"""Spreadtrum/Unisoc (SPD) helpers -- REAL operations via spd_dump.

spd_dump (bkerler/spreadtrum_flash, open-source):
    spd_dump --wait 300 exec_addr <addr> fdl <fdl1> <addr1> fdl <fdl2> <addr2>
             exec <cmds...> reset

exec commands: erase_part <part>, r <part>, w <part> <file>,
               read_part <part> <off> <size> <file>, reset, verbose

HONEST LIMITS (UI me bhi dikhaye jate hain):
- spd_dump ko FDL files (fdl1/fdl2) chahiye jo MODEL-SPECIFIC hain --
  phone ke firmware/PAC se nikalti hain. Ghalat FDL = kaam nahi karega.
- exec_addr bhi SoC ke hisab se mukhtalif hota hai (neeche table).
- PAC firmware flash SPD Upgrade Tool / ResearchDownload (official,
  free) se hoti hai -- ye tool guide + tool-launch deta hai.
"""

import os
import shutil
import subprocess
import sys
import time

# BROM me phone lagane par VID:PID
SPD_BROM_VIDPID = [("1782", "4D00"), ("1782", "4D01")]

# exec_addr per SoC (aam values -- ghalat ho to user override kar sakta hai)
SPD_EXEC_ADDR = {
    "SC9832E": "0x4ee8",
    "SC9863A": "0x4ee8",
    "SC7731E": "0x4ee8",
    "T310": "0x65015f08",
    "T606": "0x65015f08",
    "T612": "0x65015f08",
    "T616": "0x65015f08",
    "T618": "0x65015f08",
    "T760": "0x65015f08",
}
DEFAULT_EXEC_ADDR = "0x4ee8"


def find_spd_dump():
    """spd_dump dhoondo: bundled dir > PATH. Returns cmd list ya None."""
    base = os.path.dirname(os.path.abspath(
        sys.argv[0] if getattr(sys, "frozen", False) else __file__))
    for name in ("spd_dump.exe", "spd_dump", "spd_dump.py"):
        for d in (os.path.join(base, "tools", "spd_dump"),
                  os.path.join(base, "spd_dump"),
                  base):
            p = os.path.join(d, name)
            if os.path.isfile(p):
                if p.endswith(".py"):
                    return [sys.executable, p]
                return [p]
    exe = shutil.which("spd_dump") or shutil.which("spd_dump.exe")
    if exe:
        return [exe]
    return None


def run_spd(cmd, args, line_cb, timeout=900):
    """spd_dump chalao, live log. Returns (True, 'done')/(False, reason)."""
    full = cmd + args
    line_cb("$ " + " ".join(full))
    try:
        p = subprocess.Popen(full, stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT,
                             text=True, bufsize=1)
    except FileNotFoundError:
        return False, "spd_dump nahi mila"
    except Exception as exc:
        return False, str(exc)
    try:
        for line in p.stdout:
            line_cb("  " + line.rstrip()[:220])
        p.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        p.kill()
        return False, "timeout -- phone disconnect?"
    if p.returncode == 0:
        return True, "done"
    return False, f"spd_dump exit code {p.returncode}"


def detect_spd(usb_devices=None):
    """SPD BROM device (1782:4D00/4D01) detect karo.

    usb_devices: mtktool.list_usb_devices() ka result (optional).
    Returns (True, detail) ya (False, reason).
    """
    if usb_devices is None:
        try:
            from mtktool import list_usb_devices
            usb_devices = list_usb_devices()
        except Exception:
            return False, "USB scan nahi ho saka"
    hits = []
    for vid, pid, name in usb_devices:
        for wvid, wpid in SPD_BROM_VIDPID:
            if vid.upper() == wvid and pid.upper() == wpid:
                hits.append(f"{vid}:{pid} ({name[:50]})")
    if hits:
        return True, "; ".join(hits)
    return False, "koi SPD BROM device nahi mila (1782:4D00)"


def wait_spd(seconds=60, line_cb=None):
    for i in range(seconds):
        ok, detail = detect_spd()
        if ok:
            return True, detail
        time.sleep(1)
        if line_cb and i % 10 == 9:
            line_cb(f"  ... SPD BROM ka intezar ({i+1}/{seconds}s) -- "
                    "phone OFF + Vol UP+DOWN + USB")
    return False, "timeout: SPD BROM device nahi mila"


def build_fdl_args(fdl1, addr1, fdl2, addr2, exec_addr, wait=300):
    """spd_dump ke liye FDL/exec args banao."""
    args = ["--wait", str(wait)]
    if exec_addr:
        args += ["exec_addr", exec_addr]
    args += ["fdl", fdl1, addr1, "fdl", fdl2, addr2, "exec"]
    return args


SPD_PAC_GUIDE = """[SPD] PAC FIRMWARE FLASH -- step-by-step:

1. SPD Upgrade Tool ya ResearchDownload kholo (official, free).
   (Google: 'SPD Upgrade Tool latest' -- sirf bharosa wali site se!)
2. Load Packet -> apne MODEL ki .pac file select karo.
3. Phone OFF karo, Vol UP+DOWN dabaye rakho + USB lagao.
4. Start (▶) dabao -- flashing shuru.

ZAROORI:
- Sirf APNE MODEL ki PAC file use karo -- ghalat PAC = DEAD phone!
- Battery 50%+ charged ho.
- Drivers: 'SPD SCI USB2Serial' Device Manager me aana chahiye.
"""

SPD_DIAG_GUIDE = """[SPD] DIAG MODE -- guide:

1. Phone ON karo, dialer me likho: *#*#83781#*#*
   (Engineering Mode khulega)
2. 'Diag' / 'Modem test' me diag port ON karo.
3. PC par 'SPRD U2S Diag' COM port aayegi (Device Manager me check karo).
4. Kuch models me: adb shell setprop sys.usb.config diag,adb

Note: Diag se IMEI repair ke liye official WriteIMEI tool + 
model-specific NV files darkar hote hain.
"""
