"""Offline tests for updater.py -- no network needed (uses file:// URLs)."""

import json
import os
import tempfile

import updater
from updater import (check_for_updates, create_apply_script, is_newer,
                     parse_version, save_update_url)

# version parsing / comparison
assert parse_version("5.0") == (5, 0)
assert parse_version("5") == (5,)
assert parse_version("v4.10-beta") == (4, 10)
assert is_newer("5.1", "5.0")
assert is_newer("6.0", "5.9")
assert is_newer("10.0", "9.9")
assert not is_newer("5.0", "5.0")
assert not is_newer("4.9", "5.0")

# MANUAL channel: no config -> not_configured
updater.CONFIG_FILE = os.path.join(tempfile.gettempdir(), "no-such-config.json")
if os.path.exists(updater.CONFIG_FILE):
    os.remove(updater.CONFIG_FILE)
status, msg, info = check_for_updates()
assert status == "not_configured", status
assert "UPDATE.bat" in msg

# GITHUB-style channel via local file:// URL
with tempfile.TemporaryDirectory() as d:
    ver_path = os.path.join(d, "version.json")
    cfg_path = os.path.join(d, "update_config.json")
    with open(ver_path, "w", encoding="utf-8") as fh:
        json.dump({"version": "99.0", "notes": "test notes",
                   "download_url": "file:///tmp/x.zip"}, fh)
    with open(cfg_path, "w", encoding="utf-8") as fh:
        json.dump({"update_url": "file://" + ver_path}, fh)
    updater.CONFIG_FILE = cfg_path

    status, msg, info = check_for_updates()
    assert status == "available", (status, msg)
    assert info["version"] == "99.0"
    assert "99.0" in msg

    # same version -> uptodate
    with open(ver_path, "w", encoding="utf-8") as fh:
        json.dump({"version": updater.CURRENT_VERSION}, fh)
    status, msg, info = check_for_updates()
    assert status == "uptodate", (status, msg)

    # broken json -> error (not a crash)
    with open(ver_path, "w", encoding="utf-8") as fh:
        fh.write("not json {{{")
    status, msg, info = check_for_updates()
    assert status == "error", status

# save_update_url round-trip (temp config, does not touch real file)
with tempfile.TemporaryDirectory() as d:
    updater.CONFIG_FILE = os.path.join(d, "update_config.json")
    saved = save_update_url("https://example.com/gsmtool/version.json")
    assert saved == "https://example.com/gsmtool/version.json"
    assert updater.load_config()["update_url"] == saved
    save_update_url("   ")
    assert updater.load_config()["update_url"] == ""

# create_apply_script: generates a sane .bat
with tempfile.TemporaryDirectory() as d:
    app_dir = os.path.join(d, "HamzaGSMTool")
    os.makedirs(app_dir)
    zip_path = os.path.join(d, "HamzaGSMTool-v7.zip")
    open(zip_path, "w").write("fake")
    script = create_apply_script(app_dir, zip_path)
    assert script.endswith("_apply_update.bat")
    assert os.path.isfile(script)
    body = open(script, encoding="utf-8").read()
    for marker in ("users.db", "Expand-Archive", "HamzaGSMTool",
                   "python app.py", app_dir, zip_path):
        assert marker in body, f"missing in script: {marker}"

print("All updater tests passed.")
