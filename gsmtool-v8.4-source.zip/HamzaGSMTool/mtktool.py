"""MTKClient + META-mode serial helpers -- REAL operations, koi guide-only nahi.

Yeh module do cheezon ko lapet'ta (wrap) karta hai:

1. MTKClient (github.com/bkerler/mtkclient) -- BROM/PreLoader mode me:
   - FRP erase, factory reset (format), partition flash, reboot.
   - Subprocess ke zariye chalaya jata hai, output live log me stream hota hai.
2. META mode serial (pyserial) -- phone jab META mode me ho:
   - COM port detect, AT commands bhejo (IMEI restore: AT+EGMR).

Honest limits (log me bhi bataye jate hain):
- MTKClient ko BROM/PreLoader mode chahiye (phone OFF + Vol key + USB).
- Naye chips (SLA/DAA/SCB auth wale) MTKClient ko rok sakte hain -- tab
  official DA file / vendor tool darkar hota hai.
- IMEI AT commands kuch secure-boot phones par reject ho sakte hain.
"""

import os
import platform
import re
import shutil
import subprocess
import sys
import time

# ---------------------------------------------------------------------------
# MTKClient locate / install
# ---------------------------------------------------------------------------

def _bundled_mtk():
    """EXE ke saath bundled tools/mtkclient/mtk.py dhoondo."""
    base = os.path.dirname(os.path.abspath(sys.argv[0] if getattr(sys, "frozen", False) else __file__))
    candidates = [
        os.path.join(base, "tools", "mtkclient", "mtk.py"),
        os.path.join(base, "mtkclient", "mtk.py"),
        os.path.join(os.path.dirname(base), "tools", "mtkclient", "mtk.py"),
    ]
    for c in candidates:
        if os.path.isfile(c):
            return [sys.executable, c]
    return None


def find_mtk():
    """MTKClient chalane ka command dhoondo.

    Returns: command list (e.g. ['mtk'] ya [sys.executable, 'mtk.py']),
             ya None agar nahi mila.
    """
    bundled = _bundled_mtk()
    if bundled:
        return bundled
    exe = shutil.which("mtk")
    if exe:
        return [exe]
    # python -m mtkclient? (entry point module check)
    try:
        r = subprocess.run(
            [sys.executable, "-c", "import mtkclient; print('ok')"],
            capture_output=True, text=True, timeout=20)
        if "ok" in (r.stdout or ""):
            return [sys.executable, "-m", "mtkclient"]
    except Exception:
        pass
    return None


def mtk_version(cmd):
    """MTKClient ka version string lao (ya None)."""
    try:
        r = subprocess.run(cmd + ["version"], capture_output=True,
                           text=True, timeout=30)
        out = (r.stdout or "") + (r.stderr or "")
        m = re.search(r"(\d+\.\d+[\.\d]*)", out)
        return m.group(1) if m else (out.strip().splitlines()[0][:60] if out.strip() else "?")
    except Exception:
        return None


def install_mtkclient(line_cb):
    """pip se MTKClient install karo, live log ke saath. Returns True/False."""
    line_cb("MTKClient install ho raha hai (pip install mtkclient)...")
    line_cb("Ye 1-2 minute le sakta hai -- sabar rakho.")
    try:
        p = subprocess.Popen(
            [sys.executable, "-m", "pip", "install", "--upgrade", "mtkclient"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, bufsize=1)
        for line in p.stdout:
            line_cb("  pip: " + line.rstrip()[:160])
        p.wait(timeout=600)
        if p.returncode == 0:
            line_cb("OK: MTKClient install ho gaya!")
            return True
        line_cb(f"pip fail (code {p.returncode}).")
        return False
    except Exception as exc:
        line_cb(f"Install error: {exc}")
        return False


def run_mtk(cmd, args, line_cb, timeout=900, loader=None):
    """MTKClient command chalao, output line-by-line live log me.

    loader: DA file ka path (optional) -> '--loader <file>' lag jayega.
    Returns (True, 'done') ya (False, reason).
    """
    full = list(cmd)
    if loader and os.path.isfile(loader):
        full += ["--loader", loader]
    full += args
    line_cb("$ " + " ".join(full))
    try:
        p = subprocess.Popen(
            full, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, bufsize=1)
    except FileNotFoundError:
        return False, "mtk nahi mila -- pehle [TOOLS] Install MTKClient chalao"
    except Exception as exc:
        return False, str(exc)
    try:
        for line in p.stdout:
            line_cb("  " + line.rstrip()[:220])
        p.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        p.kill()
        return False, "timeout -- phone disconnect ho gaya?"
    if p.returncode == 0:
        return True, "done"
    return False, f"mtk exit code {p.returncode}"


# ---------------------------------------------------------------------------
# Device detection (Windows)
# ---------------------------------------------------------------------------

def _wmic_names():
    """Win32_PnPEntity se device names lao."""
    if platform.system() != "Windows":
        return []
    try:
        out = subprocess.run(
            ["wmic", "path", "Win32_PnPEntity", "get", "Name"],
            capture_output=True, text=True, timeout=25).stdout or ""
        return [l.strip() for l in out.splitlines() if l.strip()]
    except Exception:
        return []


# --- VID:PID detection (BROM connect ke liye) ---
# MediaTek PreLoader = 0E8D:2000, MediaTek BROM = 0E8D:0003
MTK_VIDPIDS = {
    ("0E8D", "2000"): "MediaTek PreLoader",
    ("0E8D", "0003"): "MediaTek BROM",
}
_VIDPID_RE = re.compile(r"VID_([0-9A-Fa-f]{4})&PID_([0-9A-Fa-f]{4})")


def list_usb_devices():
    """Sab USB devices: [(vid, pid, name), ...]. Windows wmic DeviceID se.

    DeviceID format: USB\\VID_0E8D&PID_2000\\5&xxxx -- is se VID:PID nikalo.
    """
    if platform.system() != "Windows":
        return []
    try:
        out = subprocess.run(
            ["wmic", "path", "Win32_PnPEntity",
             "where", "DeviceID like 'USB%'", "get", "Name,DeviceID",
             "/format:list"],
            capture_output=True, text=True, timeout=30).stdout or ""
    except Exception:
        return []
    devs = []
    name, devid = "", ""
    for line in out.splitlines():
        line = line.strip()
        if line.startswith("Name="):
            name = line[5:].strip()
        elif line.startswith("DeviceID="):
            devid = line[9:].strip()
            m = _VIDPID_RE.search(devid)
            if m and name:
                devs.append((m.group(1).upper(), m.group(2).upper(), name))
            name, devid = "", ""
    return devs


def detect_brom_vidpid():
    """VID:PID se MTK BROM/PreLoader dhoondo.

    Returns (True, '0E8D:2000 MediaTek PreLoader (...)') ya (False, reason).
    """
    devs = list_usb_devices()
    for vid, pid, name in devs:
        label = MTK_VIDPIDS.get((vid, pid))
        if label:
            return True, f"{vid}:{pid} {label} ({name[:60]})"
    return False, ("koi MTK BROM/PreLoader nahi mila "
                   "(0E8D:2000 / 0E8D:0003) -- drivers check karo")


def wait_brom_vidpid(seconds=60, line_cb=None):
    for i in range(seconds):
        ok, detail = detect_brom_vidpid()
        if ok:
            return True, detail
        time.sleep(1)
        if line_cb and i % 10 == 9:
            line_cb(f"  ... BROM ka intezar ({i+1}/{seconds}s) -- "
                    "phone OFF + Vol key + USB")
    return False, "timeout: MTK BROM/PreLoader nahi mila"


def driver_hint_mtk():
    return ("Driver guide (Urdu):\n"
            "1. Device Manager kholo (neeche [TOOLS] button hai).\n"
            "2. Phone OFF + Vol UP + USB lagao.\n"
            "3. 'MediaTek PreLoader USB VCOM' aana chahiye.\n"
            "   - Peela '!' ho to: MTK VCOM drivers install karo\n"
            "     (MediaTek_Driver_Auto_Installer -- bharosa wali site se).\n"
            "4. PreLoader sirf 3-5 second rehta hai -- jaldi dekho!")


def detect_preloader():
    """MTK PreLoader/BROM USB device detect karo. Returns (bool, detail)."""
    if platform.system() != "Windows":
        return False, "device detection sirf Windows par hai"
    hits = []
    for name in _wmic_names():
        low = name.lower()
        if ("mediatek" in low and ("preloader" in low or "vcom" in low
                                  or "usb port" in low)) or "mtk usb port" in low:
            hits.append(name)
    if hits:
        return True, "; ".join(hits[:3])
    return False, "koi MTK PreLoader/BROM device nahi mila"


META_PORT_KEYWORDS = ("meta", "mediatek", "cdc", "vcom", "usb serial",
                      "mt65", "mt67", "mt68", "preloader")


def detect_meta_port():
    """META mode ka COM port dhoondo.

    Returns (True, 'COM7 (MediaTek USB Port)') ya (False, reason).
    """
    if platform.system() != "Windows":
        return False, "sirf Windows par supported"
    ports = []
    # Tareeqa 1: pyserial ki list (agar installed hai)
    try:
        from serial.tools import list_ports
        for p in list_ports.comports():
            desc = f"{p.description} {p.manufacturer or ''}".lower()
            if any(k in desc for k in META_PORT_KEYWORDS):
                ports.append((p.device, p.description))
    except Exception:
        pass
    # Tareeqa 2: wmic se COM wale devices
    if not ports:
        try:
            out = subprocess.run(
                ["wmic", "path", "Win32_PnPEntity",
                 "where", "Name like '%COM%'", "get", "Name"],
                capture_output=True, text=True, timeout=25).stdout or ""
            for line in out.splitlines():
                low = line.lower()
                m = re.search(r"\(com\d+\)", low)
                if m and any(k in low for k in META_PORT_KEYWORDS):
                    ports.append((m.group(0).strip("()").upper(),
                                  line.strip()))
        except Exception:
            pass
    if ports:
        dev, desc = ports[0]
        extra = f" (+{len(ports)-1} aur)" if len(ports) > 1 else ""
        return True, f"{dev} ({desc[:60]}){extra}"
    return False, "koi META COM port nahi mila -- phone META mode me hai?"


def wait_meta_port(seconds=30, line_cb=None):
    """META port ke zahir hone ka intezar karo."""
    for i in range(seconds):
        ok, detail = detect_meta_port()
        if ok:
            return True, detail
        time.sleep(1)
        if line_cb and i % 5 == 4:
            line_cb(f"  ... META port ka intezar ({i+1}/{seconds}s)")
    return False, "timeout: META port nahi aaya"


def wait_preloader(seconds=60, line_cb=None):
    """PreLoader/BROM device ka intezar karo."""
    for i in range(seconds):
        ok, detail = detect_preloader()
        if ok:
            return True, detail
        time.sleep(1)
        if line_cb and i % 10 == 9:
            line_cb(f"  ... PreLoader ka intezar ({i+1}/{seconds}s) -- "
                    "phone OFF + Vol UP + USB")
    return False, "timeout: koi MTK PreLoader/BROM device nahi mila"


# ---------------------------------------------------------------------------
# META serial AT commands (IMEI restore)
# ---------------------------------------------------------------------------

def meta_at(port, command, timeout=12):
    """Ek AT command bhejo, jawab parho.

    Returns (True, 'OK...') ya (False, reason). pyserial darkar hai.
    """
    try:
        import serial
    except ImportError:
        return False, "pyserial nahi hai -- pip install pyserial chalao"
    try:
        ser = serial.Serial(port, baudrate=115200, bytesize=8,
                            parity="N", stopbits=1, timeout=timeout,
                            write_timeout=5)
    except Exception as exc:
        return False, f"port {port} nahi khula: {exc}"
    try:
        ser.reset_input_buffer()
        ser.write((command + "\r\n").encode("ascii", "replace"))
        ser.flush()
        deadline = time.time() + timeout
        buf = ""
        while time.time() < deadline:
            chunk = ser.read(256).decode("ascii", "replace")
            if chunk:
                buf += chunk
                up = buf.upper()
                if "OK" in up:
                    return True, buf.strip()[-200:]
                if "ERROR" in up:
                    return False, "phone ne ERROR diya: " + buf.strip()[-200:]
            else:
                time.sleep(0.2)
        return False, "jawab timeout: " + (buf.strip()[-120:] or "(khali)")
    finally:
        try:
            ser.close()
        except Exception:
            pass


def imei_write_meta(port, imei, line_cb):
    """META AT se IMEI likho (SIM1 + SIM2). Returns (True/False, detail)."""
    line_cb(f"IMEI {imei} META port {port} par likha ja raha hai...")
    ok, resp = meta_at(port, "AT")
    if not ok:
        return False, "AT handshake fail: " + resp
    line_cb("  AT handshake OK.")
    results = []
    for slot, param in (("SIM1", "1,7"), ("SIM2", "1,10")):
        cmd = f'AT+EGMR={param},"{imei}"'
        line_cb(f"  bhej rahe hain: AT+EGMR={param},\"...\" ({slot})")
        ok, resp = meta_at(port, cmd, timeout=15)
        results.append((slot, ok, resp))
        if ok:
            line_cb(f"  {slot}: OK!")
        else:
            line_cb(f"  {slot}: FAIL -- {resp[:100]}")
    if all(r[1] for r in results):
        return True, "dono SIM slots par IMEI likh diya gaya"
    failed = ", ".join(r[0] for r in results if not r[1])
    detail = "; ".join(f"{r[0]}: {r[2][:80]}" for r in results if not r[1])
    # Aam wajah: secure boot / auth -- seedhi baat batao
    hint = ("Ho sakta hai phone ka secure boot AT+EGMR rok raha ho "
            "(naye MTK par aam hai). Tab official SN Writer + auth DB "
            "darkar hota hai.")
    return False, f"{failed} fail. {detail} | {hint}"
