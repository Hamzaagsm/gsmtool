"""Online DA (Download Agent) database system.

Concept: chip detect/select karo -> GitHub-hosted da_database.json se
matching DA dhoondo -> download karke local cache me rakho ->
MTKClient ko --loader flag se do / SP Flash Tool me guide karo.

HONEST RULES:
- DA files manufacturers ki property hain: tool khud DA host NAHI karta,
  sirf PUBLIC links use karta hai.
- Day 1 par sab chips nahi honge -- database waqt ke saath bharegi.
- Jin chips ka koi public DA nahi, wahan sirf official firmware ka rasta
  bataya jata hai (koi fake link nahi!).
"""

import json
import os
import re
import sys
import urllib.request

# GitHub par host hone wali database (hamzaagsm/gsmtool repo).
# Parent agent ko ye file repo me upload karni hai (neeche LOCAL fallback bhi hai).
DA_DB_URL = ("https://raw.githubusercontent.com/Hamzaagsm/gsmtool/"
             "main/da_database.json")

SCHEMA_VERSION = 1


def _cache_dir():
    base = os.path.dirname(os.path.abspath(
        sys.argv[0] if getattr(sys, "frozen", False) else __file__))
    d = os.path.join(base, "da_cache")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d


def _local_db_path():
    base = os.path.dirname(os.path.abspath(
        sys.argv[0] if getattr(sys, "frozen", False) else __file__))
    return os.path.join(base, "da_database.json")


def fetch_db(timeout=20):
    """Online database lao. Returns (db_dict, source_str).

    source_str: 'online' ya 'local' (fallback) -- user ko bataya jata hai.
    """
    # 1) online
    try:
        req = urllib.request.Request(
            DA_DB_URL, headers={"User-Agent": "HamzaGSMTool/8.2"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            db = json.loads(r.read().decode("utf-8", "replace"))
            if isinstance(db, dict):
                return db, "online (GitHub)"
    except Exception:
        pass
    # 2) local fallback (tool ke saath bundled)
    try:
        with open(_local_db_path(), "r", encoding="utf-8") as f:
            db = json.load(f)
            if isinstance(db, dict):
                return db, "local (bundled copy -- online nahi mila)"
    except Exception:
        pass
    return {}, "koi database nahi mili"


def normalize_chip(chip):
    """'Mediatek MT6765' -> 'MT6765'. Returns upper chip code ya ''."""
    if not chip:
        return ""
    m = re.search(r"MT\s?(\d{4})", chip.upper())
    if m:
        return "MT" + m.group(1)
    m = re.search(r"(SC\d{4}[A-Z]?|T\d{3,4})\b", chip.upper())
    if m:
        return m.group(1)
    return chip.strip().upper()


def find_entry(db, chip):
    """Chip ke liye database entry dhoondo. Returns (key, entry) ya (None, None)."""
    code = normalize_chip(chip)
    if not code:
        return None, None
    # exact match
    if code in db:
        return code, db[code]
    # case-insensitive
    for k, v in db.items():
        if k.upper() == code:
            return k, v
    return None, None


def download_da(url, dest_name, progress_cb=None, timeout=120):
    """DA file download karo (streaming). Returns (True, path)/(False, reason)."""
    if not url or not url.lower().startswith(("http://", "https://")):
        return False, "koi download link nahi hai"
    dest = os.path.join(_cache_dir(), dest_name)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "HamzaGSMTool/8.2"})
        with urllib.request.urlopen(req, timeout=timeout) as r, \
                open(dest, "wb") as f:
            total = int(r.headers.get("Content-Length") or 0)
            done = 0
            while True:
                chunk = r.read(65536)
                if not chunk:
                    break
                f.write(chunk)
                done += len(chunk)
                if progress_cb and total:
                    progress_cb(done, total)
        # sanity: DA files aam tor par 300KB-2MB
        size = os.path.getsize(dest)
        if size < 50_000:
            return False, f"file bohat chhoti hai ({size} bytes) -- link ghalat ho sakta hai"
        return True, dest
    except Exception as exc:
        return False, f"download fail: {exc}"


def cached_da(chip_code):
    """Pehle se downloaded DA hai? Returns path ya None."""
    d = _cache_dir()
    for ext in (".bin", ".da"):
        p = os.path.join(d, f"{chip_code}{ext}")
        if os.path.isfile(p) and os.path.getsize(p) > 50_000:
            return p
    return None


def share_template(chip_code="MT6765"):
    """'DA Share karo' ke liye JSON template banao."""
    return json.dumps({
        chip_code: {
            "da_url": "https://PASTE_LINK_HERE",
            "source": "public",
            "note": "kis model/firmware se mili, yahan likho",
            "tested_by": "apna naam / shop",
        }
    }, indent=2, ensure_ascii=False)


def open_cache_folder():
    """DA cache folder kholo (SP Flash Tool me manually select ke liye)."""
    d = _cache_dir()
    try:
        if sys.platform == "win32":
            os.startfile(d)  # noqa: S606 - user ka apna folder
        else:
            import subprocess
            subprocess.Popen(["xdg-open", d])
        return True
    except Exception:
        return False
