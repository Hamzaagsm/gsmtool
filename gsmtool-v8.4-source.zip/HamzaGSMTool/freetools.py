"""Free external tools launcher for Hamza GSM Tool v8.3.

Har tool: official download link + local launch.
Tools ~/workspace/gsmtool/freetools/<key>/ me extract karo, phir tool se khul jayega.
"""

import os

TOOLS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "freetools")

# key: (display name, description_urdu, download_url, exe_names_to_find)
FREE_TOOLS = {
    "samfw": (
        "SamFw FRP Tool",
        "Samsung FRP remove (free). Android 9-15. Setup wizard → *#0*# → Remove FRP.",
        "https://samfw.com",
        ["SamFwTool.exe", "SamFwFRPTool.exe"],
    ),
    "odin": (
        "Odin3 v3.14.4",
        "Samsung firmware flashing (BL/AP/CP/CSC). Sirf genuine v3.14.4 use karo.",
        "https://odindownload.com",
        ["Odin3.exe", "Odin3 v3.14.4.exe"],
    ),
    "3utools": (
        "3uTools",
        "iPhone flashing, backup, battery info, exit recovery. 100% free.",
        "https://www.3u.com",
        ["3uTools.exe"],
    ),
    "scrcpy": (
        "scrcpy",
        "Phone screen PC par mirror + control. Tooti screen ka data nikalo.",
        "https://github.com/Genymobile/scrcpy/releases",
        ["scrcpy.exe"],
    ),
    "miflash": (
        "MiFlash",
        "Xiaomi fastboot ROM flashing. 'clean all' select karo (lock wala nahi!).",
        "https://xiaomiflash.com",
        ["XiaoMiFlash.exe", "MiFlash.exe"],
    ),
    "frija": (
        "Frija",
        "Samsung firmware Samsung ke server se direct download (fast, free).",
        "https://forum.xda-developers.com/t/tool-frija-samsung-firmware-downloader-checker.3910594/",
        ["Frija.exe"],
    ),
    "realmeflash": (
        "Realme Flash Tool",
        "Realme/Oppo OFP firmware flashing. Unlocked bootloader chahiye.",
        "https://www.thecustomdroid.com/realme-flash-tool/",
        ["RealmeFlash.exe"],
    ),
    "qpst": (
        "QPST / QFIL",
        "Qualcomm EDL (9008) flashing. QDLoader drivers ke saath.",
        "https://qpsttool.com",
        ["QFIL.exe"],
    ),
    "androidwintool": (
        "Android Win Tool",
        "FREE: Infinix/Tecno/Itel Anti-Crack Remove! MTK devices. Register (free) → Anti-Crack Remove.",
        "https://github.com/Android-Win-Tools-Update",
        ["AndroidWinTool.exe", "Android Win Tool.exe"],
    ),
    "mtkclient_gui": (
        "MTKClient GUI",
        "FREE: MTK BROM operations — FRP, format, backup. Python based.",
        "https://github.com/bkerler/mtkclient",
        ["mtk_gui.exe", "mtk_gui"],
    ),
    "spflashtool": (
        "SP Flash Tool",
        "FREE: Official MTK firmware flashing tool. Scatter file se flash.",
        "https://spflashtool.com",
        ["flash_tool.exe"],
    ),
    "egsmtool": (
        "E-GSM Tool (1-MONTH FREE TRIAL)",
        "All brands: FRP, flash, IMEI, Mi Account. Sirf 1 mahina free trial, phir paid.",
        "https://egsmtool.com",
        ["EGSMTool.exe", "E-GSM Tool.exe"],
    ),
    # ---- v8.4: mazeed free tools (research se) ----
    "mtkclient": (
        "mtkclient (GitHub)",
        "FREE open-source: MTK BROM exploit, FRP erase, flash read/write. Python + UsbDk.",
        "https://github.com/bkerler/mtkclient",
        ["mtk_gui.exe", "mtk_gui", "mtk.exe"],
    ),
    "spflashtool_official": (
        "SP Flash Tool (Official)",
        "Official MediaTek flasher — scatter firmware flashing. 100% free.",
        "https://spflashtool.com",
        ["flash_tool.exe"],
    ),
    "sfdtool": (
        "SFD Tool GUI (SPD FREE)",
        "Open-source Unisoc tool: PAC flash, partition manager, slot A/B. No credits!",
        "https://github.com",
        ["SFDTool.exe", "sfdtool.exe"],
    ),
    "spdresearch": (
        "SPD Research Tool (Official)",
        "Official Unisoc flasher (PAC firmware). Portable, free.",
        "http://spdflashtool.com",
        ["ResearchDownload.exe"],
    ),
    "edl_qc": (
        "edl (Qualcomm Open-Source)",
        "FREE QC Firehose/Sahara CLI — QFIL jaisa, open-source. Python.",
        "https://github.com/lwz114/edl",
        ["edl.exe", "edl"],
    ),
    "miunlock": (
        "Mi Unlock (Official Xiaomi)",
        "Official bootloader unlock — free (7 din wait). xiaomi.com se.",
        "https://www.mi.com/global/unlock/",
        ["MiUnlock.exe", "miflash_unlock.exe"],
    ),
    "modemmeta": (
        "ModemMeta (MTK IMEI Restore)",
        "MTK META mode: DABBE wala ORIGINAL IMEI likho (000000 fix). Free.",
        "https://www.getdroidtips.com",
        ["ModemMeta.exe"],
    ),
    "snwriter": (
        "SN Writer (MTK Official)",
        "MTK official: serial/IMEI writer. Original restore ke liye.",
        "https://spflashtool.com",
        ["SN Writer.exe", "SNWriter.exe"],
    ),
    "gstsamunlock": (
        "G-ST SamUnlock V7.8 [Community]",
        "Samsung all-chipset FRP/flash/serial. Free (community tool — scan karo).",
        "https://www.advancedsetting.com",
        ["G-ST SamUnlock.exe", "SamUnlock.exe"],
    ),
    "primetoolx": (
        "Prime Tool X [Community]",
        "Samsung/Xiaomi/Motorola FRP (Android 12-16). Free, no login (scan karo).",
        "https://gsmxblog.com",
        ["PrimeToolX.exe"],
    ),
    "bmbtool": (
        "BMB Tool Pro [Community]",
        "Samsung/Xiaomi/Vivo/Oppo/Tecno FRP (MTK+QC). Free (scan karo).",
        "https://www.youtube.com",
        ["BMBTool.exe"],
    ),
    "miketunlocker": (
        "Mike Techs Unlocker Pro [Community]",
        "35+ brands: FRP, screen lock, flash, EDL/SPD. Free ~750MB (scan karo).",
        "https://www.sergesmiketechs.com",
        ["MikeTechsUnlocker.exe"],
    ),
    "oplus_edl": (
        "OPLUS EDL Tool [Community]",
        "Realme/OnePlus/Oppo EDL flashing. Free (scan karo).",
        "https://www.fixbynaem.com",
        ["OPLUS_EDL.exe", "OplusEDL.exe"],
    ),
}


def find_tool_exe(key):
    """Tool ka exe dhoondo. (path ya None)"""
    info = FREE_TOOLS.get(key)
    if not info:
        return None
    folder = os.path.join(TOOLS_DIR, key)
    for exe in info[3]:
        p = os.path.join(folder, exe)
        if os.path.isfile(p):
            return p
        # subfolder me bhi dhoondo (1 level)
        if os.path.isdir(folder):
            for root, _dirs, files in os.walk(folder):
                if exe in files:
                    return os.path.join(root, exe)
    return None


def tool_install_hint(key):
    """User ko batayo kahan extract karna hai."""
    info = FREE_TOOLS.get(key)
    folder = os.path.join(TOOLS_DIR, key)
    return (
        f"{info[0]} abhi installed nahi hai.\n\n"
        f"1. Download page kholo: {info[2]}\n"
        f"2. Download karke extract karo is folder me:\n   {folder}\n"
        f"3. Phir dobara ye button dabao — tool khul jayega!"
    )
