#!/usr/bin/env python3
"""Command-line interface for the GSM toolkit. Example:
    python cli.py devices
    python cli.py info
    python cli.py scan
    python cli.py disable com.example.mdm
"""

import argparse
import sys

import adbwrap
import brands
import features


def main():
    ap = argparse.ArgumentParser(description="Hamza GSM Tool (CLI)")
    ap.add_argument("-s", "--serial", default=None, help="device serial")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("devices", help="list adb + fastboot devices")
    sub.add_parser("info", help="read device info (adb)")
    sub.add_parser("scan", help="scan installed apps for MDM-like packages")
    sub.add_parser("admins", help="show active device admins")

    p = sub.add_parser("reboot", help="reboot to a mode")
    p.add_argument("target", choices=features.REBOOT_TARGETS)

    p = sub.add_parser("disable", help="disable a package (reversible)")
    p.add_argument("package")
    p = sub.add_parser("uninstall", help="uninstall package for user 0 (keep data)")
    p.add_argument("package")
    p = sub.add_parser("install", help="install an APK")
    p.add_argument("apk")

    sub.add_parser("fb-devices", help="fastboot devices")
    sub.add_parser("unlock", help="bootloader unlock (WIPES DATA)")
    sub.add_parser("lock", help="bootloader lock")
    p = sub.add_parser("flash", help="fastboot flash partition")
    p.add_argument("partition")
    p.add_argument("image")

    sub.add_parser("brands", help="list supported brands")
    p = sub.add_parser("brand", help="show brand cheat sheet")
    p.add_argument("name")
    sub.add_parser("imei-guide", help="IMEI repair workflow (honest)")
    sub.add_parser("frp-guide", help="FRP notes (honest)")
    sub.add_parser("spd-notes", help="SPD/Unisoc notes")

    args = ap.parse_args()
    adb = adbwrap.find_binary("adb")
    fb = adbwrap.find_binary("fastboot")
    s = args.serial

    try:
        if args.cmd == "devices":
            print("adb:", features.adb_devices(adb))
            print("fastboot:", features.fastboot_devices(fb))
        elif args.cmd == "info":
            for k, v in features.device_info(adb, s).items():
                print(f"{k}: {v}")
        elif args.cmd == "scan":
            pkgs = features.list_packages(adb, s)
            found = features.find_suspicious_packages(pkgs)
            print(f"{len(pkgs)} packages, MDM-like: {found or 'none'}")
        elif args.cmd == "admins":
            print(features.device_admins(adb, s) or "no active device admins")
        elif args.cmd == "reboot":
            features.reboot_device(adb, args.target, s)
            print("rebooting to", args.target)
        elif args.cmd == "disable":
            features.disable_package(adb, args.package, s)
            print("disabled", args.package)
        elif args.cmd == "uninstall":
            features.uninstall_package(adb, args.package, s)
            print("uninstalled", args.package)
        elif args.cmd == "install":
            features.install_apk(adb, args.apk, s)
            print("installed", args.apk)
        elif args.cmd == "fb-devices":
            print(features.fastboot_devices(fb))
        elif args.cmd == "unlock":
            features.fastboot_unlock(fb, s)
            print("bootloader unlock sent")
        elif args.cmd == "lock":
            features.fastboot_lock(fb, s)
            print("bootloader lock sent")
        elif args.cmd == "flash":
            features.fastboot_flash(fb, args.partition, args.image, s)
            print("flash done")
        elif args.cmd == "brands":
            print(", ".join(brands.brand_names()))
        elif args.cmd == "brand":
            print(brands.cheat_sheet(args.name))
        elif args.cmd == "imei-guide":
            print(brands.IMEI_WORKFLOW)
        elif args.cmd == "frp-guide":
            print(brands.FRP_WORKFLOW)
        elif args.cmd == "spd-notes":
            print(brands.SPD_NOTES)
    except adbwrap.ToolError as exc:
        print("ERROR:", exc, file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
