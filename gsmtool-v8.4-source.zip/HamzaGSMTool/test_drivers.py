"""Tests for drivers.py -- structure, URLs, and safe check behavior."""

import drivers


def test_driver_rows_structure():
    assert len(drivers.DRIVER_ROWS) >= 5
    for row in drivers.DRIVER_ROWS:
        name, purpose, url, kind, note = row
        assert name and purpose and note
        assert kind in ("official", "bundled")
        if kind == "official":
            assert url.startswith("https://"), f"bad url for {name}"
        else:
            assert url == "", f"bundled row must not link: {name}"


def test_official_urls_are_known_pages():
    urls = [r[2] for r in drivers.DRIVER_ROWS if r[3] == "official"]
    assert any("developer.android.com" in u for u in urls)
    assert any("samsung" in u for u in urls)


def test_hw_ids_present():
    for vid in ("0E8D", "05C6", "1782", "04E8"):
        assert vid in drivers.HW_IDS


def test_check_drivers_never_raises():
    rep = drivers.check_drivers(adb_bin=None, fb_bin=None)
    assert isinstance(rep, str) and "adb" in rep.lower()


def test_install_driver_folder_guards():
    import os
    import platform
    import tempfile

    if platform.system() != "Windows":
        # Linux/CI: Windows-only message, no raise, any folder
        msg = drivers.install_driver_folder("/no/such/folder")
        assert "windows" in msg.lower()
    else:
        # non-existent folder -> friendly message, no raise
        msg = drivers.install_driver_folder("C:\\no\\such\\folder")
        assert "folder" in msg.lower()
        # existing folder without .inf files
        with tempfile.TemporaryDirectory() as td:
            msg2 = drivers.install_driver_folder(td)
            assert ".inf" in msg2
