"""Release Manager backend for Hamza GSM Tool v7 (stdlib only).

Ye module tool ke andar "Publish Update" tab ko power deta hai:

  * build_release(): maujooda tool folder ko HamzaGSMTool-vX.Y.zip me pack
    karta hai + version.json banata hai (download_url tumhari site par).
  * Phir sirf 2 files GitHub repo me upload karni hain -- tool khud browser
    me upload page khol deta hai aur Roman Urdu steps dikhata hai.

Exclude list: users.db (har PC ke apne accounts), update_config.json
(har PC ki apni setting), releases/ (nesting se bachao), __pycache__.
"""

import json
import os
import re
import urllib.parse
import zipfile

TOOL_DIR = os.path.dirname(os.path.abspath(__file__))
TOKEN_FILE = os.path.join(TOOL_DIR, "github_token.json")

EXCLUDE_DIRS = {"releases", "__pycache__", ".git"}
EXCLUDE_FILES = {"users.db", "update_config.json", "github_token.json",
                 "backup_config.json"}
EXCLUDE_EXTS = {".pyc"}


def sanitize_version(v):
    """'v7.1 beta' -> '7.1'. Sirf digits aur dots rakho."""
    v = str(v).strip().lower().lstrip("v")
    v = re.sub(r"[^0-9.]", "", v).strip(".")
    return v


def site_base_from_update_url(update_url):
    """'https://USER.github.io/gsmtool/version.json' -> base URL."""
    u = (update_url or "").strip().rstrip("/")
    if u.lower().endswith("/version.json"):
        u = u[: -len("/version.json")]
    return u


def github_upload_url(update_url):
    """Site URL se GitHub upload page ka link banao. Na ban sake to ''."""
    base = site_base_from_update_url(update_url)
    try:
        host = urllib.parse.urlparse(base).hostname or ""
    except Exception:  # noqa: BLE001 - parse fail -> no link
        return ""
    if host.endswith(".github.io"):
        user = host[: -len(".github.io")]
        path = urllib.parse.urlparse(base).path.strip("/")
        repo = path.split("/")[0] if path else ""
        if user and repo:
            return f"https://github.com/{user}/{repo}/upload/main"
    return ""


def parse_repo(update_url):
    """Site URL se (owner, repo) nikalo. Na mile to (None, None)."""
    base = site_base_from_update_url(update_url)
    try:
        parts = urllib.parse.urlparse(base)
        host, path = parts.hostname or "", parts.path.strip("/")
    except Exception:  # noqa: BLE001 - parse fail -> no repo
        return None, None
    if host.endswith(".github.io") and path:
        return host[: -len(".github.io")], path.split("/")[0]
    return None, None


# ------------------------- github token -------------------------
def save_token(token, token_file=TOKEN_FILE):
    """PAT ko local file me save karo (sirf is PC par). (ok, msg)."""
    token = (token or "").strip()
    if not token:
        return False, "Token khaali hai -- pehle GitHub se token banao."
    if not (token.startswith("ghp_") or token.startswith("github_pat_")):
        return False, ("Ye GitHub token nahi lag raha -- token 'ghp_' ya "
                       "'github_pat_' se shuru hota hai.")
    try:
        with open(token_file, "w", encoding="utf-8") as fh:
            json.dump({"token": token}, fh)
        try:
            os.chmod(token_file, 0o600)
        except Exception:  # noqa: BLE001 - Windows par ignore
            pass
        return True, "Token save ho gaya (sirf is PC par, release ZIP me nahi jata)."
    except OSError as exc:
        return False, f"Save nahi hua: {exc}"


def load_token(token_file=TOKEN_FILE):
    """Saved token wapis do, na ho to ''."""
    if os.path.isfile(token_file):
        try:
            with open(token_file, encoding="utf-8") as fh:
                return str(json.load(fh).get("token", "")).strip()
        except Exception:  # noqa: BLE001 - corrupt file -> treat as missing
            return ""
    return ""


def token_saved(token_file=TOKEN_FILE):
    return bool(load_token(token_file))


TOKEN_GUIDE = """GitHub Token banane ke steps (sirf EK dafa karna hai):

1) github.com kholo (login ho)
2) Upar right corner me apni PROFILE PHOTO dabao -> Settings
3) Neeche scroll karo -> Developer settings
4) Personal access tokens -> Tokens (classic)
5) Generate new token -> Generate new token (classic)
6) Note me likho: HamzaGSMTool
7) Expiration: No expiration (ya 1 year)
8) Neeche "repo" wale box par TICK karo (poora repo section)
9) Generate token dabao -> token COPY karo (dobara nahi dikhega!)
10) Is tool me neeche paste karke Save Token dabao

Token sirf tumhare PC par save hota hai -- kisi ko mat dikhao, kisi ko
mat bhejo. Agar kabhi leak ho jaye to GitHub se revoke kar dena."""


# ------------------------- github api publish -------------------------
def _gh_api(method, url, token, data=None):
    """GitHub REST API call (stdlib urllib). (status_code, json_dict)."""
    import urllib.error
    import urllib.request

    body = json.dumps(data).encode("utf-8") if data is not None else None
    req = urllib.request.Request(url, data=body, method=method)
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("Accept", "application/vnd.github+json")
    req.add_header("User-Agent", "HamzaGSMTool")
    if body is not None:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode("utf-8") or "{}"
            return resp.status, json.loads(raw)
    except urllib.error.HTTPError as exc:
        try:
            detail = json.loads(exc.read().decode("utf-8") or "{}")
        except Exception:  # noqa: BLE001 - unreadable body
            detail = {}
        if not isinstance(detail, dict):
            detail = {}
        return exc.code, detail
    except Exception as exc:  # noqa: BLE001 - network fail
        return 0, {"message": f"Network error: {exc}"}


def publish_to_github(tool_dir=TOOL_DIR, new_version="", notes="",
                      progress=None):
    """One-click publish: release build + GitHub upload. (ok, message).

    progress: optional callback fn(msg) for live log updates.
    Homepage dynamic hai (version.json se version/badge/notes aate hain),
    is liye sirf ZIP + version.json upload hoti hain.
    """
    import base64

    def say(msg):
        if progress:
            try:
                progress(msg)
            except Exception:  # noqa: BLE001 - progress must never break publish
                pass

    token = load_token(os.path.join(tool_dir, "github_token.json"))
    if not token:
        return (False, "GitHub token save nahi hai -- pehle token paste karke "
                       "'Save Token' dabao (Token kaise banayen? button dekho).")

    update_url = ""
    cfg_path = os.path.join(tool_dir, "update_config.json")
    if os.path.isfile(cfg_path):
        try:
            with open(cfg_path, encoding="utf-8") as fh:
                update_url = str(json.load(fh).get("update_url", "")).strip()
        except Exception:  # noqa: BLE001 - config unreadable
            update_url = ""
    owner, repo = parse_repo(update_url)
    if not owner or not repo:
        return (False, "Pehle \u2699 Update Settings me apni version.json wali "
                       "site ka URL save karo.")

    say("Step 1/3: release package ban raha hai...")
    ok, msg, paths = build_release(tool_dir=tool_dir, new_version=new_version,
                                   notes=notes)
    if not ok:
        return False, msg
    ver = paths["version"]
    say(f"Step 1/3 done: {os.path.basename(paths['zip'])}")

    say("Step 2/3: GitHub se connect ho raha hai...")
    uploads = [
        (paths["zip"], f"HamzaGSMTool-v{ver}.zip"),
        (paths["json"], "version.json"),
    ]
    for local_path, remote_name in uploads:
        api = (f"https://api.github.com/repos/{owner}/{repo}"
               f"/contents/{remote_name}")
        status, data = _gh_api("GET", api, token)
        if status == 401:
            return (False, "Token ghalat ya expire hai -- naya token banao "
                           "aur dobara save karo.")
        if status not in (200, 404):
            return (False, f"GitHub error ({status}): "
                           f"{data.get('message', 'unknown')}")
        sha = data.get("sha") if status == 200 else None

        with open(local_path, "rb") as fh:
            content = base64.b64encode(fh.read()).decode("ascii")
        payload = {"message": f"Publish v{ver} (auto via Hamza GSM Tool)",
                   "content": content}
        if sha:
            payload["sha"] = sha
        say(f"Step 2/3: {remote_name} upload ho raha hai...")
        status, data = _gh_api("PUT", api, token, payload)
        if status == 401:
            return (False, "Token ghalat ya expire hai -- naya token banao "
                           "aur dobara save karo.")
        if status not in (200, 201):
            hint = data.get("message", "unknown")
            if status == 403 and "rate limit" in str(hint).lower():
                hint += " -- thori der baad dobara try karo."
            return False, f"Upload fail ({remote_name}): {hint}"
        say(f"Step 2/3 done: {remote_name} ✓")

    say("Step 3/3: website refresh ho rahi hai (1-2 minute)...")
    return (True,
            f"v{ver} PUBLISH ho gaya! Website 1-2 minute me update ho jayegi, "
            f"phir tool khud sab ko update dega. Kuch haath se nahi karna para!")


def build_release(tool_dir=TOOL_DIR, new_version="", notes=""):
    """Release ZIP + version.json banao. (ok, message, paths_dict) return."""
    ver = sanitize_version(new_version)
    if not ver:
        return False, "Version khaali hai -- misal: 7.1", {}

    # update_url se site ka base URL nikalo (download link ke liye)
    update_url = ""
    cfg_path = os.path.join(tool_dir, "update_config.json")
    if os.path.isfile(cfg_path):
        try:
            with open(cfg_path, encoding="utf-8") as fh:
                update_url = str(json.load(fh).get("update_url", "")).strip()
        except Exception:  # noqa: BLE001 - config unreadable -> manual URL
            update_url = ""
    base = site_base_from_update_url(update_url)
    if not base:
        return (False,
                "Pehle Update Settings (⚙) me apni version.json wali site ka "
                "URL save karo, phir release banao.", {})

    rel_dir = os.path.join(tool_dir, "releases")
    os.makedirs(rel_dir, exist_ok=True)

    # version.py me naya version stamp karo taake ZIP wala tool sahi version
    # report kare (warna update loop lag jayega). Baad me wapis restore.
    vpy = os.path.join(tool_dir, "version.py")
    orig_vpy = None
    if os.path.isfile(vpy):
        with open(vpy, encoding="utf-8") as fh:
            orig_vpy = fh.read()
        with open(vpy, "w", encoding="utf-8") as fh:
            fh.write('"""Single source of truth for the tool version."""\n\n'
                     f'__version__ = "{ver}"\n')
    try:
        zip_name = f"HamzaGSMTool-v{ver}.zip"
        zip_path = os.path.join(rel_dir, zip_name)
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for root, dirs, files in os.walk(tool_dir):
                dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
                for fn in files:
                    if fn in EXCLUDE_FILES:
                        continue
                    if os.path.splitext(fn)[1].lower() in EXCLUDE_EXTS:
                        continue
                    full = os.path.join(root, fn)
                    arc = os.path.relpath(full, tool_dir)
                    zf.write(full, arc)
    finally:
        if orig_vpy is not None:
            with open(vpy, "w", encoding="utf-8") as fh:
                fh.write(orig_vpy)

    manifest = {
        "version": ver,
        "download_url": f"{base}/{zip_name}",
        "notes": notes.strip() or f"Hamza GSM Tool v{ver}",
    }
    json_path = os.path.join(rel_dir, "version.json")
    with open(json_path, "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, ensure_ascii=False, indent=2)

    upload = github_upload_url(update_url)
    steps = (
        f"Release tayyar! 2 files bani hain (releases folder me):\n"
        f"  1) {zip_name}\n"
        f"  2) version.json\n\n"
        f"Ab GitHub par upload karo:\n"
        f"  1) Apne gsmtool repo me 'Add file' -> 'Upload files' kholo\n"
        f"     {upload if upload else '(repo kholo, Add file dabao)'}\n"
        f"  2) Dono files drag-drop karo -> 'Commit changes'\n"
        f"  3) 2 minute me tool khud update dega!\n\n"
        f"NOTE: users.db is ZIP me NAHI hai -- har PC ke accounts mehfooz "
        f"rahenge."
    )
    return True, steps, {"zip": zip_path, "json": json_path,
                         "upload_url": upload, "version": ver}
