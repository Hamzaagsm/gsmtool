"""Master recovery key: admin ka "alag hisab".

PC kharab ho jaye ya naya PC lo -- recovery key se kahin bhi, baghair
purani files ke, master admin ban sakte ho. Key me checksum hota hai,
is liye ghalat/tampered key pakri jati hai (offline, koi DB nahi chahiye).

Key kisi ko NA do -- ye master admin ka darwaza hai.
"""

import hashlib
import secrets

_PREFIX = "HG7"
_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # 0/O/1/I nahi (confusion)
_BODY_GROUPS = 6   # 24 chars
_CHECK_CHARS = 4   # checksum group


def _rand_chars(n):
    return "".join(secrets.choice(_ALPHABET) for _ in range(n))


def _checksum(body):
    """body (24 chars) -> 4-char checksum."""
    digest = hashlib.sha256(body.encode("ascii")).hexdigest()
    num = int(digest, 16)
    out = []
    for _ in range(_CHECK_CHARS):
        out.append(_ALPHABET[num % len(_ALPHABET)])
        num //= len(_ALPHABET)
    return "".join(out)


def generate_key():
    """Nayi recovery key: HG7-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-CCCC"""
    groups = [_rand_chars(4) for _ in range(_BODY_GROUPS)]
    body = "".join(groups)
    groups.append(_checksum(body))
    return _PREFIX + "-" + "-".join(groups)


def normalize(key):
    return (key or "").strip().upper().replace(" ", "").replace("-", "")


def verify_key(key):
    """Checksum check -- True sirf asli key par."""
    n = normalize(key)
    expect_len = len(_PREFIX) + _BODY_GROUPS * 4 + _CHECK_CHARS
    if len(n) != expect_len or not n.startswith(_PREFIX):
        return False
    rest = n[len(_PREFIX):]
    if any(c not in _ALPHABET for c in rest):
        return False
    body, check = rest[:_BODY_GROUPS * 4], rest[_BODY_GROUPS * 4:]
    return check == _checksum(body)
