"""Sanity tests for brands.py -- no phone needed."""

from brands import BRANDS, IMEI_WORKFLOW, SPD_NOTES, brand_names, cheat_sheet, FRP_WORKFLOW

names = brand_names()
assert len(names) >= 10, f"expected 10+ brands, got {len(names)}"
for key in ("tecno", "infinix", "samsung", "xiaomi", "itel"):
    assert key in names, f"missing brand: {key}"

required = ("name", "chipsets", "modes", "external_tools",
            "frp_note", "imei_note", "mdm_note")
for key, b in BRANDS.items():
    for field in required:
        assert field in b, f"{key} missing field {field}"
    assert b["modes"], f"{key} has no modes"

sheet = cheat_sheet("infinix")
assert "Infinix" in sheet and "MDM" in sheet
assert "nahi mila" in cheat_sheet("nokia-fake-brand")

assert "ORIGINAL IMEI" in IMEI_WORKFLOW
assert "SPD" in SPD_NOTES and "FRP" in FRP_WORKFLOW

print(f"All brand tests passed ({len(names)} brands).")
