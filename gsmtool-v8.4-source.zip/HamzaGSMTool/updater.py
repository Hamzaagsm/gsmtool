"""Update framework for Hamza GSM Tool (stdlib only).

Two update channels:

1. MANUAL (default, needs no setup): Muse ships a new HamzaGSMTool-vX.zip,
   the user runs UPDATE.bat -- users.db is backed up and restored, so
   accounts are never lost.

2. GITHUB (optional): set "update_url" in update_config.json to a version.json
   file (e.g. in a GitHub repo). The tool then checks it and can download
   the new release itself.

Honest note: fully-automatic updates need SOME server to check against --
there is no magic. This module implements the check + download truthfully;
it never pretends to update when there is nothing configured.
"""

import json
import os
import urllib.request

import paths

from version import __version__ as CURRENT_VERSION

CONFIG_FILE = os.path.join(paths.base_dir(), "update_config.json")


def parse_version(v):
    """'5.0' -> (5, 0). Non-numeric bits are ignored."""
    parts = []
    for chunk in str(v).strip().split("."):
        digits = "".join(ch for ch in chunk if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts) or (0,)


def is_newer(remote, local=CURRENT_VERSION):
    """True if remote version string is newer than local."""
    return parse_version(remote) > parse_version(local)


def load_config():
    """Return {'update_url': ...}; empty url means MANUAL channel."""
    if os.path.isfile(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, dict):
                return {"update_url": str(data.get("update_url", "")).strip()}
        except Exception:
            pass
    return {"update_url": ""}


def check_for_updates():
    """Check for a newer release.

    Returns (status, message, info). status is one of:
      'not_configured' -- no update_url set (MANUAL channel)
      'uptodate'       -- already on latest
      'available'      -- newer version found (info has version/download_url/notes)
      'error'          -- check failed
    """
    url = load_config().get("update_url", "")
    if not url:
        return (
            "not_configured",
            "Auto-update server set nahi hai.\n\n"
            "2 raste hain:\n"
            "1) Muse se nayi ZIP lo aur UPDATE.bat chalao (sab se aasan).\n"
            "2) Apna GitHub repo banao -- main uska link yahan laga dunga,\n"
            "   phir tool khud naye version check karega.",
            {},
        )
    try:
        with urllib.request.urlopen(url, timeout=15) as resp:
            info = json.loads(resp.read().decode("utf-8"))
    except Exception as exc:  # noqa: BLE001 -- report to user
        return ("error", f"Update check fail ho gaya:\n{exc}", {})
    remote = str(info.get("version", "")).strip()
    if not remote:
        return ("error", "Server se version number nahi mila.", {})
    if is_newer(remote):
        notes = str(info.get("notes", "")).strip()
        msg = (f"Naya version available hai: v{remote}\n"
               f"(tumhare pas v{CURRENT_VERSION} hai)\n")
        if notes:
            msg += f"\n{notes}\n"
        return ("available", msg, info)
    return ("uptodate", f"Tumhara tool latest hai (v{CURRENT_VERSION}).", {})


def download_update(url, dest_path):
    """Download a file (http/https/file). Returns dest_path."""
    urllib.request.urlretrieve(url, dest_path)
    return dest_path


def create_apply_script(app_dir, zip_path):
    """Write _apply_update.bat next to the app; return its path.

    The script (run detached, then the app exits): waits for the app to
    close, backs up users.db, extracts the zip over app_dir, restores
    users.db if missing, restarts the app, deletes itself.
    Expects our zips' layout: top-level HamzaGSMTool/ folder.
    """
    script = os.path.join(app_dir, "_apply_update.bat")
    backup = os.path.join(os.environ.get("TEMP", app_dir),
                           "HamzaGSM_users_backup.db")
    content = (
        "@echo off\r\n"
        "title Hamza GSM Tool - Updating...\r\n"
        "timeout /t 4 /nobreak >nul\r\n"
        f'set "HERE={app_dir}"\r\n'
        f'set "ZIP={zip_path}"\r\n'
        f'set "BACKUP={backup}"\r\n'
        'if exist "%HERE%\\users.db" copy /y "%HERE%\\users.db" "%BACKUP%" >nul\r\n'
        'set "TMPD=%TEMP%\\HamzaGSMUpdate"\r\n'
        'rmdir /s /q "%TMPD%" 2>nul\r\n'
        'mkdir "%TMPD%" 2>nul\r\n'
        'powershell -NoProfile -Command "Expand-Archive -Path \'%ZIP%\' '
        '-DestinationPath \'%TMPD%\' -Force"\r\n'
        'if exist "%TMPD%\\HamzaGSMTool\\app.py" '
        'xcopy /y /e "%TMPD%\\HamzaGSMTool\\*" "%HERE%\\" >nul\r\n'
        'if not exist "%HERE%\\users.db" if exist "%BACKUP%" '
        'copy /y "%BACKUP%" "%HERE%\\users.db" >nul\r\n'
        'rmdir /s /q "%TMPD%" 2>nul\r\n'
        'del "%ZIP%" 2>nul\r\n'
        'start "" /d "%HERE%" python app.py\r\n'
        "(goto) 2>nul & del \"%~f0\"\r\n"
    )
    with open(script, "w", encoding="utf-8") as fh:
        fh.write(content)
    return script


def save_update_url(url):
    """Save the version.json URL the tool checks. Returns the saved url."""
    url = str(url).strip()
    with open(CONFIG_FILE, "w", encoding="utf-8") as fh:
        json.dump({"update_url": url}, fh, indent=2)
    return url
