@echo off
title Hamza GSM Tool
cd /d "%~dp0"
python app.py
pause
