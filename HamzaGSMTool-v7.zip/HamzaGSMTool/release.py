"""Release Manager backend for Hamza GSM Tool v7 (stdlib only).

Ye module tool ke andar "Publish Update" tab ko power deta hai:

  * build_release(): maujooda tool folder ko HamzaGSMTool-vX.Y.zip me pack
    karta hai + version.json banata hai (download_url tumhari site par).
  * Phir sirf 2 files GitHub repo me upload karni hain -- tool khud browser
    me upload page khol deta hai aur Roman Urdu steps dikhata hai.

Exclude list: users.db (har PC ke apne accounts), update_config.json
(har PC ki apni setting), releases/ (nesting se bachao), __pycache__.
"""

import json
import os
import re
import urllib.parse
import zipfile

TOOL_DIR = os.path.dirname(os.path.abspath(__file__))

EXCLUDE_DIRS = {"releases", "__pycache__", ".git"}
EXCLUDE_FILES = {"users.db", "update_config.json"}
EXCLUDE_EXTS = {".pyc"}


def sanitize_version(v):
    """'v7.1 beta' -> '7.1'. Sirf digits aur dots rakho."""
    v = str(v).strip().lower().lstrip("v")
    v = re.sub(r"[^0-9.]", "", v).strip(".")
    return v


def site_base_from_update_url(update_url):
    """'https://USER.github.io/gsmtool/version.json' -> base URL."""
    u = (update_url or "").strip().rstrip("/")
    if u.lower().endswith("/version.json"):
        u = u[: -len("/version.json")]
    return u


def github_upload_url(update_url):
    """Site URL se GitHub upload page ka link banao. Na ban sake to ''."""
    base = site_base_from_update_url(update_url)
    try:
        host = urllib.parse.urlparse(base).hostname or ""
    except Exception:  # noqa: BLE001 - parse fail -> no link
        return ""
    if host.endswith(".github.io"):
        user = host[: -len(".github.io")]
        path = urllib.parse.urlparse(base).path.strip("/")
        repo = path.split("/")[0] if path else ""
        if user and repo:
            return f"https://github.com/{user}/{repo}/upload/main"
    return ""


def build_release(tool_dir=TOOL_DIR, new_version="", notes=""):
    """Release ZIP + version.json banao. (ok, message, paths_dict) return."""
    ver = sanitize_version(new_version)
    if not ver:
        return False, "Version khaali hai -- misal: 7.1", {}

    # update_url se site ka base URL nikalo (download link ke liye)
    update_url = ""
    cfg_path = os.path.join(tool_dir, "update_config.json")
    if os.path.isfile(cfg_path):
        try:
            with open(cfg_path, encoding="utf-8") as fh:
                update_url = str(json.load(fh).get("update_url", "")).strip()
        except Exception:  # noqa: BLE001 - config unreadable -> manual URL
            update_url = ""
    base = site_base_from_update_url(update_url)
    if not base:
        return (False,
                "Pehle Update Settings (⚙) me apni version.json wali site ka "
                "URL save karo, phir release banao.", {})

    rel_dir = os.path.join(tool_dir, "releases")
    os.makedirs(rel_dir, exist_ok=True)

    zip_name = f"HamzaGSMTool-v{ver}.zip"
    zip_path = os.path.join(rel_dir, zip_name)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(tool_dir):
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
            for fn in files:
                if fn in EXCLUDE_FILES:
                    continue
                if os.path.splitext(fn)[1].lower() in EXCLUDE_EXTS:
                    continue
                full = os.path.join(root, fn)
                arc = os.path.relpath(full, tool_dir)
                zf.write(full, arc)

    manifest = {
        "version": ver,
        "download_url": f"{base}/{zip_name}",
        "notes": notes.strip() or f"Hamza GSM Tool v{ver}",
    }
    json_path = os.path.join(rel_dir, "version.json")
    with open(json_path, "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, ensure_ascii=False, indent=2)

    upload = github_upload_url(update_url)
    steps = (
        f"Release tayyar! 2 files bani hain (releases folder me):\n"
        f"  1) {zip_name}\n"
        f"  2) version.json\n\n"
        f"Ab GitHub par upload karo:\n"
        f"  1) Apne gsmtool repo me 'Add file' -> 'Upload files' kholo\n"
        f"     {upload if upload else '(repo kholo, Add file dabao)'}\n"
        f"  2) Dono files drag-drop karo -> 'Commit changes'\n"
        f"  3) 2 minute me tool khud update dega!\n\n"
        f"NOTE: users.db is ZIP me NAHI hai -- har PC ke accounts mehfooz "
        f"rahenge."
    )
    return True, steps, {"zip": zip_path, "json": json_path,
                         "upload_url": upload}
