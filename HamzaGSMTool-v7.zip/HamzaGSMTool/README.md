# Hamza GSM Tool v7.0 (professional edition)

## v7 me naya: PROFESSIONAL TOOLKIT (tumhari demand par)
- **🔌 Drivers tab**: "Check Installed Drivers" (adb/fastboot + Windows driver
  store), "Install Driver from Folder" (pnputil), aur official download links
  (Google USB Driver, Samsung USB Driver, Platform-Tools) + MTK/SPD/Qualcomm
  guidance.
- **📍 Test Point tab**: 13 brands ke SAFE EDL/BROM/Download-mode tareeqe,
  sakht test-point warnings (ghalat point = dead board!), exact model ka
  one-click test-point search, aur honest FRP notes.
- **💾 Backup tab**: "Backup Installed APKs" + "Save Device Report" --
  flashing se PEHLE backup ki aadat.
- **📦 Publish Update tab**: nayi version khud release karo -- version number
  likho → "Build Release Package" → 2 files (ZIP + version.json) GitHub par
  upload karo → tool khud users ko update dega. **Ab tumhe kisi ka wait nahi!**
- **Log tools**: "Save Log" + "Clear" buttons.

## v6 me naya: KHUD UPDATE KARO (tumhari demand par)
- **"⚙" Settings button** ("Check for Updates" ke paas): apni website ka
  `version.json` link paste karo → Save. Uske baad tool khud naye version
  check karega -- **tumhara apna update system, tumhare control me!**
- **One-click auto-install**: naya version mile to "⬇ Install Now" dabao --
  tool download karke **khud install** ho jayega aur dobara khul jayega.
  Users/passwords mehfooz rehte hain.
- **UPDATE.bat** ab bhi hai (manual tareeqa).
- **Website**: `website/` folder me tumhari download website ready hai
  (`index.html` + `version.json`) + **DEPLOY-URDU.md** me step-by-step guide
  (GitHub free account → repo → Pages ON → 10 minute me live).

## v5 me naya: UPDATES (tumhari demand par)
- **"Check for Updates" button** (upar, Refresh ke paas): dabao to tool batayega
  naya version hai ya nahi.
- **UPDATE.bat (one-click updater)**: jab Muse tumhe nayi ZIP de, to nayi ZIP
  isi folder me rakho aur **UPDATE.bat** chalao -- nayi files lag jayengi aur
  **tumhare users.db (accounts) mehfooz rahenge** (backup + restore automatic).
- **Imaandaar baat**: khud-ba-khud (bina server ke) update hona mumkin nahi --
  updates kahin publish hone chahiye. 2 raste: (1) Muse se nayi ZIP + UPDATE.bat
  (sab se aasan, abhi yehi active hai), (2) apna free GitHub repo banao --
  main uska link `update_config.json` me laga dunga, phir tool khud check karega.

## v4 me naya kya hai
- **Login system**: tool kholte hi username/password login. Pehli dafa apna
  **Admin account** banao, phir Users tab (sirf admin ko nazar aata hai) se
  naye users add karo, kisi user ko **Block/Unblock** karo, password reset karo.
  Passwords hashed save hote hain. Pehli run par `users.db` khud ban jata hai
  (ye file ZIP me shaamil NAHI hoti -- har PC par apna admin banega).
- **Naye tabs**: **META Mode** (MTK IMEI/NVRAM ke liye dedicated work area +
  PTA warning), **SPD / Unisoc** (dedicated section), **Transsion ID**
  (Tecno/Infinix/Itel ID-lock apps ka scan + disable/uninstall).
- Tabs ab: Brands, Device, MDM tools, Transsion ID, META Mode, SPD / Unisoc,
  Flashing, Guides, Users (admin).

## v3 me naya kya hai
- **Rangen UI**: dark theme, purple header, status bar
- **Brand dashboard**: 13 brands ke rangeen tiles (tap karo to detail khule)
- **Models database**: 91 popular Pakistan-market models -- search box se filter karo
  (Model | Code | Chipset). Code sirf wahan likha hai jahan confident hain;
  baqi par "--" hai. **Hamesha exact code device par verify karo!**
- Tabs: **Brands** (pehla), Device, MDM tools, Flashing, **Guides** (IMEI/FRP/SPD)

## SUPER EASY INSTALL (Python nahi aata to ye wala tareeqa)

1. `HamzaGSMTool-v4.zip` download karke **extract** karo
2. Folder ke andar **`INSTALL.bat` par double-click** karo -- bas!
   - Ye khud Python install karega (agar nahi hai)
   - Ye khud platform-tools (adb/fastboot) download karega
   - Ye Desktop par **"Hamza GSM Tool.bat"** shortcut bana dega
3. Ab hamesha Desktop wale shortcut par double-click karo -- tool khul jayega

> Phone connect karne se pehle: chipset ke USB drivers install karo
> (MTK: MediaTek VCOM / Qualcomm: QDLoader), aur phone me
> Settings > Developer options > **USB debugging ON** karo.

## Manual setup (agar Python already aata hai)


A servicing toolkit for mobile technicians: device info, reboot modes
(system/recovery/bootloader/**EDL**/**META**/sideload), MDM-app scan &
disable, bootloader unlock/lock, fastboot flashing, brand cheat sheets for
the Pakistan market (Tecno, Infinix, Itel, Samsung, Xiaomi, Oppo, Vivo,
Realme, Motorola, Nokia, OnePlus, Huawei, QMobile), plus honest IMEI/FRP/SPD
workflow guides -- all through the public ADB/Fastboot protocols.
No Python packages needed.

> **Only use on your own devices or with the owner's clear permission.**
> Flashing the wrong firmware can permanently brick a phone.
> **IMEI: sirf ORIGINAL IMEI restore karo -- Pakistan me IMEI tamper karna
> illegal hai (PTA).**

## What it CAN do

- Detect devices over ADB and Fastboot; read model/Android/patch/CPU info
- Reboot to system / recovery / bootloader / EDL / **META mode** / sideload
  (META mode = jahan vendor META tools IMEI/NVRAM kaam karte hain)
- Scan installed apps for MDM-like packages, show active device admins,
  disable or uninstall the apps **you select** (disable is reversible)
- Bootloader unlock/lock, flash partitions, install APKs
- **Brands tab**: Pakistan ke 13 brands ki cheat sheets -- key combos,
  chipset info, recommended external tools, FRP/IMEI/MDM notes per brand
- **Guides**: IMEI workflow (META), FRP honest notes, SPD/Unisoc notes

## What it CANNOT do (honest limits)

- **No exploit-based bypasses.** Removing FRP/MDM on latest security patches
  without ADB access needs chipset exploits and signed loader files --
  that is what paid tools (UMT, Chimera, Octoplus) sell. This toolkit does
  not and cannot include those.
- **IMEI repair needs the vendor META tool.** Ye toolkit phone ko META mode
  me bhej sakta hai aur workflow samjhata hai, lekin actual IMEI write
  MediaTek ke Modem META / Maui META jaise vendor utility se hota hai
  (toolkit ka hissa nahi). Sirf original IMEI restore karo -- illegal nahi.
- **No MTK BROM / SPD / EDL flashing.** For dead phones use SP Flash Tool
  (MTK), SPD Upgrade Tool (Unisoc) or QFIL (Qualcomm) with the correct
  firmware for the exact model.
- MDM removed this way can **come back** after a factory reset or if the
  phone re-contacts the company's server -- warn the customer first.

## Setup (Windows PC)

1. Install Python 3.10+ from python.org (tick "Add python.exe to PATH";
   this also installs tkinter for the GUI).
2. Download Google **platform-tools** (search "Android platform-tools
   download"), extract it, and either add it to PATH or copy `adb.exe` +
   `fastboot.exe` into `gsmtool/platform-tools/`.
3. Install your chipset's USB drivers (MTK: MediaTek VCOM; Qualcomm:
   QDLoader HS-USB).
4. On the phone: enable Developer options > USB debugging, connect via USB,
   accept the RSA prompt.

## Run

```bash
cd gsmtool
python app.py        # graphical version (4 tabs: Device, MDM tools, Flashing, Brands & Guides)
python cli.py devices
python cli.py info
python cli.py scan
python cli.py brands
python cli.py brand infinix
python cli.py imei-guide
```

## Test without a phone

```bash
python test_features.py     # parser unit tests, no device needed
```

## Files

- `app.py` -- tkinter GUI v3 (Brands dashboard / Device / MDM tools / Flashing / Guides)
- `models.py` -- Pakistan-market model database (91 models, 13 brands)
- `test_models.py` -- model database tests
- `cli.py` -- command-line version of the same features
- `features.py` -- feature logic (parsers are unit-tested)
- `brands.py` -- Pakistan market brand profiles + IMEI/FRP/SPD guides
- `adbwrap.py` -- adb/fastboot runner
- `test_features.py`, `test_brands.py` -- offline tests
