#!/usr/bin/env python3
"""Hamza GSM Tool v7 -- professional servicing toolkit GUI with login system.

Run:  python app.py
Requires Google platform-tools (adb/fastboot) on PATH or in ./platform-tools/

v7: Drivers tab (driver check/install + official links), Test Point / EDL tab
(per-brand safe key methods + model search), Backup tab (APK + device report),
Publish Update tab (one-click release builder -> GitHub), Save/Clear log.
v6: self-hosted updates. v5: update framework. v4: login system.
All servicing logic still comes from features.py.
"""

import os
import queue
import threading
import tkinter as tk
import webbrowser
from datetime import datetime
from tkinter import filedialog, messagebox, scrolledtext, ttk

import adbwrap
import brands
import drivers
import edl
import features
import models
import release
import updater
import users
from version import __version__

APP_TITLE = f"Hamza GSM Tool v{__version__}"

# Local accounts database, next to this script. Created on first run.
USERS_DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "users.db")

# ------------------------------- theme -------------------------------
BG = "#1e1e2e"        # dark slate
PANEL = "#2a2a3e"
CARD = "#31314a"
FG = "#e8e8f0"
MUTED = "#a0a0b8"
ACCENT = "#7c6cf0"    # purple
TEAL = "#00d4aa"
DANGER = "#ff5c5c"
WARN_BG = "#4a2a2a"

# Brand tiles: (key, badge text, display name, tile color, text color).
# ORIGINAL badge artwork -- initials only, not official logos.
BRAND_TILES = [
    ("samsung", "S", "Samsung", "#1428A0", "#ffffff"),
    ("xiaomi", "Mi", "Xiaomi", "#FF6900", "#ffffff"),
    ("tecno", "T", "Tecno", "#0A84FF", "#ffffff"),
    ("infinix", "i", "Infinix", "#00B140", "#ffffff"),
    ("itel", "itel", "itel", "#D7263D", "#ffffff"),
    ("oppo", "O", "Oppo", "#01996B", "#ffffff"),
    ("vivo", "V", "Vivo", "#4D7CFE", "#ffffff"),
    ("realme", "R", "Realme", "#FFC300", "#1e1e2e"),
    ("motorola", "M", "Motorola", "#2E5BFF", "#ffffff"),
    ("nokia", "N", "Nokia", "#005AFF", "#ffffff"),
    ("oneplus", "1+", "OnePlus", "#EB0028", "#ffffff"),
    ("huawei", "H", "Huawei", "#C7000B", "#ffffff"),
    ("qmobile", "Q", "QMobile", "#00B8A9", "#ffffff"),
]
TILE_W, TILE_H, TILE_PAD, TILE_COLS = 168, 104, 18, 4


def rounded_rect(cv, x1, y1, x2, y2, r, **kwargs):
    """Rounded rectangle on a Canvas (Tk has no native one)."""
    pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r,
           x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2,
           x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
    return cv.create_polygon(pts, smooth=True, **kwargs)


class ToolApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.withdraw()  # hidden until login succeeds
        self.title(APP_TITLE)
        self.geometry("1280x760")
        self.configure(bg=BG)
        self.adb = adbwrap.find_binary("adb")
        self.fb = adbwrap.find_binary("fastboot")
        self.serial = tk.StringVar()
        self.status_var = tk.StringVar()
        self._jobs = queue.Queue()
        self._brand_key = None
        self.current_user = None
        self.current_is_admin = False
        self._users_tab_added = False
        self._build()
        self._poll_jobs()
        self._update_status()
        self.log(f"adb: {self.adb or 'NOT FOUND'}")
        self.log(f"fastboot: {self.fb or 'NOT FOUND'}")
        if not self.adb or not self.fb:
            self.log("WARNING: install platform-tools (see README.md).")
        self._login_flow()  # modal; destroys app if cancelled

    # --------------------------- ui builders ---------------------------
    def _build(self):
        self._header()
        self._conn_bar()
        self._tabs()
        self._log_area()
        self._status_bar()

    def _header(self):
        head = tk.Frame(self, bg=ACCENT, height=66)
        head.pack(fill="x")
        head.pack_propagate(False)
        tk.Label(head, text=f"  HAMZA GSM TOOL  v{__version__}", bg=ACCENT, fg="#ffffff",
                 font=("Arial", 20, "bold")).pack(side="left", pady=10)
        tk.Label(head, text="Mobile Servicing Toolkit  •  Pakistan Edition",
                 bg=ACCENT, fg="#e0dcff",
                 font=("Arial", 10)).pack(side="left", padx=12, pady=10)
        strip = tk.Frame(self, bg=TEAL, height=4)
        strip.pack(fill="x")

    def _conn_bar(self):
        bar = tk.Frame(self, bg=BG, pady=6)
        bar.pack(fill="x", padx=10)
        tk.Label(bar, text="Device serial (blank = default):",
                 bg=BG, fg=MUTED, font=("Arial", 10)).pack(side="left")
        tk.Entry(bar, textvariable=self.serial, width=24, bg=PANEL, fg=FG,
                 insertbackground=FG, relief="flat",
                 highlightthickness=1, highlightbackground="#3a3a55",
                 font=("Arial", 10)).pack(side="left", padx=8)
        self._btn(bar, "Refresh devices", self.refresh).pack(side="left")
        self._btn(bar, "\u27f3 Check for Updates",
                  self._check_updates, bg=CARD, fg=FG).pack(side="left", padx=6)
        self._btn(bar, "\u2699", self._update_settings,
                  bg=CARD, fg=FG).pack(side="left")
        self._btn(bar, "Logout", self._logout, bg=CARD, fg=FG).pack(side="right")

    def _tabs(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TNotebook", background=BG, borderwidth=0, tabmargins=0)
        style.configure("TNotebook.Tab", background=PANEL, foreground=MUTED,
                        padding=(12, 8), font=("Arial", 10, "bold"), borderwidth=0)
        style.map("TNotebook.Tab",
                  background=[("selected", ACCENT)],
                  foreground=[("selected", "#ffffff")])
        style.configure("Treeview", background=PANEL, foreground=FG,
                        fieldbackground=PANEL, rowheight=26, borderwidth=0,
                        font=("Arial", 10))
        style.configure("Treeview.Heading", background=CARD, foreground=FG,
                        font=("Arial", 10, "bold"), relief="flat")
        style.map("Treeview", background=[("selected", ACCENT)])

        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=10, pady=6)

        self.tab_brands = tk.Frame(self.nb, bg=BG)
        self.tab_device = tk.Frame(self.nb, bg=BG)
        self.tab_mdm = tk.Frame(self.nb, bg=BG)
        self.tab_transsion = tk.Frame(self.nb, bg=BG)
        self.tab_meta = tk.Frame(self.nb, bg=BG)
        self.tab_spd = tk.Frame(self.nb, bg=BG)
        self.tab_flash = tk.Frame(self.nb, bg=BG)
        self.tab_drivers = tk.Frame(self.nb, bg=BG)
        self.tab_edl = tk.Frame(self.nb, bg=BG)
        self.tab_backup = tk.Frame(self.nb, bg=BG)
        self.tab_guides = tk.Frame(self.nb, bg=BG)
        self.tab_release = tk.Frame(self.nb, bg=BG)
        self.tab_users = tk.Frame(self.nb, bg=BG)  # admin only, added after login
        self.nb.add(self.tab_brands, text="  Brands  ")
        self.nb.add(self.tab_device, text="  Device  ")
        self.nb.add(self.tab_mdm, text="  MDM tools  ")
        self.nb.add(self.tab_transsion, text="  Transsion ID  ")
        self.nb.add(self.tab_meta, text="  META Mode  ")
        self.nb.add(self.tab_spd, text="  SPD / Unisoc  ")
        self.nb.add(self.tab_flash, text="  Flashing  ")
        self.nb.add(self.tab_drivers, text="  Drivers  ")
        self.nb.add(self.tab_edl, text="  Test Point  ")
        self.nb.add(self.tab_backup, text="  Backup  ")
        self.nb.add(self.tab_guides, text="  Guides  ")
        self.nb.add(self.tab_release, text="  Publish  ")

        self._build_brands_tab()
        self._build_device_tab()
        self._build_mdm_tab()
        self._build_transsion_tab()
        self._build_meta_tab()
        self._build_spd_tab()
        self._build_flash_tab()
        self._build_drivers_tab()
        self._build_edl_tab()
        self._build_backup_tab()
        self._build_guides_tab()
        self._build_release_tab()
        self._build_users_tab()

    # ------------------------- brands dashboard -------------------------
    def _build_brands_tab(self):
        # dashboard (tile grid)
        self.dash_frame = tk.Frame(self.tab_brands, bg=BG)
        self.dash_frame.pack(fill="both", expand=True)
        tk.Label(self.dash_frame, text="Brand select karo:",
                 bg=BG, fg=FG, font=("Arial", 12, "bold")).pack(anchor="w",
                                                                padx=18, pady=(10, 2))
        rows = (len(BRAND_TILES) + TILE_COLS - 1) // TILE_COLS
        cw = TILE_PAD + TILE_COLS * (TILE_W + TILE_PAD)
        ch = TILE_PAD + rows * (TILE_H + TILE_PAD)
        wrap = tk.Frame(self.dash_frame, bg=BG)
        wrap.pack(expand=True)
        self.tile_canvas = tk.Canvas(wrap, width=cw, height=ch, bg=BG,
                                     highlightthickness=0)
        self.tile_canvas.pack(pady=6)
        for i, (key, badge, name, color, fg) in enumerate(BRAND_TILES):
            r, c = divmod(i, TILE_COLS)
            x1 = TILE_PAD + c * (TILE_W + TILE_PAD)
            y1 = TILE_PAD + r * (TILE_H + TILE_PAD)
            x2, y2 = x1 + TILE_W, y1 + TILE_H
            tag = f"tile_{key}"
            rounded_rect(self.tile_canvas, x1, y1, x2, y2, 20,
                         fill=color, outline="", tags=tag)
            self.tile_canvas.create_text((x1 + x2) / 2, y1 + 40, text=badge,
                                         font=("Arial", 28, "bold"), fill=fg,
                                         tags=tag)
            self.tile_canvas.create_text((x1 + x2) / 2, y2 - 24, text=name,
                                         font=("Arial", 11, "bold"), fill=fg,
                                         tags=tag)
            self.tile_canvas.tag_bind(tag, "<Button-1>",
                                      lambda _e, k=key: self.show_brand_detail(k))
            self.tile_canvas.tag_bind(tag, "<Enter>",
                                      lambda _e: self.tile_canvas.config(cursor="hand2"))
            self.tile_canvas.tag_bind(tag, "<Leave>",
                                      lambda _e: self.tile_canvas.config(cursor=""))

        # detail view (hidden until a tile is clicked)
        self.detail_frame = tk.Frame(self.tab_brands, bg=BG)

        dhead = tk.Frame(self.detail_frame, bg=BG)
        dhead.pack(fill="x", padx=12, pady=8)
        self._btn(dhead, "← Back", self.show_dashboard,
                  bg=CARD, fg=FG).pack(side="left")
        self.badge_canvas = tk.Canvas(dhead, width=56, height=56, bg=BG,
                                      highlightthickness=0)
        self.badge_canvas.pack(side="left", padx=12)
        self.detail_name = tk.Label(dhead, text="", bg=BG, fg=FG,
                                    font=("Arial", 16, "bold"))
        self.detail_name.pack(side="left")
        self.detail_count = tk.Label(dhead, text="", bg=BG, fg=MUTED,
                                     font=("Arial", 10))
        self.detail_count.pack(side="left", padx=10)

        srow = tk.Frame(self.detail_frame, bg=BG)
        srow.pack(fill="x", padx=12, pady=4)
        tk.Label(srow, text="Search model:", bg=BG, fg=MUTED,
                 font=("Arial", 10, "bold")).pack(side="left")
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", self._on_search)
        tk.Entry(srow, textvariable=self.search_var, width=30, bg=PANEL, fg=FG,
                 insertbackground=FG, relief="flat",
                 highlightthickness=1, highlightbackground="#3a3a55",
                 font=("Arial", 10)).pack(side="left", padx=8)

        cols = ("model", "code", "chipset")
        self.model_tree = ttk.Treeview(self.detail_frame, columns=cols,
                                       show="headings", height=9)
        self.model_tree.heading("model", text="Model")
        self.model_tree.heading("code", text="Code")
        self.model_tree.heading("chipset", text="Chipset")
        self.model_tree.column("model", width=280)
        self.model_tree.column("code", width=160)
        self.model_tree.column("chipset", width=280)
        self.model_tree.pack(fill="x", padx=12, pady=4)

        tk.Label(self.detail_frame,
                 text="Model codes device par verify karo -- ghalat firmware = brick!",
                 bg=WARN_BG, fg="#ffd9d9", font=("Arial", 9, "bold"),
                 padx=8, pady=4).pack(fill="x", padx=12, pady=4)

        self.detail_cheat = self._dark_text(self.detail_frame, 8)
        self.detail_cheat.pack(fill="both", expand=True, padx=12, pady=4)

    def show_brand_detail(self, key):
        info = next(t for t in BRAND_TILES if t[0] == key)
        _, badge, name, color, fg = info
        self._brand_key = key
        self.dash_frame.pack_forget()
        self.detail_frame.pack(fill="both", expand=True)
        self.badge_canvas.delete("all")
        rounded_rect(self.badge_canvas, 2, 2, 54, 54, 14, fill=color, outline="")
        self.badge_canvas.create_text(28, 28, text=badge,
                                      font=("Arial", 18, "bold"), fill=fg)
        self.detail_name.config(text=name)
        self.detail_count.config(text=f"{models.model_count(key)} models")
        self.search_var.set("")
        self._populate_models(models.get_models(key))
        self.detail_cheat.delete("1.0", "end")
        self.detail_cheat.insert("end", brands.cheat_sheet(key))

    def show_dashboard(self):
        self.detail_frame.pack_forget()
        self.dash_frame.pack(fill="both", expand=True)
        self._brand_key = None

    def _on_search(self, *_args):
        if not self._brand_key:
            return
        self._populate_models(
            models.search_models(self._brand_key, self.search_var.get()))

    def _populate_models(self, rows):
        self.model_tree.delete(*self.model_tree.get_children())
        for m in rows:
            self.model_tree.insert("", "end", values=(
                m["model"], m["code"] or "--", m["chipset"]))

    # ---------------------------- device tab ----------------------------
    def _build_device_tab(self):
        self._btn(self.tab_device, "Read device info",
                  self.read_info).pack(anchor="w", padx=12, pady=8)
        self.info_text = self._dark_text(self.tab_device, 10)
        self.info_text.pack(fill="both", expand=True, padx=12, pady=4)
        row = tk.Frame(self.tab_device, bg=BG)
        row.pack(fill="x", padx=12, pady=8)
        for target in features.REBOOT_TARGETS:
            color = TEAL if target == "meta" else ACCENT
            self._btn(row, f"Reboot: {target}",
                      lambda t=target: self.reboot(t), bg=color).pack(side="left",
                                                                      padx=3)

    # ------------------------------ mdm tab ------------------------------
    def _build_mdm_tab(self):
        tk.Label(self.tab_mdm,
                 text="Scans installed apps for MDM-like packages. YOU choose "
                      "what to disable -- nothing is removed automatically.",
                 bg=BG, fg=MUTED, font=("Arial", 10),
                 wraplength=880, justify="left").pack(anchor="w", padx=12, pady=8)
        btns = tk.Frame(self.tab_mdm, bg=BG)
        btns.pack(fill="x", padx=12, pady=4)
        self._btn(btns, "Scan packages", self.scan_pkgs).pack(side="left", padx=3)
        self._btn(btns, "Show device admins",
                  self.show_admins).pack(side="left", padx=3)
        self.pkg_list = tk.Listbox(self.tab_mdm, selectmode="extended", height=10,
                                   bg=PANEL, fg=FG, selectbackground=ACCENT,
                                   relief="flat", highlightthickness=1,
                                   highlightbackground="#3a3a55",
                                   font=("Arial", 10))
        self.pkg_list.pack(fill="both", expand=True, padx=12, pady=6)
        acts = tk.Frame(self.tab_mdm, bg=BG)
        acts.pack(fill="x", padx=12, pady=8)
        self._btn(acts, "Disable selected (reversible)",
                  lambda: self.pkg_action("disable"),
                  bg=TEAL).pack(side="left", padx=3)
        self._btn(acts, "Uninstall selected (keep data)",
                  lambda: self.pkg_action("uninstall"),
                  bg="#b07cff").pack(side="left", padx=3)

    # ------------------------- transsion id tab -------------------------
    def _build_transsion_tab(self):
        tk.Label(self.tab_transsion,
                 text="Tecno / Infinix / Itel ID-lock apps scan karo. YOU choose "
                      "what to disable -- nothing is removed automatically.",
                 bg=BG, fg=MUTED, font=("Arial", 10),
                 wraplength=880, justify="left").pack(anchor="w", padx=12, pady=8)
        tk.Label(self.tab_transsion,
                 text="Latest security patch par Transsion ID remove ke liye aam tor par "
                      "BROM-level tools (paid) darkar hote hain. Ye feature ADB access "
                      "milne par kaam karta hai.",
                 bg=WARN_BG, fg="#ffd9d9", font=("Arial", 9, "bold"),
                 wraplength=880, justify="left",
                 padx=8, pady=6).pack(fill="x", padx=12, pady=4)
        btns = tk.Frame(self.tab_transsion, bg=BG)
        btns.pack(fill="x", padx=12, pady=4)
        self._btn(btns, "Scan Transsion ID apps",
                  self.scan_transsion_pkgs).pack(side="left", padx=3)
        self.tid_list = tk.Listbox(self.tab_transsion, selectmode="extended",
                                   height=10, bg=PANEL, fg=FG,
                                   selectbackground=ACCENT, relief="flat",
                                   highlightthickness=1,
                                   highlightbackground="#3a3a55",
                                   font=("Arial", 10))
        self.tid_list.pack(fill="both", expand=True, padx=12, pady=6)
        acts = tk.Frame(self.tab_transsion, bg=BG)
        acts.pack(fill="x", padx=12, pady=8)
        self._btn(acts, "Disable selected (reversible)",
                  lambda: self.transsion_pkg_action("disable"),
                  bg=TEAL).pack(side="left", padx=3)
        self._btn(acts, "Uninstall selected (keep data)",
                  lambda: self.transsion_pkg_action("uninstall"),
                  bg="#b07cff").pack(side="left", padx=3)

    def scan_transsion_pkgs(self):
        def job():
            pkgs = features.list_packages(self.adb, self._serial())
            found = features.find_transsion_id_packages(pkgs)
            self.tid_list.delete(0, "end")
            for p in found:
                self.tid_list.insert("end", p)
            return (f"scanned {len(pkgs)} packages, "
                    f"Transsion ID-like: {found or 'none'}")
        self._run_bg("scan transsion id", job)

    def transsion_pkg_action(self, what):
        sel = [self.tid_list.get(i) for i in self.tid_list.curselection()]
        if not sel:
            messagebox.showinfo("Transsion ID",
                                "Pehle list me se package select karo.")
            return
        if not self._confirm("Confirm",
                             f"{what.upper()} these packages?\n" + "\n".join(sel)):
            return

        def job():
            res = []
            for pkg in sel:
                if what == "disable":
                    features.disable_package(self.adb, pkg, self._serial())
                else:
                    features.uninstall_package(self.adb, pkg, self._serial())
                res.append(f"{what}d: {pkg}")
            return "\n".join(res)
        self._run_bg(f"{what} transsion packages", job)

    # ---------------------------- meta mode tab ----------------------------
    def _build_meta_tab(self):
        tk.Label(self.tab_meta,
                 text="MTK phones ke liye IMEI / NVRAM work area.",
                 bg=BG, fg=FG, font=("Arial", 12, "bold")).pack(anchor="w",
                                                               padx=12, pady=(10, 2))
        tk.Label(self.tab_meta,
                 text="Ye toolkit phone ko META mode me bhejta hai; actual IMEI write "
                      "vendor tool (Modem META / Maui META) se hota hai -- wo alag se chahiye.",
                 bg=BG, fg=MUTED, font=("Arial", 10),
                 wraplength=880, justify="left").pack(anchor="w", padx=12, pady=4)
        self._btn(self.tab_meta, "REBOOT TO META MODE",
                  lambda: self.reboot("meta"),
                  bg=TEAL).pack(anchor="w", padx=12, pady=8)
        tk.Label(self.tab_meta,
                 text="Sirf ORIGINAL IMEI restore karo -- Pakistan me IMEI tamper illegal hai (PTA).",
                 bg=WARN_BG, fg="#ffd9d9", font=("Arial", 10, "bold"),
                 wraplength=880, justify="left",
                 padx=8, pady=6).pack(fill="x", padx=12, pady=6)
        tk.Label(self.tab_meta, text="Workflow:",
                 bg=BG, fg=FG, font=("Arial", 10, "bold")).pack(anchor="w",
                                                                padx=12, pady=(6, 2))
        wf = self._dark_text(self.tab_meta, 12)
        wf.pack(fill="both", expand=True, padx=12, pady=4)
        wf.insert("end", brands.IMEI_WORKFLOW + "\n")

    # ------------------------------- spd tab -------------------------------
    def _build_spd_tab(self):
        tk.Label(self.tab_spd,
                 text="SPD / Unisoc phones -- ADB wale sare features yahan bhi kaam karte hain.",
                 bg=BG, fg=FG, font=("Arial", 12, "bold")).pack(anchor="w",
                                                                padx=12, pady=(10, 2))
        btns = tk.Frame(self.tab_spd, bg=BG)
        btns.pack(fill="x", padx=12, pady=6)
        self._btn(btns, "Read device info",
                  self.read_info).pack(side="left", padx=3)
        for target in ("system", "recovery", "bootloader"):
            self._btn(btns, f"Reboot: {target}",
                      lambda t=target: self.reboot(t)).pack(side="left", padx=3)
        tk.Label(self.tab_spd,
                 text="PAC flashing is toolkit ka hissa nahi -- SPD Upgrade Tool alag se chahiye.",
                 bg=WARN_BG, fg="#ffd9d9", font=("Arial", 9, "bold"),
                 wraplength=880, justify="left",
                 padx=8, pady=6).pack(fill="x", padx=12, pady=6)
        tk.Label(self.tab_spd, text="SPD notes:",
                 bg=BG, fg=FG, font=("Arial", 10, "bold")).pack(anchor="w",
                                                                padx=12, pady=(4, 2))
        notes = self._dark_text(self.tab_spd, 10)
        notes.pack(fill="both", expand=True, padx=12, pady=4)
        notes.insert("end", brands.SPD_NOTES + "\n")

    # ---------------------------- flashing tab ----------------------------
    def _build_flash_tab(self):
        tk.Label(self.tab_flash,
                 text="DANGER: flashing the wrong image can permanently brick "
                      "the phone. Use only firmware for the EXACT model.",
                 bg=WARN_BG, fg="#ffd9d9", font=("Arial", 10, "bold"),
                 wraplength=880, justify="left",
                 padx=8, pady=6).pack(fill="x", padx=12, pady=8)
        fbtns = tk.Frame(self.tab_flash, bg=BG)
        fbtns.pack(fill="x", padx=12, pady=4)
        self._btn(fbtns, "Bootloader UNLOCK", self.fb_unlock,
                  bg=DANGER).pack(side="left", padx=3)
        self._btn(fbtns, "Bootloader LOCK", self.fb_lock,
                  bg=CARD, fg=FG).pack(side="left", padx=3)
        self._btn(fbtns, "fastboot devices", self.fb_devices).pack(side="left",
                                                                   padx=3)
        frm = tk.Frame(self.tab_flash, bg=BG)
        frm.pack(fill="x", padx=12, pady=10)
        tk.Label(frm, text="Partition:", bg=BG, fg=FG,
                 font=("Arial", 10, "bold")).pack(side="left")
        self.part_var = tk.StringVar(value="boot")
        tk.Entry(frm, textvariable=self.part_var, width=14, bg=PANEL, fg=FG,
                 insertbackground=FG, relief="flat",
                 highlightthickness=1, highlightbackground="#3a3a55",
                 font=("Arial", 10)).pack(side="left", padx=8)
        self._btn(frm, "Choose image…", self.choose_image,
                  bg=CARD, fg=FG).pack(side="left")
        self.img_var = tk.StringVar()
        tk.Label(frm, textvariable=self.img_var, bg=BG, fg=MUTED,
                 wraplength=320, font=("Arial", 9)).pack(side="left", padx=8)
        self._btn(self.tab_flash, "FLASH partition", self.fb_flash,
                  bg=DANGER).pack(anchor="w", padx=12, pady=8)

    # ---------------------------- guides tab ----------------------------
    def _build_guides_tab(self):
        brow = tk.Frame(self.tab_guides, bg=BG)
        brow.pack(fill="x", padx=12, pady=8)
        self._btn(brow, "IMEI workflow",
                  lambda: self.show_guide(brands.IMEI_WORKFLOW)).pack(side="left",
                                                                      padx=3)
        self._btn(brow, "FRP guide",
                  lambda: self.show_guide(brands.FRP_WORKFLOW)).pack(side="left",
                                                                     padx=3)
        self._btn(brow, "SPD notes",
                  lambda: self.show_guide(brands.SPD_NOTES)).pack(side="left",
                                                                  padx=3)
        self.guide_text = self._dark_text(self.tab_guides, 20)
        self.guide_text.pack(fill="both", expand=True, padx=12, pady=4)
        self.guide_text.insert("end", "Upar button dabao -- guide yahan aayegi.\n")

    def show_guide(self, text):
        self.guide_text.delete("1.0", "end")
        self.guide_text.insert("end", text + "\n")

    # --------------------------- login system ---------------------------
    def _center_dialog(self, dlg, w, h):
        dlg.update_idletasks()
        x = (dlg.winfo_screenwidth() - w) // 2
        y = (dlg.winfo_screenheight() - h) // 2
        dlg.geometry(f"{w}x{h}+{x}+{y}")

    def _login_flow(self):
        """Modal login before the main window. Destroys app if cancelled."""
        if os.environ.get("GSMTOOL_SKIP_LOGIN") == "1":
            # Screenshot/preview only. Never enabled in shipped use.
            users.init_db(USERS_DB)
            self.current_user, self.current_is_admin = "preview", True
            self.deiconify()
            self._after_login()
            return
        users.init_db(USERS_DB)
        creds = None
        if users.user_count() == 0:
            creds = self._admin_setup_dialog()  # first run: create admin
        if creds is None:
            creds = self._login_dialog()
        if creds is None:
            self.destroy()
            return
        self.current_user, self.current_is_admin = creds
        self.deiconify()
        self._after_login()

    def _after_login(self):
        role = "Admin" if self.current_is_admin else "User"
        self._update_status()
        self.log(f"Login: {self.current_user} ({role})")
        if self.current_is_admin and not self._users_tab_added:
            self.nb.add(self.tab_users, text="  Users  ")
            self._users_tab_added = True
            self._refresh_users()

    def _logout(self):
        if not self.current_user:
            return
        if self._users_tab_added:
            self.nb.forget(self.tab_users)
            self._users_tab_added = False
        self.log(f"Logout: {self.current_user}")
        self.current_user = None
        self.current_is_admin = False
        self._update_status()
        self.withdraw()
        self._login_flow()

    def _login_dialog(self):
        """Modal username/password dialog. Returns (username, is_admin) or None."""
        dlg = tk.Toplevel(self)
        dlg.title("Login -- Hamza GSM Tool")
        dlg.configure(bg=BG)
        dlg.resizable(False, False)
        self._center_dialog(dlg, 380, 250)
        dlg.transient(self)
        dlg.grab_set()

        tk.Label(dlg, text="HAMZA GSM TOOL", bg=BG, fg=ACCENT,
                 font=("Arial", 16, "bold")).pack(pady=(18, 4))
        tk.Label(dlg, text="Login karo", bg=BG, fg=MUTED,
                 font=("Arial", 10)).pack(pady=(0, 10))

        frm = tk.Frame(dlg, bg=BG)
        frm.pack(padx=30, fill="x")
        tk.Label(frm, text="Username:", bg=BG, fg=FG,
                 font=("Arial", 10, "bold")).grid(row=0, column=0, sticky="w",
                                                  pady=4)
        user_e = tk.Entry(frm, bg=PANEL, fg=FG, insertbackground=FG, width=26,
                          relief="flat", highlightthickness=1,
                          highlightbackground="#3a3a55", font=("Arial", 11))
        user_e.grid(row=0, column=1, pady=4, padx=6)
        tk.Label(frm, text="Password:", bg=BG, fg=FG,
                 font=("Arial", 10, "bold")).grid(row=1, column=0, sticky="w",
                                                  pady=4)
        pw_e = tk.Entry(frm, bg=PANEL, fg=FG, insertbackground=FG, width=26,
                        show="*", relief="flat", highlightthickness=1,
                        highlightbackground="#3a3a55", font=("Arial", 11))
        pw_e.grid(row=1, column=1, pady=4, padx=6)

        result = {}

        def do_login():
            u = user_e.get().strip()
            status, is_admin = users.verify(u, pw_e.get())
            if status == "ok":
                result["creds"] = (u, is_admin)
                dlg.destroy()
            elif status == "blocked":
                messagebox.showwarning("Blocked",
                                       "Ye account block hai. Admin se rabta karo.",
                                       parent=dlg)
            else:
                # never reveal whether the username exists
                messagebox.showerror("Login failed",
                                     "Ghalat username ya password.",
                                     parent=dlg)

        brow = tk.Frame(dlg, bg=BG)
        brow.pack(pady=16)
        self._btn(brow, "Login", do_login).pack(side="left", padx=6)
        self._btn(brow, "Cancel", dlg.destroy, bg=CARD, fg=FG).pack(side="left",
                                                                    padx=6)
        pw_e.bind("<Return>", lambda _e: do_login())
        user_e.bind("<Return>", lambda _e: do_login())
        user_e.focus_set()
        self.wait_window(dlg)
        return result.get("creds")

    def _admin_setup_dialog(self):
        """First-run dialog: create the admin account. Returns creds or None."""
        dlg = tk.Toplevel(self)
        dlg.title("Admin Account banao")
        dlg.configure(bg=BG)
        dlg.resizable(False, False)
        self._center_dialog(dlg, 400, 320)
        dlg.transient(self)
        dlg.grab_set()

        tk.Label(dlg, text="Pehla Admin Account banao", bg=BG, fg=ACCENT,
                 font=("Arial", 15, "bold")).pack(pady=(18, 4))
        tk.Label(dlg, text="Ye admin sab users ko manage karega\n(add / block / password reset / delete).",
                 bg=BG, fg=MUTED, font=("Arial", 10), justify="center").pack(pady=(0, 10))

        frm = tk.Frame(dlg, bg=BG)
        frm.pack(padx=30, fill="x")
        tk.Label(frm, text="Username:", bg=BG, fg=FG,
                 font=("Arial", 10, "bold")).grid(row=0, column=0, sticky="w", pady=4)
        user_e = tk.Entry(frm, bg=PANEL, fg=FG, insertbackground=FG, width=26,
                          relief="flat", highlightthickness=1,
                          highlightbackground="#3a3a55", font=("Arial", 11))
        user_e.grid(row=0, column=1, pady=4, padx=6)
        tk.Label(frm, text="Password:", bg=BG, fg=FG,
                 font=("Arial", 10, "bold")).grid(row=1, column=0, sticky="w", pady=4)
        pw_e = tk.Entry(frm, bg=PANEL, fg=FG, insertbackground=FG, width=26,
                        show="*", relief="flat", highlightthickness=1,
                        highlightbackground="#3a3a55", font=("Arial", 11))
        pw_e.grid(row=1, column=1, pady=4, padx=6)
        tk.Label(frm, text="Confirm:", bg=BG, fg=FG,
                 font=("Arial", 10, "bold")).grid(row=2, column=0, sticky="w", pady=4)
        pw2_e = tk.Entry(frm, bg=PANEL, fg=FG, insertbackground=FG, width=26,
                         show="*", relief="flat", highlightthickness=1,
                         highlightbackground="#3a3a55", font=("Arial", 11))
        pw2_e.grid(row=2, column=1, pady=4, padx=6)

        result = {}

        def do_create():
            u = user_e.get().strip()
            p1, p2 = pw_e.get(), pw2_e.get()
            if p1 != p2:
                messagebox.showerror("Error", "Password match nahi ho raha.",
                                     parent=dlg)
                return
            try:
                users.create_user(u, p1, is_admin=True)
            except ValueError as exc:
                messagebox.showerror("Error", str(exc), parent=dlg)
                return
            messagebox.showinfo("Ho gaya",
                                f"Admin account '{u}' ban gaya!",
                                parent=dlg)
            result["creds"] = (u, True)
            dlg.destroy()

        brow = tk.Frame(dlg, bg=BG)
        brow.pack(pady=16)
        self._btn(brow, "Admin banao", do_create).pack(side="left", padx=6)
        self._btn(brow, "Cancel", dlg.destroy, bg=CARD, fg=FG).pack(side="left",
                                                                    padx=6)
        user_e.focus_set()
        self.wait_window(dlg)
        return result.get("creds")

    # ---------------------------- users tab (admin) ----------------------------
    def _build_users_tab(self):
        tk.Label(self.tab_users,
                 text="Users manage karo -- naya user, block/unblock, password reset, delete.",
                 bg=BG, fg=MUTED, font=("Arial", 10),
                 wraplength=880, justify="left").pack(anchor="w", padx=12, pady=8)
        cols = ("username", "role", "status")
        self.users_tree = ttk.Treeview(self.tab_users, columns=cols,
                                       show="headings", height=10)
        self.users_tree.heading("username", text="Username")
        self.users_tree.heading("role", text="Role")
        self.users_tree.heading("status", text="Status")
        self.users_tree.column("username", width=260)
        self.users_tree.column("role", width=140)
        self.users_tree.column("status", width=140)
        self.users_tree.pack(fill="both", expand=True, padx=12, pady=4)

        brow = tk.Frame(self.tab_users, bg=BG)
        brow.pack(fill="x", padx=12, pady=10)
        self._btn(brow, "Naya user add karo",
                  self._user_add_dialog).pack(side="left", padx=3)
        self._btn(brow, "Block / Unblock",
                  self._user_toggle_block, bg=WARN_BG).pack(side="left", padx=3)
        self._btn(brow, "Password reset",
                  self._user_reset_pw, bg=CARD, fg=FG).pack(side="left", padx=3)
        self._btn(brow, "User delete karo",
                  self._user_delete, bg=DANGER).pack(side="left", padx=3)
        self._btn(brow, "Refresh",
                  self._refresh_users, bg=CARD, fg=FG).pack(side="left", padx=3)

    def _refresh_users(self):
        self.users_tree.delete(*self.users_tree.get_children())
        for uname, is_admin, is_blocked in users.list_users():
            role = "Admin" if is_admin else "User"
            status = "Blocked" if is_blocked else "Active"
            self.users_tree.insert("", "end",
                                   values=(uname, role, status))

    def _selected_username(self):
        sel = self.users_tree.selection()
        if not sel:
            messagebox.showinfo("Users", "Pehle list me se user select karo.")
            return None
        return self.users_tree.item(sel[0])["values"][0]

    def _user_add_dialog(self):
        dlg = tk.Toplevel(self)
        dlg.title("Naya user")
        dlg.configure(bg=BG)
        dlg.resizable(False, False)
        self._center_dialog(dlg, 380, 250)
        dlg.transient(self)
        dlg.grab_set()

        tk.Label(dlg, text="Naya user add karo", bg=BG, fg=ACCENT,
                 font=("Arial", 14, "bold")).pack(pady=(16, 8))
        frm = tk.Frame(dlg, bg=BG)
        frm.pack(padx=30, fill="x")
        tk.Label(frm, text="Username:", bg=BG, fg=FG,
                 font=("Arial", 10, "bold")).grid(row=0, column=0, sticky="w", pady=4)
        user_e = tk.Entry(frm, bg=PANEL, fg=FG, insertbackground=FG, width=24,
                          relief="flat", highlightthickness=1,
                          highlightbackground="#3a3a55", font=("Arial", 11))
        user_e.grid(row=0, column=1, pady=4, padx=6)
        tk.Label(frm, text="Password:", bg=BG, fg=FG,
                 font=("Arial", 10, "bold")).grid(row=1, column=0, sticky="w", pady=4)
        pw_e = tk.Entry(frm, bg=PANEL, fg=FG, insertbackground=FG, width=24,
                        show="*", relief="flat", highlightthickness=1,
                        highlightbackground="#3a3a55", font=("Arial", 11))
        pw_e.grid(row=1, column=1, pady=4, padx=6)
        is_admin_var = tk.BooleanVar(value=False)
        tk.Checkbutton(frm, text="Admin banao", variable=is_admin_var,
                       bg=BG, fg=FG, selectcolor=PANEL, activebackground=BG,
                       font=("Arial", 10)).grid(row=2, column=1, sticky="w", pady=4)

        def do_add():
            try:
                users.create_user(user_e.get().strip(), pw_e.get(),
                                  is_admin=is_admin_var.get())
            except ValueError as exc:
                messagebox.showerror("Error", str(exc), parent=dlg)
                return
            self._refresh_users()
            self.log(f"User added: {user_e.get().strip()}")
            dlg.destroy()

        brow = tk.Frame(dlg, bg=BG)
        brow.pack(pady=14)
        self._btn(brow, "Add karo", do_add).pack(side="left", padx=6)
        self._btn(brow, "Cancel", dlg.destroy, bg=CARD, fg=FG).pack(side="left",
                                                                    padx=6)
        user_e.focus_set()
        self.wait_window(dlg)

    def _user_toggle_block(self):
        uname = self._selected_username()
        if uname is None:
            return
        if uname == self.current_user:
            messagebox.showwarning("Users", "Khud ko block nahi kar sakte.",
                                   parent=self)
            return
        cur = {u: b for u, _a, b in users.list_users()}.get(uname, False)
        action = "unblock" if cur else "block"
        if not messagebox.askyesno("Confirm",
                                    f"'{uname}' ko {action} karna hai?",
                                    parent=self):
            return
        try:
            users.set_blocked(uname, not cur)
        except ValueError as exc:
            messagebox.showerror("Error", str(exc), parent=self)
            return
        self._refresh_users()
        self.log(f"User {action}: {uname}")

    def _user_reset_pw(self):
        uname = self._selected_username()
        if uname is None:
            return
        dlg = tk.Toplevel(self)
        dlg.title("Password reset")
        dlg.configure(bg=BG)
        dlg.resizable(False, False)
        self._center_dialog(dlg, 360, 200)
        dlg.transient(self)
        dlg.grab_set()
        tk.Label(dlg, text=f"'{uname}' ka naya password:",
                 bg=BG, fg=FG, font=("Arial", 11, "bold")).pack(pady=(18, 8))
        pw_e = tk.Entry(dlg, bg=PANEL, fg=FG, insertbackground=FG, width=26,
                        show="*", relief="flat", highlightthickness=1,
                        highlightbackground="#3a3a55", font=("Arial", 11))
        pw_e.pack(pady=4)

        def do_reset():
            try:
                users.reset_password(uname, pw_e.get())
            except ValueError as exc:
                messagebox.showerror("Error", str(exc), parent=dlg)
                return
            messagebox.showinfo("Ho gaya", "Password reset ho gaya.", parent=dlg)
            self.log(f"Password reset: {uname}")
            dlg.destroy()

        brow = tk.Frame(dlg, bg=BG)
        brow.pack(pady=14)
        self._btn(brow, "Reset karo", do_reset).pack(side="left", padx=6)
        self._btn(brow, "Cancel", dlg.destroy, bg=CARD, fg=FG).pack(side="left",
                                                                    padx=6)
        pw_e.focus_set()
        self.wait_window(dlg)

    def _user_delete(self):
        uname = self._selected_username()
        if uname is None:
            return
        if uname == self.current_user:
            messagebox.showwarning("Users", "Khud ko delete nahi kar sakte.",
                                   parent=self)
            return
        if not messagebox.askyesno("Confirm",
                                    f"'{uname}' ko DELETE karna hai? Ye wapas nahi hoga.",
                                    parent=self):
            return
        try:
            users.delete_user(uname)
        except ValueError as exc:
            messagebox.showerror("Error", str(exc), parent=self)
            return
        self._refresh_users()
        self.log(f"User deleted: {uname}")

    # ------------------------- log + status bar -------------------------
    def _log_area(self):
        row = tk.Frame(self, bg=BG)
        row.pack(fill="x", padx=10)
        tk.Label(row, text="Log:", bg=BG, fg=MUTED,
                 font=("Arial", 10, "bold")).pack(side="left")
        self._btn(row, "Save Log", self._save_log,
                  bg=CARD, fg=FG).pack(side="right", padx=3)
        self._btn(row, "Clear", self._clear_log,
                  bg=CARD, fg=FG).pack(side="right")
        self.log_text = self._dark_text(self, 6)
        self.log_text.configure(state="disabled")
        self.log_text.pack(fill="x", padx=10, pady=(0, 6))

    def _save_log(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt")],
            initialfile="gsmtool-log.txt",
            title="Log save karo")
        if not path:
            return
        self.log_text.configure(state="normal")
        content = self.log_text.get("1.0", "end")
        self.log_text.configure(state="disabled")
        try:
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(content)
            self.log(f"Log save ho gaya: {path}")
        except OSError as exc:
            messagebox.showerror("Save Log", f"Save nahi hua: {exc}")

    def _clear_log(self):
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.configure(state="disabled")

    def _status_bar(self):
        bar = tk.Frame(self, bg=CARD, height=26)
        bar.pack(fill="x", side="bottom")
        bar.pack_propagate(False)
        tk.Label(bar, textvariable=self.status_var, bg=CARD, fg=MUTED,
                 font=("Arial", 9)).pack(side="left", padx=10)

    def _update_status(self):
        adb_ok = "OK" if self.adb else "MISSING"
        fb_ok = "OK" if self.fb else "MISSING"
        who = ""
        if self.current_user:
            role = "Admin" if self.current_is_admin else "User"
            who = f"Logged in: {self.current_user} ({role})   |   "
        self.status_var.set(f"{who}adb: {adb_ok}   |   fastboot: {fb_ok}   |   Hamza GSM Tool v{__version__}")

    # ------------------------- drivers tab -------------------------
    def _build_drivers_tab(self):
        tk.Label(self.tab_drivers,
                 text="Drivers -- phone detect na ho to sab se pehle ye dekho.",
                 bg=BG, fg=FG, font=("Arial", 12, "bold")).pack(anchor="w",
                                                               padx=12, pady=(10, 2))
        brow = tk.Frame(self.tab_drivers, bg=BG)
        brow.pack(fill="x", padx=12, pady=6)
        self._btn(brow, "Check Installed Drivers",
                  lambda: self._run_bg(
                      "driver check",
                      lambda: drivers.check_drivers(self.adb, self.fb))
                  ).pack(side="left", padx=3)
        self._btn(brow, "Install Driver from Folder…",
                  self._driver_install_pick,
                  bg=CARD, fg=FG).pack(side="left", padx=3)
        tk.Label(self.tab_drivers,
                 text="Driver list (official = verified official page; "
                      "bundled = flashing tool package ke sath milta hai):",
                 bg=BG, fg=MUTED, font=("Arial", 10)).pack(anchor="w",
                                                          padx=12, pady=(4, 2))
        for name, purpose, url, kind, note in drivers.DRIVER_ROWS:
            row = tk.Frame(self.tab_drivers, bg=PANEL)
            row.pack(fill="x", padx=12, pady=3)
            tk.Label(row, text=name, bg=PANEL, fg=FG,
                     font=("Arial", 10, "bold"), width=30,
                     anchor="w").pack(side="left", padx=8, pady=6)
            tk.Label(row, text=purpose, bg=PANEL, fg=MUTED,
                     font=("Arial", 9), wraplength=400,
                     justify="left").pack(side="left", padx=4)
            if kind == "official" and url:
                self._btn(row, "Download ↗",
                          lambda u=url: webbrowser.open(u),
                          bg=TEAL).pack(side="right", padx=8)
            else:
                self._btn(row, "Info",
                          lambda n=note, t=name: messagebox.showinfo(t, n),
                          bg=CARD, fg=FG).pack(side="right", padx=8)

    def _driver_install_pick(self):
        folder = filedialog.askdirectory(
            title="Driver folder select karo (.inf files)")
        if folder:
            self._run_bg("driver install",
                         lambda: drivers.install_driver_folder(folder))

    # ------------------------- test point / edl tab -------------------------
    def _build_edl_tab(self):
        tk.Label(self.tab_edl,
                 text="EDL / BROM / Download Mode -- brand ka safe tareeqa dekho.",
                 bg=BG, fg=FG, font=("Arial", 12, "bold")).pack(anchor="w",
                                                               padx=12, pady=(10, 2))
        tk.Label(self.tab_edl,
                 text="WARNING: test point har MODEL ka alag hota hai (brand ka "
                      "nahi). Ghalat point short karne se board DEAD ho sakta hai!",
                 bg=WARN_BG, fg="#ffd9d9", font=("Arial", 10, "bold"),
                 wraplength=880, justify="left",
                 padx=8, pady=6).pack(fill="x", padx=12, pady=6)
        brow = tk.Frame(self.tab_edl, bg=BG)
        brow.pack(fill="x", padx=12, pady=4)
        tk.Label(brow, text="Brand:", bg=BG, fg=FG,
                 font=("Arial", 10, "bold")).pack(side="left")
        self.edl_brand_var = tk.StringVar()
        names = [n for _, _, n, _, _ in BRAND_TILES]
        cb = ttk.Combobox(brow, textvariable=self.edl_brand_var,
                          values=names, state="readonly", width=18,
                          font=("Arial", 10))
        cb.pack(side="left", padx=8)
        cb.current(0)
        self._btn(brow, "Show Method",
                  self._show_edl_brand).pack(side="left", padx=3)
        self._btn(brow, "FRP Notes",
                  lambda: self._edl_show(edl.FRP_NOTES),
                  bg=CARD, fg=FG).pack(side="left", padx=3)
        srow = tk.Frame(self.tab_edl, bg=BG)
        srow.pack(fill="x", padx=12, pady=4)
        tk.Label(srow, text="Model (test point search):", bg=BG, fg=FG,
                 font=("Arial", 10, "bold")).pack(side="left")
        self.edl_model_var = tk.StringVar(value="X6887")
        tk.Entry(srow, textvariable=self.edl_model_var, width=22, bg=PANEL,
                 fg=FG, insertbackground=FG, relief="flat",
                 highlightthickness=1, highlightbackground="#3a3a55",
                 font=("Arial", 10)).pack(side="left", padx=8)
        self._btn(srow, "Search Test Point",
                  self._search_testpoint, bg=TEAL).pack(side="left", padx=3)
        self.edl_text = self._dark_text(self.tab_edl, 13)
        self.edl_text.pack(fill="both", expand=True, padx=12, pady=4)
        self.edl_text.insert("end", edl.TESTPOINT_WARNINGS + "\n")

    def _edl_show(self, text):
        self.edl_text.delete("1.0", "end")
        self.edl_text.insert("end", text + "\n")

    def _show_edl_brand(self):
        name = self.edl_brand_var.get()
        key = next((k for k, _, n, _, _ in BRAND_TILES if n == name), None)
        self._edl_show("=== " + name + " ===\n"
                       + edl.brand_edl_text(key) + "\n"
                       + edl.TESTPOINT_WARNINGS)

    def _search_testpoint(self):
        model = self.edl_model_var.get().strip()
        if not model:
            messagebox.showwarning("Model", "Pehle model likho (misal: X6887).")
            return
        webbrowser.open(edl.testpoint_search_url(model))
        self.log(f"Test point search khola: {model}")

    # ------------------------- backup tab -------------------------
    def _build_backup_tab(self):
        tk.Label(self.tab_backup,
                 text="Backup -- flashing se PEHLE backup lo!",
                 bg=BG, fg=FG, font=("Arial", 12, "bold")).pack(anchor="w",
                                                               padx=12, pady=(10, 2))
        tk.Label(self.tab_backup,
                 text="NVRAM / IMEI ka backup na ho to ghalti se data gaya to "
                      "wapis nahi aayega. Ye aadat banao.",
                 bg=WARN_BG, fg="#ffd9d9", font=("Arial", 10, "bold"),
                 wraplength=880, justify="left",
                 padx=8, pady=6).pack(fill="x", padx=12, pady=6)
        brow = tk.Frame(self.tab_backup, bg=BG)
        brow.pack(fill="x", padx=12, pady=8)
        self._btn(brow, "Backup Installed APKs",
                  self._backup_apks).pack(side="left", padx=3)
        self._btn(brow, "Save Device Report",
                  self._backup_report, bg=CARD, fg=FG).pack(side="left", padx=3)
        tk.Label(self.tab_backup,
                 text="Backups tool wali folder ke andar 'backups' me save hote hain.",
                 bg=BG, fg=MUTED, font=("Arial", 10)).pack(anchor="w",
                                                          padx=12, pady=4)

    def _backup_dir(self):
        here = os.path.dirname(os.path.abspath(__file__))
        folder = os.path.join(here, "backups", self._serial() or "default")
        os.makedirs(folder, exist_ok=True)
        return folder

    def _backup_apks(self):
        def job():
            if not self.adb:
                return "adb nahi mila -- pehle platform-tools set karo."
            base = ["-s", self._serial()] if self._serial() else []
            out = adbwrap.run(self.adb, base + ["shell", "pm", "list",
                                                "packages", "-3"])
            pkgs = [l.split(":", 1)[1].strip() for l in out.splitlines()
                    if l.startswith("package:")]
            if not pkgs:
                return "Koi user app nahi mili."
            folder = self._backup_dir()
            done, failed = 0, 0
            for pkg in pkgs:
                try:
                    pp = adbwrap.run(self.adb, base + ["shell", "pm", "path",
                                                      pkg])
                    apks = [l.split(":", 1)[1].strip()
                            for l in pp.splitlines()
                            if l.startswith("package:")]
                    for i, apk in enumerate(apks):
                        dest = os.path.join(folder, f"{pkg}_{i}.apk")
                        adbwrap.run(self.adb, base + ["pull", apk, dest])
                    done += 1
                except Exception:  # noqa: BLE001 - count, keep going
                    failed += 1
            msg = f"{done} apps backup ho gayin: {folder}"
            if failed:
                msg += f" ({failed} fail)"
            return msg
        self._run_bg("APK backup", job)

    def _backup_report(self):
        def job():
            if not self.adb:
                return "adb nahi mila -- pehle platform-tools set karo."
            base = ["-s", self._serial()] if self._serial() else []
            props = adbwrap.run(self.adb, base + ["shell", "getprop"])
            folder = self._backup_dir()
            stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            fname = f"device-report-{self._serial() or 'default'}-{stamp}.txt"
            path = os.path.join(folder, fname)
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(f"Hamza GSM Tool device report -- {stamp}\n\n")
                fh.write(props)
            return f"Report save ho gayi: {path}"
        self._run_bg("device report", job)

    # ------------------------- publish update tab -------------------------
    def _build_release_tab(self):
        tk.Label(self.tab_release,
                 text="Publish Update -- nayi version khud release karo.",
                 bg=BG, fg=FG, font=("Arial", 12, "bold")).pack(anchor="w",
                                                               padx=12, pady=(10, 2))
        tk.Label(self.tab_release,
                 text=f"Current version: v{__version__}",
                 bg=BG, fg=MUTED, font=("Arial", 10)).pack(anchor="w",
                                                          padx=12, pady=2)
        frm = tk.Frame(self.tab_release, bg=BG)
        frm.pack(fill="x", padx=12, pady=8)
        tk.Label(frm, text="New version:", bg=BG, fg=FG,
                 font=("Arial", 10, "bold")).pack(side="left")
        self.rel_ver_var = tk.StringVar(value="7.1")
        tk.Entry(frm, textvariable=self.rel_ver_var, width=10, bg=PANEL, fg=FG,
                 insertbackground=FG, relief="flat",
                 highlightthickness=1, highlightbackground="#3a3a55",
                 font=("Arial", 10)).pack(side="left", padx=8)
        tk.Label(frm, text="Kya naya hai:", bg=BG, fg=FG,
                 font=("Arial", 10, "bold")).pack(side="left", padx=(12, 0))
        self.rel_notes_var = tk.StringVar()
        tk.Entry(frm, textvariable=self.rel_notes_var, width=42, bg=PANEL,
                 fg=FG, insertbackground=FG, relief="flat",
                 highlightthickness=1, highlightbackground="#3a3a55",
                 font=("Arial", 10)).pack(side="left", padx=8)
        brow = tk.Frame(self.tab_release, bg=BG)
        brow.pack(fill="x", padx=12, pady=4)
        self._btn(brow, "Build Release Package",
                  self._build_release_pkg).pack(side="left", padx=3)
        self._btn(brow, "Open GitHub Upload Page",
                  self._open_upload_page, bg=TEAL).pack(side="left", padx=3)
        self.rel_text = self._dark_text(self.tab_release, 13)
        self.rel_text.pack(fill="both", expand=True, padx=12, pady=4)
        self.rel_text.insert(
            "end",
            "Nayi version number likho (misal 7.1) -> 'Build Release Package' "
            "dabao.\nPhir 2 files (ZIP + version.json) GitHub par upload karo -- "
            "tool khud users ko update de dega.\n")

    def _build_release_pkg(self):
        ver = self.rel_ver_var.get()
        notes = self.rel_notes_var.get()

        def job():
            ok, msg, _paths = release.build_release(new_version=ver,
                                                    notes=notes)
            return ("RELEASE OK\n" + msg) if ok else ("RELEASE FAILED\n" + msg)
        self._run_bg("build release", job)

    def _open_upload_page(self):
        url = release.github_upload_url(
            updater.load_config().get("update_url", ""))
        if url:
            webbrowser.open(url)
            self.log(f"Upload page khola: {url}")
        else:
            messagebox.showinfo(
                "Upload page",
                "Pehle \u2699 Update Settings me apni version.json wali site ka "
                "URL save karo.")

    # ------------------------------ widgets ------------------------------
    def _btn(self, parent, text, cmd, bg=ACCENT, fg="#ffffff"):
        return tk.Button(parent, text=text, command=cmd, bg=bg, fg=fg,
                         activebackground="#8f7ff5", activeforeground="#ffffff",
                         relief="flat", padx=12, pady=6,
                         font=("Arial", 10, "bold"), cursor="hand2")

    def _dark_text(self, parent, height):
        return scrolledtext.ScrolledText(parent, height=height, bg=PANEL, fg=FG,
                                         insertbackground=FG,
                                         selectbackground=ACCENT, relief="flat",
                                         highlightthickness=1,
                                         highlightbackground="#3a3a55",
                                         font=("Arial", 10))

    # ------------------------------ helpers ------------------------------
    def log(self, msg):
        self.log_text.configure(state="normal")
        self.log_text.insert("end", msg + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _poll_jobs(self):
        try:
            while True:
                self.log(self._jobs.get_nowait())
        except queue.Empty:
            pass
        self.after(200, self._poll_jobs)

    def _run_bg(self, label, func):
        def worker():
            self._jobs.put(f">> {label}")
            try:
                out = func()
                if out:
                    self._jobs.put(str(out).strip()[:3000])
                self._jobs.put("done.")
            except Exception as exc:  # noqa: BLE001 - show in log
                self._jobs.put(f"ERROR: {exc}")
        threading.Thread(target=worker, daemon=True).start()

    def _serial(self):
        return self.serial.get().strip() or None

    def _confirm(self, title, msg):
        return messagebox.askyesno(title, msg)

    # ------------------------------ actions ------------------------------
    def _center(self, dlg):
        """Center a dialog over the main window (pretty on any screen)."""
        dlg.update_idletasks()
        x = self.winfo_x() + (self.winfo_width() - dlg.winfo_width()) // 2
        y = self.winfo_y() + (self.winfo_height() - dlg.winfo_height()) // 2
        dlg.geometry(f"+{max(x, 0)}+{max(y, 0)}")

    def _update_settings(self):
        """Let the user paste their own version.json URL (self-hosted updates)."""
        dlg = tk.Toplevel(self)
        dlg.title("Update Settings")
        dlg.configure(bg=BG)
        dlg.transient(self)
        dlg.grab_set()
        self._center(dlg)
        tk.Label(dlg, text="Apni website ka version.json link yahan paste karo:",
                 bg=BG, fg=FG, font=("Arial", 10, "bold"),
                 wraplength=420, justify="left").pack(padx=16, pady=(14, 6))
        tk.Label(dlg, text="Misal: https://tumhara-username.github.io/gsmtool/version.json",
                 bg=BG, fg=MUTED, font=("Arial", 9)).pack(padx=16)
        var = tk.StringVar(value=updater.load_config().get("update_url", ""))
        ent = tk.Entry(dlg, textvariable=var, width=52, bg=PANEL, fg=FG,
                       insertbackground=FG, relief="flat",
                       highlightthickness=1, highlightbackground="#3a3a55")
        ent.pack(padx=16, pady=10)

        def save():
            url = updater.save_update_url(var.get())
            self.log(f"Update URL set: {url or '(khali -- manual mode)'}")
            messagebox.showinfo("Update Settings",
                                "Save ho gaya!" + ("\nAb 'Check for Updates' dabao."
                                                   if url else ""),
                                parent=dlg)
            dlg.destroy()

        def test():
            updater.save_update_url(var.get())
            dlg.destroy()
            self._check_updates()

        brow = tk.Frame(dlg, bg=BG)
        brow.pack(pady=(0, 14))
        self._btn(brow, "Save", save).pack(side="left", padx=4)
        self._btn(brow, "Save + Test", test).pack(side="left", padx=4)
        self._btn(brow, "Cancel", dlg.destroy,
                  bg=CARD, fg=FG).pack(side="left", padx=4)

    def _check_updates(self):
        """'Check for Updates' button: honest update check, no fake promises."""
        self.log("Checking for updates...")
        status, msg, info = updater.check_for_updates()
        if status == "available":
            self.log(f"Update available: v{info.get('version')}")
            choice = self._update_choice_dialog(
                "Update available",
                msg + "\nKya karun?")
            if choice == "install":
                self._download_and_install(info)
            elif choice == "download":
                self._download_only(info)
        elif status == "uptodate":
            messagebox.showinfo("Updates", msg, parent=self)
        else:  # not_configured / error
            messagebox.showinfo("Updates", msg, parent=self)
        self.log(f"Update check: {status}")

    def _update_choice_dialog(self, title, msg):
        """Custom 3-button dialog. Returns 'install' | 'download' | None."""
        result = {"v": None}
        dlg = tk.Toplevel(self)
        dlg.title(title)
        dlg.configure(bg=BG)
        dlg.transient(self)
        dlg.grab_set()
        self._center(dlg)
        tk.Label(dlg, text=msg, bg=BG, fg=FG, font=("Arial", 10),
                 wraplength=400, justify="left").pack(padx=16, pady=12)
        brow = tk.Frame(dlg, bg=BG)
        brow.pack(pady=(0, 14))

        def pick(v):
            result["v"] = v
            dlg.destroy()

        self._btn(brow, "\u2b07 Install Now", lambda: pick("install")).pack(
            side="left", padx=4)
        self._btn(brow, "Download ZIP only", lambda: pick("download"),
                  bg=CARD, fg=FG).pack(side="left", padx=4)
        self._btn(brow, "Cancel", lambda: pick(None),
                  bg=CARD, fg=FG).pack(side="left", padx=4)
        self.wait_window(dlg)
        return result["v"]

    def _download_only(self, info):
        url = info.get("download_url", "")
        if not url:
            messagebox.showinfo("Update", "Download link set nahi hai.",
                                parent=self)
            return
        dest = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            f"HamzaGSMTool-v{info.get('version')}.zip")
        try:
            self.log(f"Downloading {url} ...")
            updater.download_update(url, dest)
            messagebox.showinfo("Update",
                                f"Download ho gaya:\n{dest}\n\n"
                                "UPDATE.bat chalao -- users.db mehfooz rahega.",
                                parent=self)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Update", f"Download fail:\n{exc}", parent=self)

    def _download_and_install(self, info):
        """One-click self-update: download, stage apply-script, restart."""
        url = info.get("download_url", "")
        if not url:
            messagebox.showinfo("Update", "Download link set nahi hai.",
                                parent=self)
            return
        app_dir = os.path.dirname(os.path.abspath(__file__))
        dest = os.path.join(app_dir, f"HamzaGSMTool-v{info.get('version')}.zip")
        try:
            self.log(f"Downloading {url} ...")
            updater.download_update(url, dest)
            script = updater.create_apply_script(app_dir, dest)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Update", f"Tayyari fail:\n{exc}", parent=self)
            return
        if not messagebox.askyesno(
                "Update",
                "Update download ho gaya.\n\n"
                "Ab tool band karke install shuru karun?\n"
                "Tumhare users/passwords mehfooz rahenge.",
                parent=self):
            return
        self.log("Applying update -- restarting...")
        try:
            os.startfile(script)  # Windows
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror(
                "Update",
                f"Auto-install start nahi ho saka:\n{exc}\n\n"
                f"Manual: {script} chalao ya UPDATE.bat use karo.",
                parent=self)
            return
        self.destroy()

    def refresh(self):
        def job():
            lines = ["adb devices:"]
            for s, st in features.adb_devices(self.adb):
                lines.append(f"  {s}  [{st}]")
            lines.append("fastboot devices:")
            for s in features.fastboot_devices(self.fb):
                lines.append(f"  {s}")
            return "\n".join(lines)
        self._run_bg("refresh devices", job)

    def read_info(self):
        self._run_bg("read device info",
                     lambda: "\n".join(
                         f"{k}: {v}" for k, v in
                         features.device_info(self.adb, self._serial()).items()))

    def reboot(self, target):
        if not self._confirm("Reboot", f"Reboot device to '{target}'?"):
            return
        self._run_bg(f"reboot {target}",
                     lambda: features.reboot_device(self.adb, target, self._serial()))

    def scan_pkgs(self):
        def job():
            pkgs = features.list_packages(self.adb, self._serial())
            found = features.find_suspicious_packages(pkgs)
            self.pkg_list.delete(0, "end")
            for p in found or pkgs:
                self.pkg_list.insert("end", p)
            return (f"scanned {len(pkgs)} packages, "
                    f"{len(found)} MDM-like: {found or 'none'}")
        self._run_bg("scan packages", job)

    def show_admins(self):
        self._run_bg("device admins",
                     lambda: features.device_admins(self.adb, self._serial())
                     or "no active device admins")

    def pkg_action(self, what):
        sel = [self.pkg_list.get(i) for i in self.pkg_list.curselection()]
        if not sel:
            messagebox.showinfo("MDM tools", "Pehle list me se package select karo.")
            return
        if not self._confirm("Confirm",
                             f"{what.upper()} these packages?\n" + "\n".join(sel)):
            return

        def job():
            res = []
            for pkg in sel:
                if what == "disable":
                    features.disable_package(self.adb, pkg, self._serial())
                else:
                    features.uninstall_package(self.adb, pkg, self._serial())
                res.append(f"{what}d: {pkg}")
            return "\n".join(res)
        self._run_bg(f"{what} packages", job)

    def fb_devices(self):
        self._run_bg("fastboot devices",
                     lambda: features.fastboot_devices(self.fb) or "none")

    def fb_unlock(self):
        if not self._confirm("DANGER",
                             "Unlock bootloader? This WIPES all data and may "
                             "void warranty. Continue?"):
            return
        self._run_bg("bootloader unlock",
                     lambda: features.fastboot_unlock(self.fb, self._serial()))

    def fb_lock(self):
        if not self._confirm("Lock bootloader?",
                             "Only lock with STOCK firmware flashed, or the "
                             "phone may not boot. Continue?"):
            return
        self._run_bg("bootloader lock",
                     lambda: features.fastboot_lock(self.fb, self._serial()))

    def choose_image(self):
        path = filedialog.askopenfilename(title="Choose firmware image")
        if path:
            self.img_var.set(path)

    def fb_flash(self):
        part, img = self.part_var.get().strip(), self.img_var.get().strip()
        if not part or not img:
            messagebox.showinfo("Flash", "Partition aur image dono chahiye.")
            return
        if not self._confirm("DANGER",
                             f"Flash '{img}' to partition '{part}'?\n"
                             "Wrong image = bricked phone. Continue?"):
            return
        self._run_bg(f"flash {part}",
                     lambda: features.fastboot_flash(self.fb, part, img,
                                                     self._serial()))


if __name__ == "__main__":
    ToolApp().mainloop()
