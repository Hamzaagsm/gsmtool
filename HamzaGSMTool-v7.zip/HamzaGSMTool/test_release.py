"""Tests for release.py -- release builder and URL helpers."""

import json
import os

import release


def _make_tool_dir(tmp_path):
    tool = tmp_path / "tool"
    tool.mkdir()
    (tool / "app.py").write_text("# app")
    (tool / "users.db").write_text("SECRET-DATA")  # must be excluded
    (tool / "update_config.json").write_text(json.dumps(
        {"update_url": "https://hamzaagsm.github.io/gsmtool/version.json"}))
    pycache = tool / "__pycache__"
    pycache.mkdir()
    (pycache / "app.pyc").write_text("x")
    rel = tool / "releases"
    rel.mkdir()
    (rel / "old.zip").write_text("old")  # must not be nested into new zip
    return str(tool)


def test_sanitize_version():
    assert release.sanitize_version("v7.1 beta") == "7.1"
    assert release.sanitize_version(" 8.0 ") == "8.0"
    assert release.sanitize_version("") == ""


def test_site_base_and_upload_url():
    u = "https://hamzaagsm.github.io/gsmtool/version.json"
    assert release.site_base_from_update_url(u) == \
        "https://hamzaagsm.github.io/gsmtool"
    assert release.github_upload_url(u) == \
        "https://github.com/hamzaagsm/gsmtool/upload/main"
    assert release.github_upload_url("") == ""
    assert release.github_upload_url("https://example.com/x.json") == ""


def test_build_release_creates_zip_and_manifest(tmp_path):
    tool = _make_tool_dir(tmp_path)
    ok, msg, paths = release.build_release(tool_dir=tool, new_version="7.1",
                                           notes="test notes")
    assert ok, msg
    assert os.path.isfile(paths["zip"])
    assert os.path.isfile(paths["json"])

    import zipfile
    with zipfile.ZipFile(paths["zip"]) as zf:
        names = zf.namelist()
    assert "app.py" in names
    assert "users.db" not in names, "users.db leak!"
    assert "update_config.json" not in names
    assert not any(n.endswith(".pyc") for n in names)
    assert not any(n.startswith("releases/") for n in names), "nested release!"

    with open(paths["json"], encoding="utf-8") as fh:
        manifest = json.load(fh)
    assert manifest["version"] == "7.1"
    assert manifest["download_url"] == \
        "https://hamzaagsm.github.io/gsmtool/HamzaGSMTool-v7.1.zip"
    assert manifest["notes"] == "test notes"


def test_build_release_needs_update_url(tmp_path):
    tool = tmp_path / "tool2"
    tool.mkdir()
    ok, msg, _ = release.build_release(tool_dir=str(tool), new_version="7.1")
    assert not ok
    assert "Update Settings" in msg


def test_build_release_rejects_empty_version(tmp_path):
    tool = _make_tool_dir(tmp_path)
    ok, msg, _ = release.build_release(tool_dir=tool, new_version="")
    assert not ok
