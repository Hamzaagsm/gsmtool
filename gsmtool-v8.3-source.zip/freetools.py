"""Free external tools launcher for Hamza GSM Tool v8.3.

Har tool: official download link + local launch.
Tools ~/workspace/gsmtool/freetools/<key>/ me extract karo, phir tool se khul jayega.
"""

import os

TOOLS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "freetools")

# key: (display name, description_urdu, download_url, exe_names_to_find)
FREE_TOOLS = {
    "samfw": (
        "SamFw FRP Tool",
        "Samsung FRP remove (free). Android 9-15. Setup wizard → *#0*# → Remove FRP.",
        "https://samfw.com",
        ["SamFwTool.exe", "SamFwFRPTool.exe"],
    ),
    "odin": (
        "Odin3 v3.14.4",
        "Samsung firmware flashing (BL/AP/CP/CSC). Sirf genuine v3.14.4 use karo.",
        "https://odindownload.com",
        ["Odin3.exe", "Odin3 v3.14.4.exe"],
    ),
    "3utools": (
        "3uTools",
        "iPhone flashing, backup, battery info, exit recovery. 100% free.",
        "https://www.3u.com",
        ["3uTools.exe"],
    ),
    "scrcpy": (
        "scrcpy",
        "Phone screen PC par mirror + control. Tooti screen ka data nikalo.",
        "https://github.com/Genymobile/scrcpy/releases",
        ["scrcpy.exe"],
    ),
    "miflash": (
        "MiFlash",
        "Xiaomi fastboot ROM flashing. 'clean all' select karo (lock wala nahi!).",
        "https://xiaomiflash.com",
        ["XiaoMiFlash.exe", "MiFlash.exe"],
    ),
    "frija": (
        "Frija",
        "Samsung firmware Samsung ke server se direct download (fast, free).",
        "https://forum.xda-developers.com/t/tool-frija-samsung-firmware-downloader-checker.3910594/",
        ["Frija.exe"],
    ),
    "realmeflash": (
        "Realme Flash Tool",
        "Realme/Oppo OFP firmware flashing. Unlocked bootloader chahiye.",
        "https://www.thecustomdroid.com/realme-flash-tool/",
        ["RealmeFlash.exe"],
    ),
    "qpst": (
        "QPST / QFIL",
        "Qualcomm EDL (9008) flashing. QDLoader drivers ke saath.",
        "https://qpsttool.com",
        ["QFIL.exe"],
    ),
}


def find_tool_exe(key):
    """Tool ka exe dhoondo. (path ya None)"""
    info = FREE_TOOLS.get(key)
    if not info:
        return None
    folder = os.path.join(TOOLS_DIR, key)
    for exe in info[3]:
        p = os.path.join(folder, exe)
        if os.path.isfile(p):
            return p
        # subfolder me bhi dhoondo (1 level)
        if os.path.isdir(folder):
            for root, _dirs, files in os.walk(folder):
                if exe in files:
                    return os.path.join(root, exe)
    return None


def tool_install_hint(key):
    """User ko batayo kahan extract karna hai."""
    info = FREE_TOOLS.get(key)
    folder = os.path.join(TOOLS_DIR, key)
    return (
        f"{info[0]} abhi installed nahi hai.\n\n"
        f"1. Download page kholo: {info[2]}\n"
        f"2. Download karke extract karo is folder me:\n   {folder}\n"
        f"3. Phir dobara ye button dabao — tool khul jayega!"
    )
