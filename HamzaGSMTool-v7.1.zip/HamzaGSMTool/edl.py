"""EDL / BROM / Download-mode guide for Hamza GSM Tool v7 (stdlib only).

Honest scope -- test point ki EXACT location har MODEL ki alag hoti hai
(brand ki nahi!), is liye tool me koi test-point diagram hardcode NAHI ki
gayi. Ghalat point short karne se board dead ho sakta hai. Ye module deta hai:

  * har brand ke liye SAFE key-combination methods (EDL / BROM /
    Download mode) -- ye standard, public tareeqe hain
  * sakht safety warnings (Roman Urdu)
  * testpoint_search_url(model): exact model ka test point dhoondne ke liye
    one-click web search helper
"""

import urllib.parse

# brand_key -> {mode, keys, notes}
# brand keys must match brands.py / BRAND_TILES keys.
BRAND_EDL = {
    "samsung": {
        "mode": "Download Mode (Odin)",
        "keys": "Phone OFF karo -> Volume UP + Volume DOWN dono dabaye rakho "
                "-> USB cable lagao. (Purane models: Vol Down + Home + Power)",
        "notes": "Odin flashing ke liye. Driver: Samsung USB Driver chahiye.",
    },
    "xiaomi": {
        "mode": "EDL Mode (9008)",
        "keys": "Naye models par key combo BLOCKED hai. Options: (1) test point "
                "(exact model verify karo), (2) deep-flash cable, (3) purane "
                "models par fastboot me 'fastboot oem edl'.",
        "notes": "Authorized Mi account ke baghair flashing mushkil hai.",
    },
    "tecno": {
        "mode": "BROM Mode (MTK)",
        "keys": "Phone OFF -> Volume UP (kuch models me Vol Down) dabaye rakho "
                "-> USB cable lagao. Test point ki zaroorat NAHI parti.",
        "notes": "SP Flash Tool / MTK drivers chahiye. Transsion ID ke liye "
                 "tool ka 'Transsion ID' tab dekho.",
    },
    "infinix": {
        "mode": "BROM Mode (MTK)",
        "keys": "Phone OFF -> Volume UP (kuch models me Vol Down) dabaye rakho "
                "-> USB cable lagao. Test point ki zaroorat NAHI parti.",
        "notes": "SP Flash Tool / MTK drivers chahiye.",
    },
    "itel": {
        "mode": "BROM Mode (MTK/SPD)",
        "keys": "MTK wale: Vol UP + USB. SPD wale: Vol DOWN + USB. Pehle "
                "chipset confirm karo (Device tab -> Read info).",
        "notes": "Chipset ke hisab se MTK ya SPD driver chahiye.",
    },
    "oppo": {
        "mode": "EDL / Flash Mode",
        "keys": "Aksar LOCKED: test point + authorized account chahiye. "
                "Kuch purane models: Vol UP + Vol DOWN + USB.",
        "notes": "Naye Oppo/Realme me free flashing mushkil hai -- pehle "
                 "exact model ka status verify karo.",
    },
    "vivo": {
        "mode": "EDL / Fastboot",
        "keys": "Fastboot: Vol DOWN + Power. EDL aksar locked -- test point + "
                "authorized tool chahiye.",
        "notes": "Bootloader unlock Vivo me officially supported nahi.",
    },
    "realme": {
        "mode": "EDL / Fastboot",
        "keys": "Fastboot: Vol DOWN + Power. EDL: test point (exact model) ya "
                "deep-flash cable. Naye models locked hain.",
        "notes": "Oppo jaisi hi policy -- authorized account zaroori.",
    },
    "motorola": {
        "mode": "Fastboot / EDL",
        "keys": "Fastboot: Vol DOWN + Power. Purane Qualcomm models: "
                "'fastboot oem edl' ya blankflash.",
        "notes": "Bootloader unlock Motorola site se (data wipe hoga).",
    },
    "nokia": {
        "mode": "Fastboot / Download",
        "keys": "Fastboot: Vol DOWN + USB lagao. HMD phones me EDL aksar "
                "blocked hai.",
        "notes": "Nokia/HMD me free deep flashing options mehdood hain.",
    },
    "oneplus": {
        "mode": "EDL / Fastboot",
        "keys": "Fastboot: Vol UP + Vol DOWN + Power. EDL: Vol UP + Vol DOWN "
                "dabaye rakho + USB (kuch models), warna test point.",
        "notes": "MSM Tool authorized account mangta hai naye models par.",
    },
    "huawei": {
        "mode": "Fastboot / Upgrade",
        "keys": "Fastboot: Vol DOWN + USB. Naye Huawei me bootloader unlock "
                "code band hai.",
        "notes": "Huawei me free flashing ke options bohat mehdood hain.",
    },
    "qmobile": {
        "mode": "Chipset par depend",
        "keys": "MTK wala: Vol UP + USB (BROM). SPD wala: Vol DOWN + USB. "
                "Pehle Device tab se chipset confirm karo.",
        "notes": "QMobile aksar rebranded hota hai -- asal chipset dekho.",
    },
}

TESTPOINT_WARNINGS = """TEST POINT -- ZAROORI WARNINGS (ghor se parho):

1. Test point har MODEL ka alag hota hai, BRAND ka nahi! Infinix X6887 ka
   point kisi aur Infinix se match nahi karega.
2. GHALAT point short karne se motherboard hamesha ke liye DEAD ho sakta hai.
3. Hamesha EXACT model number verify karo (battery/back cover kholne se pehle).
4. Sirf tab kholo jab tumhe hardware ka tajurba ho; nahi to kisi expert ko do.
5. Ye tool koi test-point diagram hardcode NAHI karta -- kyunke ghalat diagram
   phone maar sakti hai. Neeche search button se exact model ka point dhoondo
   aur 2-3 sources se confirm karo.
"""

FRP_NOTES = """FRP -- honest picture:

* FRP Google ki theft-protection hai. Sirf apne phone ya customer ki ijazat
  se kaam karo.
* Naye security patch par purane bypass (Talkback waghera) aksar PATCHED hain.
* Jo tareeqe aaj kaam karte hain wo kal band ho sakte hain -- koi tool
  "100% FRP bypass" ka wada nahi kar sakta.
* Samsung: Download mode + Odin (official firmware) sab se safe rasta hai.
* MTK phones: BROM mode se format (SP Flash Tool) -- lekin NVRAM/IMEI ka
  backup pehle lo (Backup tab).
"""


def testpoint_search_url(model):
    """Google search URL for '<model> test point edl'."""
    q = urllib.parse.quote_plus(f"{model.strip()} test point edl")
    return f"https://www.google.com/search?q={q}"


def brand_edl_text(brand_key):
    """Human-readable EDL guide block for one brand key."""
    info = BRAND_EDL.get(brand_key)
    if not info:
        return "Is brand ka data nahi mila."
    return (f"Mode: {info['mode']}\n"
            f"Tareeqa: {info['keys']}\n"
            f"Note: {info['notes']}\n")
