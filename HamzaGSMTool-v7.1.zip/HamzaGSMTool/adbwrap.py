"""Thin, testable wrapper around adb / fastboot (Google platform-tools).

All servicing features in this toolkit go through these two functions,
so nothing here depends on any leaked/exploit code -- only the public
ADB and Fastboot protocols.
"""

import os
import platform
import shutil
import subprocess


class ToolError(Exception):
    """Raised when adb/fastboot is missing or a command fails."""


def find_binary(name):
    """Locate `adb` / `fastboot`: PATH first, then ./platform-tools/."""
    path = shutil.which(name)
    if path:
        return path
    here = os.path.dirname(os.path.abspath(__file__))
    exe = name + (".exe" if platform.system() == "Windows" else "")
    cand = os.path.join(here, "platform-tools", exe)
    if os.path.isfile(cand):
        return cand
    return None


def run(binary, args, timeout=60):
    """Run one adb/fastboot command. Returns stdout text or raises ToolError."""
    if not binary:
        raise ToolError(
            "adb/fastboot not found. Install Google 'platform-tools' and add it "
            "to PATH, or copy adb+fastboot into gsmtool/platform-tools/."
        )
    proc = subprocess.run(
        [binary] + args, capture_output=True, text=True, timeout=timeout
    )
    if proc.returncode != 0:
        err = (proc.stderr or proc.stdout).strip()
        raise ToolError(
            f"{os.path.basename(binary)} {' '.join(args)} failed: {err}"
        )
    return proc.stdout
