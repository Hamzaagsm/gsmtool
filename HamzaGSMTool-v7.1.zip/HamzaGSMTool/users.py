"""Local user accounts for Hamza GSM Tool (stdlib only: sqlite3, hashlib, secrets).

- DB file lives next to the script (users.db), created on first app run.
- Passwords are hashed with PBKDF2-HMAC-SHA256 (200,000 iterations) + 16-byte salt.
- Plain passwords are NEVER stored.
"""

import hashlib
import secrets
import sqlite3
import time

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    username   TEXT PRIMARY KEY,
    pw_hash    TEXT NOT NULL,
    salt       TEXT NOT NULL,
    is_admin   INTEGER NOT NULL DEFAULT 0,
    is_blocked INTEGER NOT NULL DEFAULT 0,
    created_at REAL NOT NULL
);
"""

_ITERATIONS = 200_000
_DB_PATH = None  # set by init_db()


def init_db(path):
    """Point the module at a DB file and create the table if needed."""
    global _DB_PATH
    _DB_PATH = path
    con = sqlite3.connect(_DB_PATH)
    try:
        con.execute(SCHEMA)
        con.commit()
    finally:
        con.close()


def _con():
    if not _DB_PATH:
        raise RuntimeError("init_db() pehle call karo")
    return sqlite3.connect(_DB_PATH)


def _new_salt():
    return secrets.token_bytes(16).hex()


def _hash(password, salt_hex):
    return hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"),
        bytes.fromhex(salt_hex), _ITERATIONS).hex()


def _validate(username, password):
    if not username or not str(username).strip():
        raise ValueError("Username khaali nahi ho sakta.")
    if not password:
        raise ValueError("Password khaali nahi ho sakta.")
    if len(password) < 4:
        raise ValueError("Password kam az kam 4 characters ka ho.")


def user_count():
    con = _con()
    try:
        return con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    finally:
        con.close()


def admin_count():
    con = _con()
    try:
        return con.execute(
            "SELECT COUNT(*) FROM users WHERE is_admin = 1").fetchone()[0]
    finally:
        con.close()


def create_user(username, password, is_admin=False):
    """Create a user. Raises ValueError on bad input or duplicate name."""
    username = str(username).strip()
    _validate(username, password)
    salt = _new_salt()
    con = _con()
    try:
        exists = con.execute(
            "SELECT 1 FROM users WHERE username = ?", (username,)).fetchone()
        if exists:
            raise ValueError(f"Username '{username}' pehle se mojood hai.")
        con.execute(
            "INSERT INTO users (username, pw_hash, salt, is_admin, is_blocked, created_at)"
            " VALUES (?, ?, ?, ?, 0, ?)",
            (username, _hash(password, salt), salt,
             1 if is_admin else 0, time.time()))
        con.commit()
    finally:
        con.close()


def verify(username, password):
    """Check credentials.

    Returns (status, is_admin) where status is one of:
      "ok"      -- correct password, account active
      "blocked" -- correct password but account is blocked
      "bad"     -- wrong username or password (never says which)
    """
    username = str(username or "").strip()
    con = _con()
    try:
        row = con.execute(
            "SELECT pw_hash, salt, is_admin, is_blocked FROM users WHERE username = ?",
            (username,)).fetchone()
    finally:
        con.close()
    if not row:
        return ("bad", False)
    pw_hash, salt, is_admin, is_blocked = row
    if _hash(password or "", salt) != pw_hash:
        return ("bad", False)
    if is_blocked:
        return ("blocked", bool(is_admin))
    return ("ok", bool(is_admin))


def set_blocked(username, blocked):
    """Block (True) or unblock (False) a user. Refuses to block the last admin."""
    con = _con()
    try:
        row = con.execute(
            "SELECT is_admin FROM users WHERE username = ?", (username,)).fetchone()
        if not row:
            raise ValueError(f"Username '{username}' nahi mila.")
        if blocked and row[0] and admin_count() <= 1:
            raise ValueError("Aakhri admin ko block nahi kar sakte.")
        con.execute("UPDATE users SET is_blocked = ? WHERE username = ?",
                    (1 if blocked else 0, username))
        con.commit()
    finally:
        con.close()


def list_users():
    """Return [(username, is_admin, is_blocked), ...] oldest first."""
    con = _con()
    try:
        rows = con.execute(
            "SELECT username, is_admin, is_blocked FROM users ORDER BY created_at"
        ).fetchall()
    finally:
        con.close()
    return [(u, bool(a), bool(b)) for u, a, b in rows]


def reset_password(username, new_password):
    """Set a new password for a user."""
    if not new_password or len(new_password) < 4:
        raise ValueError("Password kam az kam 4 characters ka ho.")
    salt = _new_salt()
    con = _con()
    try:
        cur = con.execute("UPDATE users SET pw_hash = ?, salt = ? WHERE username = ?",
                          (_hash(new_password, salt), salt, username))
        if cur.rowcount == 0:
            raise ValueError(f"Username '{username}' nahi mila.")
        con.commit()
    finally:
        con.close()


def delete_user(username):
    """Delete a user. Refuses if it would delete the last admin."""
    con = _con()
    try:
        row = con.execute(
            "SELECT is_admin FROM users WHERE username = ?", (username,)).fetchone()
        if not row:
            raise ValueError(f"Username '{username}' nahi mila.")
        if row[0] and admin_count() <= 1:
            raise ValueError("Aakhri admin delete nahi ho sakta.")
        con.execute("DELETE FROM users WHERE username = ?", (username,))
        con.commit()
    finally:
        con.close()
