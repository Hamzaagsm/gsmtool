"""Single source of truth for the tool version."""

__version__ = "6.0"
