"""Tests for recovery (master key) + meta + Gmail restore. No real network."""
import os
import sqlite3
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import backup_admin
import recovery
import users

TMP = tempfile.mkdtemp(prefix="rec_test_")
DB = os.path.join(TMP, "users.db")
users.init_db(DB)

# --- key generation: format + uniqueness ---
k1 = recovery.generate_key()
k2 = recovery.generate_key()
assert k1 != k2
assert k1.startswith("HG7-")
parts = k1.split("-")
assert len(parts) == 8 and all(len(p) == 4 for p in parts[1:]), k1

# --- verify: asli key OK ---
assert recovery.verify_key(k1) is True
assert recovery.verify_key(k1.lower()) is True      # case insensitive
assert recovery.verify_key(k1.replace("-", " ")) is True  # space wali bhi

# --- verify: tampered key FAIL ---
assert recovery.verify_key(k1[:-1] + ("A" if k1[-1] != "A" else "B")) is False
assert recovery.verify_key("HG7-AAAA-BBBB-CCCC-DDDD-EEEE-FFFF-GGGG") is False
assert recovery.verify_key("ghalat-key") is False
assert recovery.verify_key("") is False
assert recovery.verify_key(None) is False

# --- meta round-trip ---
assert users.get_meta("recovery_key") is None
users.set_meta("recovery_key", k1)
assert users.get_meta("recovery_key") == k1
users.set_meta("recovery_key", k2)  # overwrite
assert users.get_meta("recovery_key") == k2

# --- asal SQLite DB ke bytes (IMAP + restore tests ke liye) ---
realdir = os.path.join(TMP, "realdb")
os.makedirs(realdir)
realdb = os.path.join(realdir, "users.db")
users.init_db(realdb)
users.create_user("hamza", "pass123", is_admin=True)
users.set_meta("recovery_key", k1)
with open(realdb, "rb") as fh:
    REAL_DB_BYTES = fh.read()
assert REAL_DB_BYTES[:16] == b"SQLite format 3\x00"
users.init_db(DB)  # wapis test DB

# --- backup email me key aati hai ---
db = os.path.join(TMP, "u.db")
with open(db, "wb") as fh:
    fh.write(b"x" * 200)
msg = backup_admin.build_message("a@b.c", db, recovery_key=k1)
text = msg.get_body(preferencelist=("plain",)).get_content()
assert k1 in text, "key email body me nahi!"
msg2 = backup_admin.build_message("a@b.c", db)
text2 = msg2.get_body(preferencelist=("plain",)).get_content()
assert "RECOVERY KEY" not in text2


# --- fake IMAP: fetch_latest_backup ---
from email.message import EmailMessage as _EM

# NOTE: REAL_DB_BYTES neeche (restore section se pehle) asal SQLite se banta hai;
# yahan sirf email builder define karte hain.


def make_backup_email(db_bytes):
    m = _EM()
    m["From"] = "a@b.c"
    m["To"] = "a@b.c"
    m["Subject"] = "Hamza GSM Tool backup - 2026-10-08 10:00"
    m.set_content("backup")
    m.add_attachment(db_bytes, maintype="application",
                     subtype="octet-stream",
                     filename="users-backup-2026-10-08.db")
    return m.as_bytes()


class FakeIMAP:
    mode = "ok"  # ok | noresult | noattach | badlogin

    def __init__(self, host, port):
        assert host == "imap.gmail.com" and port == 993
        self.logged_in = False

    def login(self, user, pw):
        if self.mode == "badlogin" or pw != "good-app-password":
            import imaplib
            raise imaplib.IMAP4.error("bad")
        self.logged_in = True

    def select(self, box):
        return "OK", [b"1"]

    def search(self, charset, *criteria):
        if self.mode == "noresult":
            return "OK", [b""]
        return "OK", [b"1 2 3"]

    def fetch(self, num, _spec):
        assert num == b"3"  # latest
        if self.mode == "noattach":
            m = _EM()
            m["Subject"] = "Hamza GSM Tool backup"
            m.set_content("no attachment here")
            return "OK", [(b"3 (RFC822)", m.as_bytes())]
        return "OK", [(b"3 (RFC822)", make_backup_email(REAL_DB_BYTES))]

    def logout(self):
        return "OK", [b""]


ok, msg, data = backup_admin.fetch_latest_backup(
    "a@b.c", "good-app-password", imap_class=FakeIMAP)
assert ok and data == REAL_DB_BYTES, (ok, msg)

FakeIMAP.mode = "badlogin"
ok, msg, data = backup_admin.fetch_latest_backup(
    "a@b.c", "wrong", imap_class=FakeIMAP)
assert not ok and "App Password" in msg and data is None, msg

FakeIMAP.mode = "noresult"
ok, msg, data = backup_admin.fetch_latest_backup(
    "a@b.c", "good-app-password", imap_class=FakeIMAP)
assert not ok and "koi backup" in msg, msg

FakeIMAP.mode = "noattach"
ok, msg, data = backup_admin.fetch_latest_backup(
    "a@b.c", "good-app-password", imap_class=FakeIMAP)
assert not ok and "attachment" in msg, msg

FakeIMAP.mode = "ok"
ok, msg, data = backup_admin.fetch_latest_backup(
    "", "", imap_class=FakeIMAP)
assert not ok and data is None

# --- restore_db: safety copy + replace + validation ---
base = os.path.join(TMP, "restore_pc")
os.makedirs(base)
old_db = os.path.join(base, "users.db")
with open(old_db, "wb") as fh:
    fh.write(b"SQLite format 3\x00" + b"OLD" * 100)

ok, msg = backup_admin.restore_db(base, REAL_DB_BYTES)
assert ok, msg
with open(old_db, "rb") as fh:
    assert fh.read() == REAL_DB_BYTES
import glob
safety = glob.glob(os.path.join(base, "users.db.backup-*"))
assert len(safety) == 1
with open(safety[0], "rb") as fh:
    assert b"OLD" in fh.read()

# kharab bytes reject
ok, msg = backup_admin.restore_db(base, b"not a db")
assert not ok, msg
ok, msg = backup_admin.restore_db(base, b"")
assert not ok, msg

# restored DB khulti hai: admin + key wapis mile
users.init_db(old_db)
lst = users.list_users()
assert ("hamza", True, False, None) in lst, lst
assert users.get_meta("recovery_key") == k1
assert users.verify("hamza", "pass123") == ("ok", True)

print("All recovery/restore tests passed.")
