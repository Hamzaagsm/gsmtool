"""Popular Pakistan-market models per brand.

HONESTY RULES (do not weaken):
- "code" is filled ONLY when the model number is verified/confident.
- Otherwise "code" is "" and the UI shows "--"; chipset may be
  "verify on device".
- Always verify the exact code on the physical device before flashing.
"""

MODELS = {
    "samsung": [
        {"model": "Galaxy A54", "code": "SM-A546", "chipset": "Exynos 1380"},
        {"model": "Galaxy A34", "code": "SM-A346", "chipset": "Dimensity 1080"},
        {"model": "Galaxy A35", "code": "SM-A356", "chipset": "Exynos 1380"},
        {"model": "Galaxy A25", "code": "SM-A256", "chipset": "Exynos 1280"},
        {"model": "Galaxy A15", "code": "SM-A155", "chipset": "Helio G99"},
        {"model": "Galaxy A05s", "code": "SM-A057", "chipset": "Snapdragon 680"},
        {"model": "Galaxy A04s", "code": "SM-A047", "chipset": "Exynos 850"},
        {"model": "Galaxy M34", "code": "SM-M346", "chipset": "Exynos 1280"},
        {"model": "Galaxy S23", "code": "SM-S911", "chipset": "Snapdragon 8 Gen 2"},
        {"model": "Galaxy S24", "code": "SM-S921", "chipset": "Exynos 2400"},
    ],
    "xiaomi": [
        {"model": "Redmi Note 13 Pro 5G", "code": "2312DRA50G", "chipset": "Snapdragon 7s Gen 2"},
        {"model": "Poco X6 Pro", "code": "2311DRK48G", "chipset": "Dimensity 8300 Ultra"},
        {"model": "Poco X6 5G", "code": "23122PCD1G", "chipset": "Snapdragon 7s Gen 2"},
        {"model": "Redmi 13C", "code": "23124RN87G", "chipset": "Helio G85"},
        {"model": "Redmi Note 13 (4G)", "code": "", "chipset": "Snapdragon 685 (verify)"},
        {"model": "Redmi 12", "code": "", "chipset": "Helio G88 (verify)"},
        {"model": "Redmi A3", "code": "", "chipset": "verify on device"},
        {"model": "Poco M6 Pro", "code": "", "chipset": "Helio G99 Ultra (verify)"},
        {"model": "Xiaomi 13T", "code": "", "chipset": "Dimensity 8200 Ultra (verify)"},
        {"model": "Redmi Note 12", "code": "", "chipset": "Snapdragon 685 (verify)"},
    ],
    "tecno": [
        {"model": "Spark 20", "code": "KJ5", "chipset": "verify on device"},
        {"model": "Spark 20 Pro", "code": "KJ6", "chipset": "Helio G99"},
        {"model": "Spark 20C", "code": "BG7n", "chipset": "verify on device"},
        {"model": "Spark 20 Pro+", "code": "KJ7", "chipset": "verify on device"},
        {"model": "Spark 20 Pro 5G", "code": "KJ8", "chipset": "Dimensity 810"},
        {"model": "Spark 10 Pro", "code": "", "chipset": "verify on device"},
        {"model": "Camon 30", "code": "", "chipset": "verify on device"},
        {"model": "Camon 40", "code": "", "chipset": "verify on device"},
        {"model": "Pova 6", "code": "", "chipset": "verify on device"},
        {"model": "Pop 8", "code": "", "chipset": "verify on device"},
    ],
    "infinix": [
        {"model": "Note Edge", "code": "X6887", "chipset": "Dimensity 7100"},
        {"model": "Hot 50 Pro+", "code": "X6880", "chipset": "Helio G100"},
        {"model": "Hot 50 Pro", "code": "X6881", "chipset": "Helio G99"},
        {"model": "Note 40 5G", "code": "X6852", "chipset": "Dimensity 7020"},
        {"model": "Hot 40i", "code": "", "chipset": "verify on device"},
        {"model": "Note 40 Pro", "code": "", "chipset": "verify on device"},
        {"model": "Smart 8", "code": "", "chipset": "verify on device"},
        {"model": "GT 20 Pro", "code": "", "chipset": "Dimensity 8200U (verify)"},
        {"model": "Hot 50i", "code": "", "chipset": "verify on device"},
        {"model": "Zero 30", "code": "", "chipset": "verify on device"},
    ],
    "itel": [
        {"model": "S23", "code": "", "chipset": "Unisoc T606 (verify)"},
        {"model": "P55", "code": "", "chipset": "verify on device"},
        {"model": "A70", "code": "", "chipset": "verify on device"},
        {"model": "S25", "code": "", "chipset": "verify on device"},
        {"model": "P40", "code": "", "chipset": "verify on device"},
        {"model": "A60", "code": "", "chipset": "verify on device"},
    ],
    "oppo": [
        {"model": "A58 4G", "code": "CPH2577", "chipset": "Helio G85"},
        {"model": "A38", "code": "", "chipset": "verify on device"},
        {"model": "A18", "code": "", "chipset": "verify on device"},
        {"model": "A60", "code": "", "chipset": "verify on device"},
        {"model": "Reno 11F", "code": "", "chipset": "verify on device"},
        {"model": "A78", "code": "", "chipset": "verify on device"},
        {"model": "A57 (2022)", "code": "", "chipset": "verify on device"},
    ],
    "vivo": [
        {"model": "Y36", "code": "", "chipset": "verify on device"},
        {"model": "Y28", "code": "", "chipset": "verify on device"},
        {"model": "Y17s", "code": "", "chipset": "verify on device"},
        {"model": "V30", "code": "", "chipset": "verify on device"},
        {"model": "Y21", "code": "", "chipset": "verify on device"},
        {"model": "V29e", "code": "", "chipset": "verify on device"},
    ],
    "realme": [
        {"model": "C55", "code": "RMX3710", "chipset": "Helio G88"},
        {"model": "C67", "code": "RMX3890", "chipset": "Snapdragon 685"},
        {"model": "11 Pro+", "code": "RMX3771", "chipset": "Dimensity 7050"},
        {"model": "Note 50", "code": "", "chipset": "verify on device"},
        {"model": "C53", "code": "", "chipset": "verify on device"},
        {"model": "Narzo 70x", "code": "", "chipset": "verify on device"},
        {"model": "12 Pro+", "code": "", "chipset": "verify on device"},
    ],
    "motorola": [
        {"model": "Moto G85", "code": "XT2427", "chipset": "Snapdragon 6s Gen 3"},
        {"model": "Edge 50 Fusion", "code": "", "chipset": "verify on device"},
        {"model": "Moto G34", "code": "", "chipset": "verify on device"},
        {"model": "Moto E14", "code": "", "chipset": "verify on device"},
        {"model": "Moto G24", "code": "", "chipset": "verify on device"},
    ],
    "nokia": [
        {"model": "G42", "code": "", "chipset": "Snapdragon 480+ (verify)"},
        {"model": "C32", "code": "", "chipset": "verify on device"},
        {"model": "G60", "code": "", "chipset": "verify on device"},
        {"model": "C22", "code": "", "chipset": "verify on device"},
        {"model": "G21", "code": "", "chipset": "verify on device"},
    ],
    "oneplus": [
        {"model": "Nord CE4", "code": "CPH2613", "chipset": "Snapdragon 7 Gen 3"},
        {"model": "12R", "code": "CPH2607", "chipset": "Snapdragon 8 Gen 2"},
        {"model": "Nord CE3 Lite", "code": "", "chipset": "verify on device"},
        {"model": "Nord 3", "code": "", "chipset": "verify on device"},
        {"model": "11R", "code": "", "chipset": "verify on device"},
    ],
    "huawei": [
        {"model": "Nova 12 SE", "code": "", "chipset": "verify on device"},
        {"model": "Nova Y72", "code": "", "chipset": "verify on device"},
        {"model": "Nova 11i", "code": "", "chipset": "verify on device"},
        {"model": "Nova Y90", "code": "", "chipset": "verify on device"},
        {"model": "Nova 10 SE", "code": "", "chipset": "verify on device"},
    ],
    "qmobile": [
        {"model": "Noir series (legacy)", "code": "", "chipset": "MTK/SPD (verify)"},
        {"model": "View series (legacy)", "code": "", "chipset": "verify on device"},
        {"model": "Energy series (legacy)", "code": "", "chipset": "verify on device"},
        {"model": "i-series (legacy)", "code": "", "chipset": "verify on device"},
        {"model": "S-series (legacy)", "code": "", "chipset": "verify on device"},
    ],
}


def get_models(brand_key):
    """Return list of {model, code, chipset} for a brand key (or [])."""
    return MODELS.get(brand_key, [])


def search_models(brand_key, query):
    """Case-insensitive filter over model/code/chipset."""
    q = (query or "").strip().lower()
    if not q:
        return get_models(brand_key)
    return [m for m in get_models(brand_key)
            if q in m["model"].lower()
            or q in m["code"].lower()
            or q in m["chipset"].lower()]


def model_count(brand_key):
    return len(get_models(brand_key))
