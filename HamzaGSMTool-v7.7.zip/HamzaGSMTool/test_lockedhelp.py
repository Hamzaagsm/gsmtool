"""Tests for lockedhelp (locked-phone honest guide)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lockedhelp

BRANDS = ["samsung", "xiaomi", "tecno", "infinix", "itel", "oppo", "vivo",
          "realme", "motorola", "nokia", "oneplus", "huawei", "qmobile",
          "iphone"]
assert len(BRANDS) == 14

for k in BRANDS:
    t = lockedhelp.help_text(k)
    # honest core message har brand me
    assert "SEEDHI BAAT" in t, k
    assert "USB Debugging" in t, k
    assert "Recovery mode:" in t, k
    assert "Fastboot mode:" in t, k
    assert "EDL / BROM mode:" in t, k
    assert "HAR MODE KI ASLIYAT" in t, k
    # koi jhoota wada nahi: "100%", "guarantee", "ek click me unlock" jaisay lafz nahi
    low = t.lower()
    assert "guarantee" not in low, k
    assert "100%" not in low, k

assert "Brand nahi mila" in lockedhelp.help_text("nonsense")

print("All lockedhelp tests passed.")
