"""Offline tests for features.py parsers -- no phone needed."""

from features import (
    find_suspicious_packages,
    find_transsion_id_packages,
    parse_adb_devices,
    parse_device_admins,
    parse_fastboot_devices,
    parse_packages,
)

ADB_SAMPLE = """List of devices attached
8f9a2c1\tdevice product:noteedge model:X6887 device:edge
emulator-5554\tunauthorized
"""

assert parse_adb_devices(ADB_SAMPLE) == [
    ("8f9a2c1", "device"),
    ("emulator-5554", "unauthorized"),
]
assert parse_adb_devices("List of devices attached\n\n") == []

FB_SAMPLE = "8f9a2c1\tfastboot\n"
assert parse_fastboot_devices(FB_SAMPLE) == ["8f9a2c1"]

PKG_SAMPLE = """package:com.android.settings
package:com.transsion.mdm.agent
package:com.google.android.gms
"""
pkgs = parse_packages(PKG_SAMPLE)
assert pkgs == ["com.android.settings", "com.transsion.mdm.agent",
                "com.google.android.gms"]
assert find_suspicious_packages(pkgs) == ["com.transsion.mdm.agent"]
assert find_suspicious_packages(["com.android.chrome"]) == []

DUMPSYS_SAMPLE = """
Active admin ComponentInfo{com.transsion.mdm.agent/.AdminReceiver}:
  ...
Active password quality: 0
"""
assert parse_device_admins(DUMPSYS_SAMPLE) == [
    "com.transsion.mdm.agent/.AdminReceiver"
]
assert parse_device_admins("no admins here") == []

TRANSSION_SAMPLE = [
    "com.transsion.idlock",
    "com.android.settings",
    "com.transsion.account",
    "com.google.android.gms",
]
assert find_transsion_id_packages(TRANSSION_SAMPLE) == [
    "com.transsion.idlock",
    "com.transsion.account",
]
assert find_transsion_id_packages(["com.android.chrome"]) == []
assert find_transsion_id_packages([]) == []

print("All parser tests passed.")
