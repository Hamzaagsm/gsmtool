"""Tests for iphone.py -- structure, guides, and safe behavior."""

import iphone


def test_itunes_url_official():
    assert iphone.ITUNES_URL.startswith("https://www.apple.com/")


def test_dfu_guides_cover_generations():
    assert len(iphone.DFU_GUIDES) >= 3
    for gen, g in iphone.DFU_GUIDES.items():
        assert g["recovery"] and g["dfu"], f"incomplete guide for {gen}"


def test_dfu_text():
    gen = "iPhone 8 / X / 11 / 12 / 13 / 14 / 15 / 16"
    txt = iphone.dfu_text(gen)
    assert "RECOVERY" in txt and "DFU" in txt
    assert "KAALI" in txt  # screen-black note
    assert "nahi mila" in iphone.dfu_text("Nokia 3310")


def test_activation_lock_notes_honest():
    n = iphone.ACTIVATION_LOCK_NOTES
    assert "NAHI" in n  # no false bypass promise
    assert "Apple Support" in n or "Apple ID" in n


def test_functions_never_raise_without_tools():
    # CI has no libimobiledevice -- all must return friendly strings
    for fn in (iphone.check_tools, iphone.detect_iphone, iphone.device_info,
               iphone.enter_recovery, iphone.exit_recovery):
        out = fn()
        assert isinstance(out, str) and len(out) > 0
    assert "NOT FOUND" in iphone.check_tools()
