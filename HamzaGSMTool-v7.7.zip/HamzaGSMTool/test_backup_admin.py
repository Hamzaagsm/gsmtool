"""Tests for backup_admin (Gmail auto-backup). No real network used."""
import os
import sys
import tempfile
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import backup_admin

TMP = tempfile.mkdtemp(prefix="bkadm_test_")


class FakeSMTP:
    instances = []

    def __init__(self, host, port, timeout=30):
        self.host = host
        self.port = port
        self.logged_in = None
        self.sent = None
        FakeSMTP.instances.append(self)

    def starttls(self):
        pass

    def login(self, user, pw):
        self.logged_in = (user, pw)
        if pw != "good-app-password":
            import smtplib
            raise smtplib.SMTPAuthenticationError(535, b"bad")

    def send_message(self, msg):
        self.sent = msg

    def quit(self):
        pass


# --- config round-trip ---
cfg = backup_admin.save_config(TMP, "test@gmail.com", "abcd efgh", True)
assert cfg["gmail"] == "test@gmail.com"
assert cfg["app_password"] == "abcdefgh"  # space hata
assert cfg["auto"] is True
loaded = backup_admin.load_config(TMP)
assert loaded == cfg, loaded

# empty dir -> defaults
with tempfile.TemporaryDirectory() as td:
    d = backup_admin.load_config(td)
    assert d == {"gmail": "", "app_password": "", "auto": False,
                 "last_backup": 0.0}

# --- needs_backup logic ---
now = time.time()
assert backup_admin.needs_backup(
    {"auto": True, "gmail": "a@b.c", "app_password": "x",
     "last_backup": now - 25 * 3600}, now) is True
assert backup_admin.needs_backup(
    {"auto": True, "gmail": "a@b.c", "app_password": "x",
     "last_backup": now - 3600}, now) is False
assert backup_admin.needs_backup(
    {"auto": False, "gmail": "a@b.c", "app_password": "x",
     "last_backup": 0}, now) is False
assert backup_admin.needs_backup(
    {"auto": True, "gmail": "", "app_password": "x",
     "last_backup": 0}, now) is False

# --- build_message (no network) ---
db = os.path.join(TMP, "users.db")
with open(db, "wb") as fh:
    fh.write(b"fake-db-bytes")
msg = backup_admin.build_message("test@gmail.com", db)
assert msg["To"] == "test@gmail.com" and msg["From"] == "test@gmail.com"
atts = list(msg.iter_attachments())
assert len(atts) == 1 and atts[0].get_filename().startswith("users-backup-")

# --- send_backup success (fake SMTP) ---
FakeSMTP.instances.clear()
ok, note = backup_admin.send_backup("test@gmail.com", "good-app-password",
                                    db, smtp_class=FakeSMTP)
assert ok, note
inst = FakeSMTP.instances[-1]
assert inst.host == "smtp.gmail.com" and inst.port == 587
assert inst.logged_in == ("test@gmail.com", "good-app-password")
assert inst.sent is not None

# --- send_backup bad password ---
ok, note = backup_admin.send_backup("test@gmail.com", "wrong",
                                    db, smtp_class=FakeSMTP)
assert not ok and "App Password" in note, note

# --- send_backup missing db ---
ok, note = backup_admin.send_backup("test@gmail.com", "good-app-password",
                                    os.path.join(TMP, "nope.db"),
                                    smtp_class=FakeSMTP)
assert not ok and "users.db" in note

# --- mark_backed_up resets the 24h timer ---
backup_admin.save_config(TMP, "test@gmail.com", "good-app-password", True,
                         last_backup=now - 25 * 3600)
assert backup_admin.needs_backup(backup_admin.load_config(TMP)) is True
backup_admin.mark_backed_up(TMP)
assert backup_admin.needs_backup(backup_admin.load_config(TMP)) is False

print("All backup_admin tests passed.")
