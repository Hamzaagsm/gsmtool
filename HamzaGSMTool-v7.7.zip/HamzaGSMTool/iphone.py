"""iPhone support for Hamza GSM Tool v7.2 (stdlib only).

IMAANDAR SCOPE -- pehle parh lo:
  * iPhone ADB/Fastboot par NAHI chalta (ye Android ke protocols hain).
    iPhone Apple ke apne protocols (MobileDevice / Recovery / DFU) use karta hai.
  * Ye module jo SACH me kar sakta hai:
      - iPhone detect karna (libimobiledevice tools hon to: idevice_id)
      - Device info parhna (ideviceinfo)
      - Recovery mode me bhejna / nikalna (ideviceenterrecovery / irecovery)
      - DFU / Recovery key combos (har generation ke liye, safe guide)
      - iTunes official download link (drivers iTunes ke sath aate hain)
  * Jo NAHI kar sakta (koi bhi free tool nahi kar sakta):
      - Naye iOS par iCloud Activation Lock bypass
      - iPhone "flashing" Android jaisi (restore iTunes/Finder se hota hai)
  * libimobiledevice Windows par pehle se nahi hota -- iTunes install karne
    se Apple drivers aate hain; command-line tools alag se chahiye.
"""

import shutil
import subprocess

# Official Apple iTunes download page (verified official).
ITUNES_URL = "https://www.apple.com/itunes/download/"

# iPhone generation -> {recovery, dfu}
DFU_GUIDES = {
    "iPhone 8 / X / 11 / 12 / 13 / 14 / 15 / 16": {
        "recovery": ("Volume UP dabao-chhodo, phir Volume DOWN dabao-chhodo, "
                     "phir SIDE button dabaye rakho -- Apple logo aaye to bhi "
                     "NA chhodo, recovery screen (cable + laptop) aane tak."),
        "dfu": ("Phone ko PC se lagao. Vol UP dabao-chhodo, Vol DOWN "
                "dabao-chhodo, phir SIDE 10 sec dabaye rakho. Phir SIDE + "
                "Vol DOWN 5 sec, phir sirf Vol DOWN 10 sec -- screen KAALI "
                "rahe to DFU hai (kuch nazar aaye to dobara karo)."),
    },
    "iPhone 7 / 7 Plus": {
        "recovery": ("Volume DOWN + SIDE (power) dono dabaye rakho -- Apple "
                     "logo ke baad bhi na chhodo, recovery screen tak."),
        "dfu": ("PC se lagao. Vol DOWN + SIDE 10 sec, phir sirf Vol DOWN "
                "10 sec -- screen kaali rahe to DFU."),
    },
    "iPhone 6s / SE (1st gen) / purane": {
        "recovery": ("HOME + SIDE (power) dono dabaye rakho -- Apple logo ke "
                     "baad bhi na chhodo, recovery screen tak."),
        "dfu": ("PC se lagao. HOME + SIDE 10 sec, phir sirf HOME 10 sec -- "
                "screen kaali rahe to DFU."),
    },
}

ACTIVATION_LOCK_NOTES = """iCloud Activation Lock -- honest picture:

* Activation Lock Apple ki theft-protection hai (Android FRP jaisi).
* Naye iOS par koi FREE / one-click bypass NAHI hai -- jo "100% iCloud
  bypass" ka wada kare wo aksar scam hai.
* LEGIT tareeqe:
    1) Apple ID + password (asal owner se lo)
    2) Proof of purchase (bill/box) ke sath Apple Support -- wo hata sakte hain
* Purane devices (A9-A11 chips: iPhone X tak) par checkra1n jaisi exploits
  hain, lekin wo Linux/Mac mangti hain aur har iOS par kaam nahi kartin.
* Customer ka phone ho to hamesha unse Apple ID likhwa kar kaam karo.
"""


def _which_tools():
    return {
        "idevice_id": shutil.which("idevice_id"),
        "ideviceinfo": shutil.which("ideviceinfo"),
        "ideviceenterrecovery": shutil.which("ideviceenterrecovery"),
        "irecovery": shutil.which("irecovery"),
    }


def check_tools():
    """Report which libimobiledevice tools are available. Never raises."""
    found = {k: v for k, v in _which_tools().items() if v}
    lines = ["== iPhone tools =="]
    for name in ("idevice_id", "ideviceinfo", "ideviceenterrecovery",
                 "irecovery"):
        lines.append(f"{name}: {'FOUND' if name in found else 'NOT FOUND'}")
    if not found:
        lines.append("")
        lines.append("Tools nahi mile. iTunes install karo (Apple drivers ke "
                     "liye) -- neeche iTunes button hai. Command-line tools "
                     "(libimobiledevice) alag se chahiye hote hain.")
    return "\n".join(lines)


def detect_iphone():
    """List connected iPhones (UDIDs). Never raises."""
    exe = shutil.which("idevice_id")
    if not exe:
        return ("idevice_id nahi mila -- pehle tools install karo "
                "(neeche Check Tools dekho).")
    try:
        out = subprocess.run([exe, "-l"], capture_output=True, text=True,
                             timeout=15).stdout.strip()
    except Exception as exc:  # noqa: BLE001 - report, don't crash
        return f"Detect fail: {exc}"
    if not out:
        return "Koi iPhone connect nahi hai (cable check karo, iTunes drivers)."
    lines = ["Connected iPhone(s):"]
    for udid in out.splitlines():
        lines.append(f"  - {udid.strip()}")
    return "\n".join(lines)


def device_info():
    """ideviceinfo output. Never raises."""
    exe = shutil.which("ideviceinfo")
    if not exe:
        return "ideviceinfo nahi mila -- pehle tools install karo."
    try:
        out = subprocess.run([exe], capture_output=True, text=True,
                             timeout=20).stdout
    except Exception as exc:  # noqa: BLE001 - report, don't crash
        return f"Info fail: {exc}"
    keep = ("DeviceName", "ProductType", "ProductVersion", "BuildVersion",
            "SerialNumber", "IMEI", "ICCID", "BatteryLevel",
            "ActivationState")
    rows = []
    for line in out.splitlines():
        if ":" in line:
            k = line.split(":", 1)[0].strip()
            if k in keep:
                rows.append(line.strip())
    return "\n".join(rows) if rows else "Info nahi mil saki."


def enter_recovery():
    """Send first connected iPhone to recovery mode. Never raises."""
    exe = shutil.which("ideviceenterrecovery")
    if not exe:
        return "ideviceenterrecovery nahi mila -- pehle tools install karo."
    idev = shutil.which("idevice_id")
    udid = ""
    if idev:
        try:
            udid = subprocess.run(
                [idev, "-l"], capture_output=True, text=True,
                timeout=15).stdout.splitlines()[0].strip()
        except Exception:  # noqa: BLE001 - no udid, try without
            udid = ""
    try:
        args = [exe, udid] if udid else [exe]
        subprocess.run(args, capture_output=True, text=True, timeout=20)
        return ("Recovery command bhej diya -- screen par cable+laptop "
                "nazar aaye to recovery me hai.")
    except Exception as exc:  # noqa: BLE001 - report, don't crash
        return f"Recovery fail: {exc}"


def exit_recovery():
    """Kick iPhone out of recovery mode (irecovery -n). Never raises."""
    exe = shutil.which("irecovery")
    if not exe:
        return "irecovery nahi mila -- pehle tools install karo."
    try:
        subprocess.run([exe, "-n"], capture_output=True, text=True,
                       timeout=20)
        return "Exit-recovery command bhej diya -- phone reboot hoga."
    except Exception as exc:  # noqa: BLE001 - report, don't crash
        return f"Exit fail: {exc}"


def dfu_text(generation):
    """Human-readable DFU+recovery guide for one generation key."""
    g = DFU_GUIDES.get(generation)
    if not g:
        return "Is generation ka data nahi mila."
    return (f"=== {generation} ===\n"
            f"RECOVERY MODE:\n{g['recovery']}\n\n"
            f"DFU MODE:\n{g['dfu']}\n\n"
            f"NOTE: DFU me screen poori KAALI rehti hai -- kuch bhi nazar "
            f"aaye to DFU nahi laga, dobara karo.\n")
