"""Locked Phone Helper -- honest guide jab phone locked ho.

SEEDHI BAAT (user ko bhi dikhayi jati hai):
- Locked phone par USB debugging ON NAHI ho sakti. Ye Android ki security
  hai -- duniya ka koi software ye nahi kar sakta.
- Doosre (paid) tools EDL/BROM mode use karte hain -- phone ke "neeche wale
  darwaze", Android ke bahar. Un me jane ke liye key combo / test point /
  special cable chahiye, aur aksar vendor-authorized files ya paid server.
- Ye helper jadoo nahi karta: har brand ke liye sahi key combos deta hai,
  fastboot me ASAL check karta hai, aur har mode me jo honestly ho sakta
  hai wahi batata hai.
"""

# brand_key -> {"recovery":..., "fastboot":..., "edl":..., "note":...}
# combos public, standard tareeqe hain.
LOCK_MODES = {
    "samsung": {
        "recovery": "Phone OFF -> Vol UP + Power dabaye rakho",
        "fastboot": "Samsung me fastboot NAHI hota (Download mode hota hai)",
        "edl": "Download Mode: Vol UP + Vol DOWN dono -> USB lagao "
               "(purane: Vol Down + Home + Power)",
        "note": "Odin se official firmware flash ho sakti hai. FRP latest "
                "security par mushkil -- paid tools (Chimera/UMT) ya SamFW.",
    },
    "xiaomi": {
        "recovery": "Vol UP + Power dabaye rakho",
        "fastboot": "Vol DOWN + Power dabaye rakho",
        "edl": "Naye models par key combo BLOCKED. Purane: fastboot me "
               "'fastboot oem edl'. Ya test point / deep-flash cable.",
        "note": "EDL flashing ke liye authorized Mi account chahiye. "
                "Fastboot ROM bina auth ke flash ho sakti hai (bootloader "
                "unlock zaroori -- data jayega).",
    },
    "tecno": {
        "recovery": "Vol UP + Power dabaye rakho",
        "fastboot": "MTK phones me fastboot aam NAHI hota",
        "edl": "BROM Mode: Phone OFF -> Vol UP dabaye rakho -> USB lagao "
               "(test point ki zaroorat NAHI)",
        "note": "BROM me SP Flash Tool se kaam hota hai. FRP reset BROM se "
                "mumkin (purane security patch par).",
    },
    "infinix": {
        "recovery": "Vol UP + Power dabaye rakho",
        "fastboot": "MTK phones me fastboot aam NAHI hota",
        "edl": "BROM Mode: Phone OFF -> Vol UP dabaye rakho -> USB lagao "
               "(test point ki zaroorat NAHI)",
        "note": "BROM me SP Flash Tool se kaam hota hai. FRP reset BROM se "
                "mumkin (purane security patch par).",
    },
    "itel": {
        "recovery": "Vol UP + Power dabaye rakho",
        "fastboot": "Chipset par munhasir (MTK: nahi / SPD: haan)",
        "edl": "MTK: Vol UP + USB (phone OFF). SPD: Vol DOWN + USB. Pehle "
               "chipset confirm karo.",
        "note": "SPD models me Research/Upgrade Tool, MTK me SP Flash Tool.",
    },
    "oppo": {
        "recovery": "Vol DOWN + Power dabaye rakho",
        "fastboot": "Vol DOWN + Power (kuch models)",
        "edl": "Aksar LOCKED -- test point + authorized account chahiye",
        "note": "Naye Oppo me free flashing mushkil. Exact model ka status "
                "pehle verify karo.",
    },
    "vivo": {
        "recovery": "Vol UP + Power (naye) / Vol DOWN + Power (purane)",
        "fastboot": "Vol DOWN + Power (kuch models)",
        "edl": "Aksar LOCKED -- test point + authorized account chahiye",
        "note": "Naye Vivo me free flashing mushkil. Fastboot khule to "
                "device info dekho.",
    },
    "realme": {
        "recovery": "Vol DOWN + Power dabaye rakho",
        "fastboot": "Vol DOWN + Power (kuch models)",
        "edl": "Aksar LOCKED -- test point + authorized account chahiye",
        "note": "Oppo jaisa haal -- naye models me paid/authorized rasta.",
    },
    "motorola": {
        "recovery": "Vol DOWN + Power -> menu me Recovery chuno",
        "fastboot": "Vol DOWN + Power dabaye rakho",
        "edl": "Qualcomm models: test point se 9008 (mushkil)",
        "note": "Fastboot khul jaye to bootloader status check karo. "
                "Motorola ka official unlock program hai (data jayega).",
    },
    "nokia": {
        "recovery": "Vol UP + Power dabaye rakho",
        "fastboot": "Vol DOWN + Power (kuch models)",
        "edl": "Aksar LOCKED -- authorized service chahiye",
        "note": "Nokia (HMD) me free flashing ke raste band hain.",
    },
    "oneplus": {
        "recovery": "Vol DOWN + Power dabaye rakho",
        "fastboot": "Vol UP + Vol DOWN + Power (kuch) / Vol DOWN + Power",
        "edl": "Test point se 9008; MSM Tool ko authorized account chahiye",
        "note": "Purane OnePlus (6T tak) me MSM Tool free tha; naye me auth.",
    },
    "huawei": {
        "recovery": "Vol UP + Power dabaye rakho (eRecovery)",
        "fastboot": "Vol DOWN + Power (bootloader locked rehta hai)",
        "edl": "Naye models LOCKED -- test point + paid service",
        "note": "Huawei ne bootloader unlock band kar diya hai (2018 se).",
    },
    "qmobile": {
        "recovery": "Vol UP + Power dabaye rakho",
        "fastboot": "SPD wale: Vol DOWN + Power (kuch models)",
        "edl": "MTK: Vol UP + USB (OFF). SPD: Vol DOWN + USB (OFF).",
        "note": "Chipset confirm karo -- MTK (SP Flash) ya SPD (Research Tool).",
    },
    "iphone": {
        "recovery": "Model ke hisab se (iPhone tab me guide hai)",
        "fastboot": "iPhone me fastboot NAHI hota",
        "edl": "DFU Mode: iPhone tab me generation-wise guide hai",
        "note": "Activation Lock (iCloud) kisi free tool se NAHI khulta. "
                "Sirf asal owner Apple ID se khol sakta hai.",
    },
}

HONEST_TOP = (
    "SEEDHI BAAT:\n"
    "- Locked phone par USB Debugging ON NAHI ho sakti. Ye Android/iOS ki "
    "security hai -- duniya ka koi software ye nahi kar sakta.\n"
    "- Doosre tools EDL/BROM mode use karte hain (phone ke 'neeche wale "
    "darwaze'). Un me jane ke liye key combo / test point / special cable "
    "chahiye, aur aksar vendor-authorized files ya PAID server.\n"
    "- Neeche apne brand ke key combos dekho. Jo mode khul jaye, us me jo "
    "honestly ho sakta hai wahi karo -- ghalat file se phone DEAD ho sakta hai."
)

MODE_TRUTH = (
    "\nHAR MODE KI ASLIYAT:\n"
    "- Recovery: yahan se FRP/password NAHI khulta. Sirf official update ya "
    "wipe (wipe se FRP nahi jata).\n"
    "- Fastboot: khul jaye to device info / bootloader status dekho. "
    "Flashing ke liye aksar unlock + authorized files chahiye.\n"
    "- EDL/BROM: flashing vendor files mangti hai. Xiaomi: authorized Mi "
    "account. Oppo/Vivo/Naye: paid/authorized rasta. Ghalat file = dead phone."
)


def brand_names():
    return [(k, v["recovery"] is not None and k) for k, v in LOCK_MODES.items()]


def help_text(brand_key):
    d = LOCK_MODES.get(brand_key)
    if not d:
        return "Brand nahi mila."
    lines = [
        HONEST_TOP,
        f"\n--- {brand_key.upper()} ---",
        f"Recovery mode: {d['recovery']}",
        f"Fastboot mode: {d['fastboot']}",
        f"EDL / BROM mode: {d['edl']}",
        f"\nNote: {d['note']}",
        MODE_TRUTH,
    ]
    return "\n".join(lines)
