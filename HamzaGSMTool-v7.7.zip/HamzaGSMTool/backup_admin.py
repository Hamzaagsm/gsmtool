"""Admin auto-backup: users.db Gmail par email hota hai (sirf Admin ke liye).

Gmail seedha password se login nahi karne deta -- "App Password" chahiye:
  1. Google Account -> Security -> 2-Step Verification ON karo.
  2. Wahi Security page par "App passwords" kholo.
  3. App: "Mail", Device: apna PC naam -> Generate.
  4. 16 harf wala password copy karke tool me dalo (space hata kar).

Config sirf is PC par backup_config.json me save hoti hai -- kahin upload nahi hoti.
"""

import json
import os
import smtplib
import time
from email.message import EmailMessage

CONFIG_NAME = "backup_config.json"
BACKUP_INTERVAL = 24 * 3600  # din me ek dafa
SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = 587


def config_path(base_dir):
    return os.path.join(base_dir, CONFIG_NAME)


def load_config(base_dir):
    """{'gmail':..., 'app_password':..., 'auto':bool, 'last_backup':float}"""
    cfg = {"gmail": "", "app_password": "", "auto": False, "last_backup": 0.0}
    try:
        with open(config_path(base_dir), "r", encoding="utf-8") as fh:
            data = json.load(fh)
        for key in cfg:
            if key in data:
                cfg[key] = data[key]
    except (OSError, ValueError):
        pass
    return cfg


def save_config(base_dir, gmail, app_password, auto, last_backup=0.0):
    old = load_config(base_dir)
    if last_backup == 0.0:
        last_backup = old.get("last_backup", 0.0)
    cfg = {
        "gmail": (gmail or "").strip(),
        "app_password": (app_password or "").replace(" ", ""),
        "auto": bool(auto),
        "last_backup": float(last_backup),
    }
    with open(config_path(base_dir), "w", encoding="utf-8") as fh:
        json.dump(cfg, fh, indent=2)
    return cfg


def mark_backed_up(base_dir):
    cfg = load_config(base_dir)
    cfg["last_backup"] = time.time()
    with open(config_path(base_dir), "w", encoding="utf-8") as fh:
        json.dump(cfg, fh, indent=2)
    return cfg


def needs_backup(cfg, now=None):
    """Auto backup on hai aur 24 ghante guzar gaye?"""
    if not cfg.get("auto"):
        return False
    if not cfg.get("gmail") or not cfg.get("app_password"):
        return False
    now = time.time() if now is None else now
    return (now - float(cfg.get("last_backup", 0))) >= BACKUP_INTERVAL


def build_message(gmail, db_path, recovery_key=None):
    """EmailMessage banao -- network use nahi karta (testable)."""
    msg = EmailMessage()
    msg["From"] = gmail
    msg["To"] = gmail
    stamp = time.strftime("%Y-%m-%d %H:%M")
    msg["Subject"] = f"Hamza GSM Tool backup - {stamp}"
    body = (
        "Assalam-o-Alaikum,\n\n"
        "Ye Hamza GSM Tool ka automatic backup hai (users.db).\n"
        f"Backup time: {stamp}\n\n"
        "Is email ko delete NA karo -- PC kharab hone par isi file se\n"
        "saare accounts wapis mil jayenge.\n"
    )
    if recovery_key:
        body += (
            "\nTumhari MASTER RECOVERY KEY (sambhal kar rakho, kisi ko na do):\n"
            f"{recovery_key}\n"
            "Naye PC par tool kholo -> 'Master Admin' -> ye key dalo.\n"
        )
    body += "\n-- Hamza GSM Tool"
    msg.set_content(body)
    with open(db_path, "rb") as fh:
        data = fh.read()
    fname = f"users-backup-{time.strftime('%Y-%m-%d')}.db"
    msg.add_attachment(data, maintype="application",
                       subtype="octet-stream", filename=fname)
    return msg


def send_backup(gmail, app_password, db_path, recovery_key=None,
                smtp_class=smtplib.SMTP):
    """Backup email bhejo. Returns (True, 'ok') ya (False, wajah)."""
    if not os.path.exists(db_path):
        return False, "users.db nahi mili -- pehle admin account banao."
    if not gmail or not app_password:
        return False, "Pehle Gmail aur App Password save karo."
    try:
        msg = build_message(gmail, db_path, recovery_key)
        server = smtp_class(SMTP_HOST, SMTP_PORT, timeout=30)
        try:
            server.starttls()
            server.login(gmail, app_password)
            server.send_message(msg)
        finally:
            try:
                server.quit()
            except Exception:
                pass
        return True, "Backup email bhej diya gaya."
    except smtplib.SMTPAuthenticationError:
        return False, "Gmail login fail -- App Password ghalat hai."
    except (smtplib.SMTPException, OSError) as exc:
        return False, f"Email nahi bheji ja saki: {exc}"


# ---------------- Gmail se backup wapis lao (IMAP) ----------------
IMAP_HOST = "imap.gmail.com"
IMAP_PORT = 993
_BACKUP_SUBJECT = "Hamza GSM Tool backup"


def fetch_latest_backup(gmail, app_password, imap_class=None):
    """Gmail me sab se naya backup email dhoondo.

    Returns (True, 'ok', db_bytes) ya (False, wajah, None).
    """
    import imaplib
    if imap_class is None:
        imap_class = imaplib.IMAP4_SSL
    if not gmail or not app_password:
        return False, "Pehle Gmail aur App Password save karo.", None
    try:
        mail = imap_class(IMAP_HOST, IMAP_PORT)
        try:
            mail.login(gmail, app_password)
            mail.select("INBOX")
            typ, data = mail.search(None, "SUBJECT",
                                    f'"{_BACKUP_SUBJECT}"')
            if typ != "OK" or not data or not data[0]:
                return False, "Gmail me koi backup email nahi mila.", None
            latest_id = data[0].split()[-1]
            typ, msg_data = mail.fetch(latest_id, "(RFC822)")
            if typ != "OK" or not msg_data:
                return False, "Backup email parha nahi ja saka.", None
            from email import message_from_bytes
            msg = message_from_bytes(msg_data[0][1])
            for part in msg.walk():
                fname = part.get_filename() or ""
                if fname.startswith("users-backup-") and fname.endswith(".db"):
                    return True, "ok", part.get_payload(decode=True)
            return False, "Backup email me users.db attachment nahi mila.", None
        finally:
            try:
                mail.logout()
            except Exception:
                pass
    except imaplib.IMAP4.error:
        return False, "Gmail login fail -- App Password ghalat hai.", None
    except OSError as exc:
        return False, f"Gmail se rabta nahi ho saka: {exc}", None


def restore_db(base_dir, db_bytes):
    """users.db ko backup email wali file se replace karo.

    Pehle maujooda users.db ki safety copy banata hai.
    Returns (True, msg) ya (False, wajah).
    """
    if not db_bytes or len(db_bytes) < 100:
        return False, "Backup file khaali ya kharab hai."
    if db_bytes[:16] != b"SQLite format 3\x00":
        return False, "Ye asal users.db backup nahi lag rahi."
    db_path = os.path.join(base_dir, "users.db")
    if os.path.exists(db_path):
        stamp = time.strftime("%Y-%m-%d_%H%M%S")
        safety = os.path.join(base_dir, f"users.db.backup-{stamp}")
        try:
            with open(db_path, "rb") as fh:
                old = fh.read()
            with open(safety, "wb") as fh:
                fh.write(old)
        except OSError as exc:
            return False, f"Safety copy nahi ban saki: {exc}"
    try:
        with open(db_path, "wb") as fh:
            fh.write(db_bytes)
    except OSError as exc:
        return False, f"Restore nahi ho saka: {exc}"
    return True, "Backup wapis aa gaya! Tool dobara kholo."
